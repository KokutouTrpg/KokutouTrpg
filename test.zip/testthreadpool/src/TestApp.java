
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class TestApp {
    private static final long KEEP_ALIVE_TIME = 5L;
    private ExecutorService executor = null;
    private final ReentrantLock rebootLock = new ReentrantLock(true);
    private volatile Future<?> resultStartInstance = null;

    public static void sleep(long millis, boolean isThrowInterruptedException, boolean canInterrupt)
            throws InterruptedException {
        Util.printLog(Util.LOG.IN, "sleep");
        try {
            if (canInterrupt) {
                try {
                    Thread.sleep(millis);
                } catch (InterruptedException e) {
                    Util.printLog(null, "sleep", "interrupted", e);
                    if (isThrowInterruptedException) {
                        Util.printLog(null, "sleep", "throw InterruptedException", e);
                        throw e;
                    }
                }
            } else {
                long anchorNanoTime = System.nanoTime();
                long currentNanoTime;
                do {
                    currentNanoTime = System.nanoTime();
                } while (currentNanoTime - anchorNanoTime < millis * 1000000);
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "sleep");
        }
    }

    public static void main(String[] args) {
        PrintStream sysOut = System.out;
        try (FileOutputStream fos = new FileOutputStream("out.pu")) {
            PrintStream ps = new PrintStream(fos);
            System.setOut(ps);
            System.out.println("@startuml");
            Util.setAnchorNanoTime();
            Util.printLog(Util.LOG.IN, "main");
            TestApp app = new TestApp();
            try {
                app.startAsync();
                sleep(3000L, true, true);
                app.reboot();
                sleep(250L, true, true);
                app.reboot();
            } catch (InterruptedException e) {
                Util.printLog(null, "main", "interrupted", e);
            } finally {
                int poolsize;
                do {
                    poolsize = ((ThreadPoolExecutor) app.executor).getPoolSize();
                    try {
                        sleep(1000L, false, false);
                    } catch (InterruptedException e) {
                    }
                } while (poolsize != 0);
                Util.printLog(Util.LOG.OUT, "main");
                System.out.println("@enduml");
                ps.close();
                fos.close();
                System.setOut(sysOut);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void startAsync() {
        Util.printLog(Util.LOG.IN, "startAsync", "");
        try {
            executor = new ThreadPoolExecutorEx(0, 1, KEEP_ALIVE_TIME, TimeUnit.SECONDS,
                    ThreadFactoryImpl.getInstance());
            Runnable runner = () -> {
                Util.printLog(Util.LOG.IN, "run");
                try {
                    start();
                } finally {
                    Util.printLog(Util.LOG.OUT, "run");
                }
            };
            try {
                executor.submit(runner);
            } catch (Exception e) {
                Util.printLog(null, "startAsync", "failed to start.", e);
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "startAsync");
        }
    }

    public void start() {
        Util.printLog(Util.LOG.IN, "start");
        try {
            boolean isCallStartInstance = false;
            try {
                startInstance();
            } catch (Exception e) {
                if (ExceptionUtil.isSpecifiedExceptionOccurred(e, InterruptedException.class)) {
                    Util.printLog(null, "start", "interrupted.", e);
                } else {
                    if (!isCallStartInstance) {
                        Util.printLog(null, "start", "failed to start.", e);
                    }
                }
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "start");
        }
    }

    private volatile Thread currentThread = null;

    public void startInstance() throws Exception {
        Util.printLog(Util.LOG.IN, "startInstance");
        currentThread = Thread.currentThread();
        try {
            sleep(1000L, false, true);
            if (Thread.currentThread().isInterrupted()) {
                Util.printLog(null, "startInstance", "isInterrupted");
            }
            sleep(500L, true, true);
            if (Thread.currentThread().isInterrupted()) {
                Util.printLog(null, "startInstance", "isInterrupted");
            }
            sleep(500L, true, true);
        } finally {
            if (Thread.currentThread().isInterrupted()) {
                Util.printLog(null, "startInstance", "isInterrupted");
            }
            currentThread = null;
            Util.printLog(Util.LOG.OUT, "startInstance");
        }
    }

    public void stopInstance() {
        Util.printLog(Util.LOG.IN, "stopInstance");
        try {
        } finally {
            Util.printLog(Util.LOG.OUT, "stopInstance");
        }
    }

    public void cancel() {
        Util.printLog(Util.LOG.IN, "cancel", "");
        try {
            if (resultStartInstance != null) {
                boolean result = resultStartInstance.cancel(true);
                if (result) {
                    Util.printLog(null, "cancel", "success cancel");
                }
                if (resultStartInstance.isCancelled()) {
                    Util.printLog(null, "cancel", "isCancelled");
                }
                if (resultStartInstance.isDone()) {
                    Util.printLog(null, "cancel", "isDone");
                }
                if (currentThread != null) {
                    Util.printLog(null, "cancel", "state=" + currentThread.getState().toString());
                }
                Util.printLog(Util.LOG.IN, "get", "");
                try {
                    Object obj = resultStartInstance.get();
                } catch (Exception e) {
                    Util.printLog(null, "get", "exception happen", e);
                } finally {
                    Util.printLog(Util.LOG.OUT, "get", "");
                }
                if (currentThread != null) {
                    Util.printLog(null, "cancel", "state=" + currentThread.getState().toString());
                }
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "cancel", "");
        }
    }

    public void interrupt() {
        Util.printLog(Util.LOG.IN, "interrupt", "");
        try {
            if (resultStartInstance != null) {
                if (currentThread != null) {
                    Util.printLog(null, "interrupt", "state=" + currentThread.getState().toString());
                    currentThread.interrupt();
                    Util.printLog(null, "interrupt", "state=" + currentThread.getState().toString());
                }
                if (resultStartInstance.isCancelled()) {
                    Util.printLog(null, "interrupt", "isCancelled");
                }
                if (resultStartInstance.isDone()) {
                    Util.printLog(null, "interrupt", "isDone");
                }
                if (currentThread != null) {
                    Util.printLog(null, "interrupt", "state=" + currentThread.getState().toString());
                }
                Util.printLog(Util.LOG.IN, "get", "");
                try {
                    Object obj = resultStartInstance.get();
                } catch (Exception e) {
                    Util.printLog(null, "get", "exception happen", e);
                } finally {
                    Util.printLog(Util.LOG.OUT, "get", "");
                }
                if (currentThread != null) {
                    Util.printLog(null, "interrupt", "state=" + currentThread.getState().toString());
                }
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "interrupt", "");
        }
    }

    public void reboot() {
        Util.printLog(Util.LOG.IN, "reboot");
        try {
            try {
                rebootLock.lock();
                stopInstance();
                cancel(); // Cancelするも、割り込み例外が握りつぶされ終了。Future.getはCanceldExceptionが発生
                cancel(); // Cancel済みのため、再キャンセルできない。Future.getはCanceldExceptionが発生
                interrupt(); // 割り込みで成功
                Runnable runner = () -> {
                    Util.printLog(Util.LOG.IN, "run");
                    try {
                        startInstance();
                    } catch (Exception e) {
                        Util.printLog(null, "reboot", "failed to reboot() by startInstance(). ", e);
                    }
                    Util.printLog(Util.LOG.OUT, "run");
                };
                try {
                    resultStartInstance = executor.submit(runner);
                } catch (Exception e) {
                    Util.printLog(null, "reboot", "failed to reboot(). ", e);
                }
            } finally {
                rebootLock.unlock();
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "reboot");
        }
    }
}