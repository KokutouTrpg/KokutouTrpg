
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class TestApp {
    private static final long KEEP_ALIVE_TIME = 30L;
    private ExecutorService executor = null;
    private final ReentrantLock rebootLock = new ReentrantLock(true);
    private volatile Future<?> resultStartInstance = null;

    public static void sleep(long millis, boolean isThrowInterruptedException) throws InterruptedException {
        Util.printLog(Util.LOG.IN, "sleep");
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Util.printLog(null, "sleep", "interrupted.", e);
            if (isThrowInterruptedException) {
                Util.printLog(null, "sleep", "throw InterruptedException", e);
                throw e;
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "sleep");
        }
    }

    public static void main(String[] args) {
        PrintStream sysOut = System.out;
        try (FileOutputStream fos = new FileOutputStream("out.pu")) {
            PrintStream ps = new PrintStream(fos);
            System.setOut(ps);
            System.out.println("@startuml");
            Util.setAnchorNanoTime();
            Util.printLog(Util.LOG.IN, "main");
            TestApp app = new TestApp();
            try {
                app.startAsync();
                sleep(5000L, true);
                app.reboot();
                sleep(1000L, true);
                app.reboot();
            } catch (InterruptedException e) {
                Util.printLog(null, "main", "interrupted.", e);
            } finally {
                int poolsize;
                do {
                    poolsize = ((ThreadPoolExecutor) app.executor).getPoolSize();
                    // Util.printLog(null, "main", "PoolSize=" + poolsize);
                    try {
                        Thread.sleep(1000L);
                    } catch (InterruptedException e) {
                    }
                } while (poolsize != 0);
                poolsize = ((ThreadPoolExecutor) app.executor).getPoolSize();
                Util.printLog(null, "main", "PoolSize=" + poolsize);
                Util.printLog(Util.LOG.OUT, "main");
                System.out.println("@enduml");
                ps.close();
                fos.close();
                System.setOut(sysOut);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void startAsync() {
        Util.printLog(Util.LOG.IN, "startAsync", "");
        try {
            executor = new ThreadPoolExecutorEx(0, 1, KEEP_ALIVE_TIME, TimeUnit.SECONDS,
                    ThreadFactoryImpl.getInstance());
            Runnable runner = () -> {
                Util.printLog(Util.LOG.IN, "run");
                try {
                    start();
                } finally {
                    Util.printLog(Util.LOG.OUT, "run");
                }
            };
            try {
                executor.submit(runner);
            } catch (Exception e) {
                Util.printLog(null, "startAsync", "failed to start.", e);
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "startAsync");
        }
    }

    public void start() {
        Util.printLog(Util.LOG.IN, "start");
        try {
            boolean isCallStartInstance = false;
            try {
                startInstance();
            } catch (Exception e) {
                if (ExceptionUtil.isSpecifiedExceptionOccurred(e, InterruptedException.class)) {
                    Util.printLog(null, "start", "interrupted.", e);
                } else {
                    if (!isCallStartInstance) {
                        Util.printLog(null, "start", "failed to start.", e);
                    }
                }
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "start");
        }
    }

    public void startInstance() throws Exception {
        Util.printLog(Util.LOG.IN, "startInstance");
        try {
            sleep(2000L, false);
            if (Thread.currentThread().isInterrupted()) {
                Util.printLog(null, "startInstance", "isInterrupted");
            }
            sleep(1000L, true);
        } finally {
            if (Thread.currentThread().isInterrupted()) {
                Util.printLog(null, "startInstance", "isInterrupted");
            }
            Util.printLog(Util.LOG.OUT, "startInstance");
        }
    }

    public void stopInstance() {
        Util.printLog(Util.LOG.IN, "stopInstance");
        try {
        } finally {
            Util.printLog(Util.LOG.OUT, "stopInstance");
        }
    }

    public void reboot() {
        Util.printLog(Util.LOG.IN, "reboot");
        try {
            try {
                rebootLock.lock();
                stopInstance();
                if (resultStartInstance != null) {
                    Util.printLog(Util.LOG.IN, "cancel", "");
                    resultStartInstance.cancel(true);
                    Util.printLog(Util.LOG.OUT, "cancel", "");
                }
                Runnable runner = () -> {
                    Util.printLog(Util.LOG.IN, "run");
                    try {
                        startInstance();
                    } catch (Exception e) {
                        Util.printLog(null, "reboot", "failed to reboot() by startInstance(). ", e);
                    }
                    Util.printLog(Util.LOG.OUT, "run");
                };
                try {
                    resultStartInstance = executor.submit(runner);
                } catch (Exception e) {
                    Util.printLog(null, "reboot", "failed to reboot(). ", e);
                }
            } finally {
                rebootLock.unlock();
            }
        } finally {
            Util.printLog(Util.LOG.OUT, "reboot");
        }
    }
}