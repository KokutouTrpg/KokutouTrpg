import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class ThreadPoolExecutorEx extends ThreadPoolExecutor {
	public ThreadPoolExecutorEx(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit,
			ThreadFactory threadFactory) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, new ThreadTaskQueue(), threadFactory);
		this.setRejectedExecutionHandler((ThreadTaskQueue) this.getQueue());
	}

	@Override
	protected void beforeExecute(Thread t, Runnable r) {
		// Util.printLog(Util.LOG.IN, "beforeExecute");
		// Util.printLog(Util.LOG.OUT, "beforeExecute");
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected void afterExecute(Runnable r, Throwable t) {
		// Util.printLog(Util.LOG.IN, "afterExecute");
		if (t != null) {
			Util.printLog(null, "afterExecute", "happen.", t);
		} else if (r instanceof FutureTask) {
			if (((FutureTask) r).isCancelled()) {
				try {
					((FutureTask) r).get();
				} catch (InterruptedException e) {
					Util.printLog(null, "afterExecute", "happen.", e);
				} catch (ExecutionException e) {
					Util.printLog(null, "afterExecute", "happen.", e);
					Util.printLog(null, "afterExecute", "happen.", e.getCause());
				} catch (Throwable e) {
					Util.printLog(null, "afterExecute", "happen.", e);
				}
			}
		}
		// Util.printLog(Util.LOG.OUT, "afterExecute");
	}
}

class ThreadTaskQueue extends LinkedBlockingQueue<Runnable> implements RejectedExecutionHandler {
	private AtomicInteger idleThreads = new AtomicInteger();

	@Override
	public final boolean offer(Runnable task) {
		if (idleThreads.get() == 0) {
			return false;
		}
		return super.offer(task);
	}

	@Override
	public final Runnable take() throws InterruptedException {
		idleThreads.incrementAndGet();
		try {
			Runnable task = super.take();
			return task;
		} catch (InterruptedException e) {
			throw e;
		} finally {
			idleThreads.decrementAndGet();
		}
	}

	@Override
	public final Runnable poll(long timeout, TimeUnit unit) throws InterruptedException {
		Util.printLog(Util.LOG.IN, "poll");
		idleThreads.incrementAndGet();
		try {
			Runnable task = super.poll(timeout, unit);
			if (task == null) {
				Util.printLog(null, "poll", "poll thread keepAliveTime Over. idleThreads=" + idleThreads.get());
			}
			return task;
		} finally {
			idleThreads.decrementAndGet();
			Util.printLog(Util.LOG.OUT, "poll");
		}
	}

	private boolean offerRejectTask(Runnable task) {
		return super.offer(task);
	}

	@Override
	public void rejectedExecution(Runnable task, ThreadPoolExecutor executor) {
		if (executor.isShutdown()) {
			throw new RejectedExecutionException("Task $r rejected from $executor");
		}
		((ThreadTaskQueue) executor.getQueue()).offerRejectTask(task);
	}
}
