
import java.io.PrintWriter;
import java.io.StringWriter;

public class Util {
	private static long anchorNanoTime = 0L;

	public enum LOG {
		IN,
		OUT
	};

	public static void setAnchorNanoTime() {
		anchorNanoTime = System.nanoTime();
	}

	public static long getDeltaNanoTimeFromAnchor() {
		return System.nanoTime() - anchorNanoTime;
	}

	public static void printLog(LOG type, String method) {
		printLog(type, method, "", null, null);
	}

	public static void printLog(LOG type, String method, String message) {
		printLog(type, method, message, null, null);
	}

	public static void printLog(LOG type, String method, String message, Throwable thr) {
		printLog(type, method, message, thr, null);
	}

	public static void printLog(LOG type, String method, String message, Exception e) {
		printLog(type, method, message, null, e);
	}

	public static synchronized void printLog(LOG type, String method, String message, Throwable thr, Exception e) {
		long dt = getDeltaNanoTimeFromAnchor();
		String thName = getThreadName();
		print2(type, dt, thName, method, message);
	}

	public static void print2(LOG type, long dt, String thName, String method, String message) {
		String _thName = thName.replace("-", "");
		if (type == LOG.IN) {
			System.out.println("?-> " + _thName);
			System.out.println("activate " + _thName);
		} else if (type == LOG.OUT) {
			System.out.println("?<- " + _thName);
			System.out.println("deactivate " + _thName);
		} else {
			System.out.println("?--> " + _thName);
		}
		double _dt = ((double) dt) / 1000000000;
		System.out.println("rnote right");
		String str = String.format("%12.9f [%s]-%s() {%s}", _dt, _thName, method, message);
		System.out.println(str);
		System.out.println("end note");

		// printStackTrace(thr,e);

	}

	public static void print1(LOG type, long dt, String thName, String method, String message) {
		String logtype = "   ";

		if (type == null) {
			logtype = "---";
		} else if (type == LOG.IN) {
			logtype = ">>>";
		} else if (type == LOG.OUT) {
			logtype = "<<<";
		}
		String str = String.format("|%11d|%3s|%10s|%15s()|%s", dt, logtype, thName, method, message);
		System.out.println(str);
		// printStackTrace(thr,e);

	}

	public static void printStackTrace(Throwable thr, Exception e) {
		if (thr != null) {
			System.err.println(Util.getStackTraceString(thr));
		}
		if (e != null) {
			System.err.println(Util.getStackTraceString(e));
		}
	}

	public static String getStackTraceString(Throwable thr) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		thr.printStackTrace(pw);
		pw.flush();
		return sw.toString();
	}

	public static String getStackTraceString(Exception e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		pw.flush();
		return sw.toString();
	}

	public static String getThreadName() {
		return Thread.currentThread().getName();
	}
}
