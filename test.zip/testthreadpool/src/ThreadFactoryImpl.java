
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadFactory;

public final class ThreadFactoryImpl implements ThreadFactory {
	private static final String THREAD_GROUP_NAME = "THGROUP";
	private static final String LINE_SEPARATOR = System.lineSeparator();
	private static final int MARGIN = 10;
	private static ThreadFactoryImpl singleton = null;
	private ThreadGroup threadGroup = new ThreadGroup(THREAD_GROUP_NAME);

	private ThreadFactoryImpl() {
	}

	public static synchronized ThreadFactoryImpl getInstance() {
		if (singleton == null) {
			singleton = new ThreadFactoryImpl();
		}
		return singleton;
	}

	@Override
	public Thread newThread(Runnable r) {
		Util.printLog(Util.LOG.IN, "newThread");
		Thread thread = new Thread(threadGroup, r);
		// thread.setName(THREAD_GROUP_NAME + "-" + thread.getName());
		Util.printLog(Util.LOG.OUT, "newThread", "" + thread);
		return thread;
	}

	public synchronized String dumpThreads() {
		Thread[] threads = new Thread[threadGroup.activeCount() + MARGIN];
		threadGroup.enumerate(threads);
		List<Thread> list = new ArrayList<Thread>(Arrays.asList(threads));
		list.removeAll(Collections.singleton(null));
		Comparator<Thread> comparator = Comparator.comparing(Thread::getName);
		list.sort(comparator);
		StringBuilder sb = new StringBuilder();
		for (Thread thread : list) {
			sb.append("# Thread: ");
			sb.append(thread.getName());
			sb.append(LINE_SEPARATOR);
			for (StackTraceElement elem : thread.getStackTrace()) {
				String log = " at " + elem.getClassName() + "."
						+ elem.getMethodName() + "("
						+ elem.getFileName() + ":"
						+ elem.getLineNumber() + ")";
				sb.append(log);
				sb.append(LINE_SEPARATOR);
			}
			sb.append(LINE_SEPARATOR);
		}
		return sb.toString();
	}
}
