
public final class ExceptionUtil {
	private ExceptionUtil() {
	}

	public static boolean isSpecifiedExceptionOccurred(Exception e, Class<? extends Exception> specify) {
		Throwable causeThrowable = e;
		do {
			if (specify.isInstance(causeThrowable)) {
				return true;
			}
			causeThrowable = causeThrowable.getCause();
		} while (causeThrowable != null);
		return false;
	}
}
