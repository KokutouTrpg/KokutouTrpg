
public final class ThreadUtil {
	private ThreadUtil() {
	}

	public static void checkThrowInterrupted() throws InterruptedException {
		if (Thread.currentThread().isInterrupted()) {
			throw new InterruptedException("An interrupt occurred.");
		}
	}
}
