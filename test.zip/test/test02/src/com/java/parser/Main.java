package com.java.parser;

import com.java.parser.project.JavaProject;

import com.java.parser.antlr.JavaLexer;
import com.java.parser.antlr.JavaParser;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

public class Main {
	public static void main(String[] args) throws IOException, IllegalAccessException {
		String path = null;
		Optional<String> pathOptional = Arrays.stream(args).filter(item -> item.startsWith("-path=")).findFirst();
		if (pathOptional.isPresent()) {
			path = pathOptional.get();
			path = path.split("-path=")[1];
		}
		if (Objects.isNull(path)) {
			throw new IllegalArgumentException("please pass code path to parse");
		}

		File dir = new File(path);
		if (!dir.exists()) {
			throw new FileNotFoundException(dir.toString());
		}
		List<String> files = new ArrayList<>();
		get(dir, files);

		files = files.stream().filter(item -> item.endsWith(".java")).collect(Collectors.toList());
		List<JavaParser> parsers = new ArrayList<>();
		for (String file : files) {
			System.out.println(file);
			CharStream charStream = CharStreams.fromPath(Paths.get(file));
			JavaLexer javaLexer = new JavaLexer(charStream);
			parsers.add(new JavaParser(new CommonTokenStream(javaLexer)));
		}
		JavaProject project = new JavaProject();
		parsers.forEach(parser -> {
			project.load(parser);
		});
		System.out.println("========================================================");
		System.out.println("[After Load]");
		// project.print(1);
		System.out.println("========================================================");
		System.out.println("[Before Resolve]");
		project.resolveImports();
		System.out.println("========================================================");
		System.out.println("[After Resolve]");
		project.print(1);
		System.out.println("========================================================");
	}

	private static void get(File file, List files) {
		File[] fs = file.listFiles();
		for (File f : fs) {
			if (f.isDirectory()) {
				get(f, files);
			}
			if (f.isFile()) {
				files.add(f.getPath());
			}
		}
	}

	private static void printChildlen(ParseTree context, int layer) {
		printChildlen(context, layer, 5);
	}

	private static void printChildlen(ParseTree context, int layer, int max_layer) {
		if (layer == max_layer) {
			return;
		}
		if (context.getChildCount() == 0) {
			System.out.println(indentation(layer) + "{" + context.getClass().getCanonicalName() + "} <= '" + context + "'");
		} else {
			System.out.println(indentation(layer) + "{" + context.getClass().getCanonicalName() + "}");
		}
		for (int i = 0; i < context.getChildCount(); ++i) {
			ParseTree child = context.getChild(i);
			printChildlen(child, layer + 1, max_layer);
		}
	}

	private static String indentation(int n) {
		return String.join("", Collections.nCopies(n, "  "));
	}
}