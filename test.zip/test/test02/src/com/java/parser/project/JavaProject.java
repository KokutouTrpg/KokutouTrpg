package com.java.parser.project;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.PrimitiveIterator;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.antlr.v4.runtime.RuleContext;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.xpath.XPath;

import java.util.HashMap;
import java.util.Iterator;

import com.java.parser.antlr.JavaParser;
import com.java.parser.project.JavaProject.JavaPackage.JavaImports;

public class JavaProject {
	private List<JavaImports> importsList;
	private Map<String, JavaPackage> packages;

	public JavaProject() {
		this.packages = new HashMap<>();
		this.importsList = new ArrayList<>();
	}

	public void print(int layer) {
		System.out.println(JavaProject.indentation(layer) + "[Project]");
		System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer("this", this));
		System.out.println(JavaProject.indentation(layer + 1) + "[Packages]");
		this.packages.entrySet().stream() //
				.forEach(e -> {
					System.out.println(JavaProject.indentation(layer + 1) + JavaProject.printPointer(e.getKey(), e.getValue()));
					e.getValue().print(layer + 2);
				});
	}

	public JavaPackage getPackage(String name) {
		if (!this.packages.containsKey(name)) {
			this.packages.put(name, new JavaPackage());
		}
		return this.packages.get(name);
	}

	public void load(JavaParser parser) {
		JavaParser.CompilationUnitContext cuctx = parser.compilationUnit();
		JavaPackage _package = this.loadPackage(cuctx, parser);
	}

	public JavaPackage loadPackage(JavaParser.CompilationUnitContext cuctx, JavaParser parser) {
		JavaParser.PackageDeclarationContext ctx = cuctx.getChild(JavaParser.PackageDeclarationContext.class, 0);
		String name = ctx.getChild(1).getText();
		JavaPackage _package = this.getPackage(name);

		JavaImports imports = _package.loadImports(cuctx, parser);

		_package.loadPublicClasses(cuctx, parser, imports);
		_package.loadDefaultClasses(cuctx, parser, imports);

		return _package;
	}

	public void resolveImports() {
		importsList.stream() //
				.forEach(imports -> {
					Predicate<Entry<String, JavaPackage>> isQualified = e -> packages.containsKey(e.getKey()) && packages.get(e.getKey()).publicClasses.size() > 0;
					imports.importPackages.entrySet().stream() //
							.filter(isQualified) //
							.forEach(e -> {
								e.getValue().publicClasses.entrySet().stream() //
										.forEach(e1 -> imports.importClasses.put(e1.getKey(), e1.getValue()));
							});
					imports.importPackages.entrySet().removeIf(isQualified);
				});
		packages.entrySet().stream() //
				.forEach(e -> {
					e.getValue().defaultClasses.entrySet() //
							.forEach(e1 -> e1.getValue().resolveSuperClass());
					e.getValue().publicClasses.entrySet() //
							.forEach(e1 -> e1.getValue().resolveSuperClass());
				});
		packages.entrySet().stream() //
				.forEach(e -> {
					e.getValue().defaultClasses.entrySet() //
							.forEach(e1 -> e1.getValue().resolveInheritance());
					e.getValue().publicClasses.entrySet() //
							.forEach(e1 -> e1.getValue().resolveInheritance());
				});
	}

	public class JavaPackage {
		private Map<String, JavaClass> publicClasses;
		private Map<String, JavaClass> defaultClasses;

		public JavaPackage() {
			this.publicClasses = new HashMap<>();
			this.defaultClasses = new HashMap<>();
		}

		public void print(int layer) {
			if (this.publicClasses.size() > 0) {
				System.out.println(JavaProject.indentation(layer) + "[Public Classes]");
				this.publicClasses.entrySet().stream() //
						.forEach(e -> {
							System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
							e.getValue().print(layer + 1);
						});
			}
			if (this.defaultClasses.size() > 0) {
				System.out.println(JavaProject.indentation(layer) + "[Default Classes]");
				this.defaultClasses.entrySet().stream() //
						.forEach(e -> {
							System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
							e.getValue().print(layer + 1);
						});
			}
		}

		public JavaClass getPublicClass(String name) {
			if (!this.publicClasses.containsKey(name)) {
				this.publicClasses.put(name, new JavaClass());
			}
			return this.publicClasses.get(name);
		}

		public JavaClass getDefaultClass(String name) {
			if (!this.defaultClasses.containsKey(name)) {
				this.defaultClasses.put(name, new JavaClass());
			}
			return this.defaultClasses.get(name);
		}

		public JavaImports loadImports(JavaParser.CompilationUnitContext cuctx, JavaParser parser) {
			JavaPackage.JavaImports imports = JavaPackage.this.new JavaImports();
			cuctx.getRuleContexts(JavaParser.ImportDeclarationContext.class).stream() //
					.forEach(idctx -> {
						String packagePath = idctx.getChild(1).getText();
						String lastPackagePath = idctx.getChild(1).getChild(idctx.getChild(1).getChildCount() - 1).getText();
						if (lastPackagePath.matches("[A-Z][a-zA-Z0-9_]*")) {
							String packageName = packagePath.substring(0, packagePath.length() - lastPackagePath.length() - 1);
							imports.importClasses.put(lastPackagePath, JavaProject.this.getPackage(packageName).getPublicClass(lastPackagePath));
						} else {
							imports.importPackages.put(packagePath, JavaProject.this.getPackage(packagePath));
						}
					});
			imports.setDefaultImports();
			JavaProject.this.importsList.add(imports);
			return imports;
		}

		public List<JavaClass> loadPublicClasses(JavaParser.CompilationUnitContext cuctx, JavaParser parser, JavaImports imports) {
			return cuctx.getRuleContexts(JavaParser.TypeDeclarationContext.class).stream() //
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassOrInterfaceModifierContext.class).size() > 0) //
					.filter(ctx -> ctx.getChild(JavaParser.ClassOrInterfaceModifierContext.class, 0).getText().equals("public")) //
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() > 0).limit(1) //
					.map(ctx -> {
						JavaParser.ClassDeclarationContext cdctx = ctx.getChild(JavaParser.ClassDeclarationContext.class, 0);
						JavaClass publicClass = this.getPublicClass(cdctx.getChild(1).getText());
						return publicClass.loadClass(cdctx, parser, imports);
					}) //
					.collect(Collectors.toList());
		}

		public List<JavaClass> loadDefaultClasses(JavaParser.CompilationUnitContext cuctx, JavaParser parser, JavaImports imports) {
			return cuctx.getRuleContexts(JavaParser.TypeDeclarationContext.class).stream() //
					.filter(ctx -> (ctx.getRuleContexts(JavaParser.ClassOrInterfaceModifierContext.class).size() == 0) || (!ctx.getChild(JavaParser.ClassOrInterfaceModifierContext.class, 0).getText().equals("public"))) //
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() > 0) //
					.map(ctx -> {
						JavaParser.ClassDeclarationContext cdctx = ctx.getChild(JavaParser.ClassDeclarationContext.class, 0);
						JavaClass defaultClass = this.getDefaultClass(cdctx.getChild(1).getText());
						return defaultClass.loadClass(cdctx, parser, imports);
					}) //
					.collect(Collectors.toList());
		}

		public class JavaImports {
			public Map<String, JavaPackage> importPackages;
			public Map<String, JavaClass> importClasses;

			public JavaImports() {
				this.importPackages = new HashMap<>();
				this.importClasses = new HashMap<>();
			}

			public void setDefaultImports() {
				this.importClasses.put("boolean", JavaProject.this.getPackage("PrimitiveType").getPublicClass("boolean"));
				this.importClasses.put("byte", JavaProject.this.getPackage("PrimitiveType").getPublicClass("byte"));
				this.importClasses.put("short", JavaProject.this.getPackage("PrimitiveType").getPublicClass("short"));
				this.importClasses.put("int", JavaProject.this.getPackage("PrimitiveType").getPublicClass("int"));
				this.importClasses.put("long", JavaProject.this.getPackage("PrimitiveType").getPublicClass("long"));
				this.importClasses.put("char", JavaProject.this.getPackage("PrimitiveType").getPublicClass("char"));
				this.importClasses.put("float", JavaProject.this.getPackage("PrimitiveType").getPublicClass("float"));
			}

			public void print(int layer) {
				if (this.importClasses.size() > 0) {
					System.out.println(JavaProject.indentation(layer) + "[Imported Classes]");
					this.importClasses.entrySet().stream() //
							.forEach(e -> {
								System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
							});
				}
				if (this.importPackages.size() > 0) {
					System.out.println(JavaProject.indentation(layer) + "[Imported Packages]");
					this.importPackages.entrySet().stream() //
							.forEach(e -> {
								System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
							});
				}
			}
		}

		public class JavaClass {
			private JavaImports imports;

			private Map<String, JavaClass> superClass;

			private Map<String, JavaClass> innerClasses;

			private Map<String, JavaMethod> staticMethods;
			private Map<String, JavaInstance> staticFields;

			private JavaInstance originalThis;

			public JavaClass() {
				this.superClass = new HashMap<>();
				this.imports = new JavaImports();
				this.innerClasses = new HashMap<>();

				this.staticMethods = new HashMap<>();
				this.staticFields = new HashMap<>();

				this.originalThis = new JavaInstance();
			}

			public void print(int layer) {
				// this.imports.print(layer);
				if (this.superClass.size() > 0) {
					System.out.println(JavaProject.indentation(layer) + "[Super Class]");
					this.superClass.entrySet().stream() //
							.forEach(e -> {
								System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
							});
				}
				if (this.staticMethods.size() > 0 || this.staticFields.size() > 0) {
					if (this.staticMethods.size() > 0) {
						System.out.println(JavaProject.indentation(layer) + "[Static Methods]");
						this.staticMethods.entrySet().stream() //
								.forEach(e -> {
									System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
									e.getValue().print(layer + 1);
								});
					}
					if (this.staticFields.size() > 0) {
						System.out.println(JavaProject.indentation(layer) + "[Static Fields]");
						this.staticFields.entrySet().stream() //
								.forEach(e -> {
									System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
									e.getValue().print(layer + 1);
								});
					}
				}
				System.out.println(JavaProject.indentation(layer) + "[Original This]");
				System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer("Original This", this.originalThis));
				this.originalThis.print(layer + 1);
				if (this.innerClasses.size() > 0) {
					System.out.println(JavaProject.indentation(layer) + "[Inner Classes]");
					this.innerClasses.entrySet().stream() //
							.forEach(e -> {
								System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
								e.getValue().print(layer + 1);
							});
				}
			}

			public JavaClass setImports(JavaImports imports) {
				this.imports = imports;
				return this;
			}

			public JavaClass setSuperClass(String name) {
				this.superClass.put(name, new JavaClass());
				return this.superClass.get(name);
			}

			public JavaClass getInnerClass(String name) {
				if (!this.innerClasses.containsKey(name)) {
					this.innerClasses.put(name, new JavaClass());
				}
				return this.innerClasses.get(name);
			}

			public JavaMethod getStaticMethods(String name) {
				if (!this.staticMethods.containsKey(name)) {
					this.staticMethods.put(name, new JavaMethod());
				}
				return this.staticMethods.get(name);
			}

			public JavaInstance getStaticFields(String name) {
				if (!this.staticFields.containsKey(name)) {
					this.staticFields.put(name, new JavaInstance());
				}
				return this.staticFields.get(name);
			}

			public JavaClass loadClass(JavaParser.ClassDeclarationContext cdctx, JavaParser parser, JavaImports imports) {
				JavaParser.ClassBodyContext cbctx = cdctx.getRuleContext(JavaParser.ClassBodyContext.class, 0);
				return this.loadClass(cbctx, parser, imports).loadSuperClass(cbctx, parser);
			}

			public JavaClass loadClass(JavaParser.ClassBodyContext cbctx, JavaParser parser, JavaImports imports) {
				this.setImports(imports);
				this.loadStatic(cbctx, parser, imports);
				this.loadMember(cbctx, parser, imports);
				this.loadInnerClasses(cbctx, parser, imports);
				return this;
			}

			public void loadStatic(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
				this.loadStaticMethods(ctx, parser, imports);
				this.loadStaticField(ctx, parser);
			}

			public void loadMember(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
				this.loadMemberMethods(ctx, parser, imports);
				this.loadMemberField(ctx, parser);
			}

			private List<JavaMethod> loadStaticMethods(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
				return ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream() //
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() > 0) //
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).stream() //
								.filter(mctx -> mctx.getText().equals("static")).count() > 0)
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).size() == 1) //
						.filter(cbdctx -> cbdctx.getRuleContext(JavaParser.MemberDeclarationContext.class, 0) //
								.getRuleContexts(JavaParser.MethodDeclarationContext.class).size() == 1) //
						.map(cbdctx -> {
							JavaParser.MethodDeclarationContext mdctx = cbdctx.getRuleContext(JavaParser.MemberDeclarationContext.class, 0) //
									.getRuleContext(JavaParser.MethodDeclarationContext.class, 0);
							return this.getStaticMethods(mdctx.getChild(1).getText()).loadMethod(mdctx, parser, imports);
						}).collect(Collectors.toList());
			}

			private List<JavaMethod> loadMemberMethods(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
				return ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream() //
						.filter(cbdctx -> (cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() == 0) || (cbdctx.getRuleContexts(JavaParser.ModifierContext.class).stream() //
								.filter(mctx -> mctx.getText().equals("static")).count() == 0))
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).size() == 1) //
						.filter(cbdctx -> cbdctx.getRuleContext(JavaParser.MemberDeclarationContext.class, 0) //
								.getRuleContexts(JavaParser.MethodDeclarationContext.class).size() == 1) //
						.map(cbdctx -> {
							JavaParser.MethodDeclarationContext mdctx = cbdctx.getRuleContext(JavaParser.MemberDeclarationContext.class, 0) //
									.getRuleContext(JavaParser.MethodDeclarationContext.class, 0);
							return this.originalThis.getMemberMethods(mdctx.getChild(1).getText()).loadMethod(mdctx, parser, imports);
						}).collect(Collectors.toList());
			}

			private void loadStaticField(JavaParser.ClassBodyContext ctx, JavaParser parser) {
				ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream() //
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() > 0) //
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).stream() //
								.filter(mctx -> mctx.getText().equals("static")).count() > 0)
						.forEach(cbdctx -> {
							cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream() //
									.forEach(mdctx -> {
										mdctx.getRuleContexts(JavaParser.FieldDeclarationContext.class).stream() //
												.forEach(ftdctx -> {
													ftdctx.getRuleContext(JavaParser.VariableDeclaratorsContext.class, 0) //
															.getRuleContexts(JavaParser.VariableDeclaratorContext.class).stream() //
															.forEach(vdctx -> {
																String name = vdctx.getRuleContext(JavaParser.VariableDeclaratorIdContext.class, 0).getText();
																JavaInstance staticField = this.getStaticFields(name).loadFieldType(vdctx, parser);
															});
												});
									});
						});
			}

			private void loadMemberField(JavaParser.ClassBodyContext ctx, JavaParser parser) {
				ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream() //
						.filter(cbdctx -> (cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() == 0) || (cbdctx.getRuleContexts(JavaParser.ModifierContext.class).stream() //
								.filter(mctx -> mctx.getText().equals("static")).count() == 0))
						.forEach(cbdctx -> {
							cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream() //
									.forEach(mdctx -> {
										mdctx.getRuleContexts(JavaParser.FieldDeclarationContext.class).stream() //
												.forEach(ftdctx -> {
													ftdctx.getRuleContext(JavaParser.VariableDeclaratorsContext.class, 0) //
															.getRuleContexts(JavaParser.VariableDeclaratorContext.class).stream() //
															.forEach(vdctx -> {
																String name = vdctx.getRuleContext(JavaParser.VariableDeclaratorIdContext.class, 0).getText();
																JavaInstance memberField = this.originalThis.getMemberFields(name).loadFieldType(vdctx, parser);
															});
												});
									});
						});
			}

			public List<JavaClass> loadInnerClasses(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
				return ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream() //
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).size() == 1) //
						.filter(cbdctx -> cbdctx.getRuleContext(JavaParser.MemberDeclarationContext.class, 0) //
								.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() == 1) //
						.map(cbdctx -> {
							JavaParser.ClassDeclarationContext cdctx = cbdctx.getRuleContext(JavaParser.MemberDeclarationContext.class, 0) //
									.getRuleContext(JavaParser.ClassDeclarationContext.class, 0);
							return this.getInnerClass(cdctx.getChild(1).getText()).loadClass(cdctx, parser, imports);
						}).collect(Collectors.toList());
			}

			public JavaClass loadSuperClass(JavaParser.ClassBodyContext ctx, JavaParser parser) {
				if (ctx.parent.getChildCount() > 3) {
					if (ctx.parent.getChild(2).getText().equals("extends")) {
						String superClassName = ctx.parent.getChild(3).getText();
						return this.setSuperClass(superClassName);
					}
				}
				return null;
			}

			public void resolveSuperClass() {
				Iterator<String> i = this.superClass.keySet().iterator();
				if (i.hasNext()) {
					String superClassName = i.next();
					String[] superClassNames = superClassName.split("\\.");
					String className = superClassNames.length == 0 ? superClassName : superClassNames[0];
					if (this.imports.importClasses.containsKey(className)) {
						JavaClass currentClass = this.imports.importClasses.get(className);
						for (int j = 1; j < superClassNames.length; j++) {
							className = superClassNames[j];
							JavaClass getClass = currentClass.innerClasses.get(className);
							if (Objects.isNull(getClass)) {
								getClass = currentClass.getInnerClass(className);
							}
							currentClass = getClass;
						}
						this.superClass.put(className, currentClass);
					} else if (JavaPackage.this.publicClasses.containsKey(className)) {
						JavaClass currentClass = JavaPackage.this.publicClasses.get(className);
						for (int j = 1; j < superClassNames.length; j++) {
							className = superClassNames[j];
							JavaClass getClass = currentClass.innerClasses.get(className);
							if (Objects.isNull(getClass)) {
								getClass = currentClass.getInnerClass(className);
							}
							currentClass = getClass;
						}
						this.superClass.put(className, currentClass);
					} else {
						this.superClass.remove(superClassName);
					}
					if (superClassNames.length > 1) {
						this.superClass.remove(superClassName);
					}
				}

				this.innerClasses.entrySet().stream() //
						.forEach(e -> e.getValue().resolveSuperClass());

				this.staticMethods.entrySet().stream() //
						.forEach(e2 -> e2.getValue().anonymousClasses.entrySet().stream() //
								.forEach(e3 -> e3.getValue().resolveSuperClass()));
				this.originalThis.memberMethods.entrySet().stream() //
						.forEach(e2 -> e2.getValue().anonymousClasses.entrySet().stream() //
								.forEach(e3 -> e3.getValue().resolveSuperClass()));
				this.staticFields.entrySet().stream() //
						.forEach(e -> e.getValue().resolveDeclaredType(this.imports));
			}

			public void resolveInheritance() {
				Iterator<String> i = this.superClass.keySet().iterator();
				if (i.hasNext()) {
					String superClassName = i.next();
					JavaClass getClass = this.superClass.get(superClassName);
					getClass.resolveInheritance();
					getClass.staticMethods.entrySet().stream()
							// .filter(e ->
							// !this.staticMethods.containsKey(e.getKey()))
							.forEach(e -> System.out.println(e.getKey()));
					getClass.staticMethods.entrySet().stream() //
							.filter(e -> !this.staticMethods.containsKey(e.getKey())) //
							.forEach(e -> this.staticMethods.put(e.getKey(), e.getValue()));
					getClass.staticFields.entrySet().stream() //
							.filter(e -> !this.staticFields.containsKey(e.getKey())) //
							.forEach(e -> this.staticFields.put(e.getKey(), e.getValue()));
					getClass.originalThis.memberMethods.entrySet().stream() //
							.filter(e -> !this.originalThis.memberMethods.containsKey(e.getKey())) //
							.forEach(e -> this.originalThis.memberMethods.put(e.getKey(), e.getValue()));
					getClass.originalThis.memberFields.entrySet().stream() //
							.filter(e -> !this.originalThis.memberFields.containsKey(e.getKey())) //
							.forEach(e -> this.originalThis.memberFields.put(e.getKey(), e.getValue()));
				}
				this.innerClasses.entrySet().stream() //
						.forEach(e -> e.getValue().resolveInheritance());
				this.staticMethods.entrySet().stream() //
						.forEach(e2 -> e2.getValue().anonymousClasses.entrySet().stream() //
								.forEach(e3 -> e3.getValue().resolveInheritance()));
				this.originalThis.memberMethods.entrySet().stream() //
						.forEach(e2 -> e2.getValue().anonymousClasses.entrySet().stream() //
								.forEach(e3 -> e3.getValue().resolveInheritance()));

			}

			public class JavaMethod {
				private Map<String, JavaClass> anonymousClasses;
				private Map<String, JavaMethod> callMethods;

				public JavaMethod() {
					this.anonymousClasses = new HashMap<>();
					this.callMethods = new HashMap<>();
				}

				public void print(int layer) {
					if (this.anonymousClasses.size() > 0) {
						System.out.println(JavaProject.indentation(layer) + "[Anonymous Classes]");
						this.anonymousClasses.entrySet().stream() //
								.forEach(e -> {
									System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
									e.getValue().print(layer + 1);
								});
						// this.superClass.print(layer + 2);
					}
				}

				public JavaClass getAnonymousClass() {
					String name = "#" + this.anonymousClasses.size();
					this.anonymousClasses.put(name, new JavaClass());
					return this.anonymousClasses.get(name);
				}

				public JavaMethod getCallMethods(String name) {
					if (!this.callMethods.containsKey(name)) {
						this.callMethods.put(name, new JavaMethod());
					}
					return this.callMethods.get(name);
				}

				public JavaMethod loadMethod(JavaParser.MethodDeclarationContext mtdctx, JavaParser parser, JavaImports imports) {
					this.loadAnonymousClasses(mtdctx, parser, imports);
					return this;
				}

				public JavaMethod loadMethod(JavaParser.LambdaExpressionContext lectx, JavaParser parser, JavaImports imports) {
					this.loadAnonymousClasses(lectx, parser, imports);
					return this;
				}

				private List<JavaClass> loadAnonymousClasses(RuleContext ctx, JavaParser parser, JavaImports imports) {
					Collection<ParseTree> creators = XPath.findAll(ctx, "//creator", parser);
					Collection<ParseTree> skipcreators = XPath.findAll(ctx, "//creator/classCreatorRest//creator", parser);
					Collection<ParseTree> lambdaExpressions = XPath.findAll(ctx, "//expression/lambdaExpression", parser);
					Collection<ParseTree> skipclambdaExpressions = XPath.findAll(ctx, "//expression/lambdaExpression//expression/lambdaExpression", parser);
					return Stream.concat(creators.stream() //
							.filter(e -> !skipcreators.contains(e)) //
							.filter(e -> ((JavaParser.CreatorContext) e) //
									.getRuleContext(JavaParser.ClassCreatorRestContext.class, 0) //
									.getRuleContexts(JavaParser.ClassBodyContext.class).size() > 0) //
							.map(e -> {
								JavaParser.CreatorContext creator = (JavaParser.CreatorContext) e;
								String superClassName = creator.getRuleContext(JavaParser.CreatedNameContext.class, 0).getText();
								JavaClass anonymousClass = this.getAnonymousClass().setSuperClass(superClassName);

								JavaParser.ClassBodyContext cbctx = creator.getRuleContext(JavaParser.ClassCreatorRestContext.class, 0) //
										.getRuleContext(JavaParser.ClassBodyContext.class, 0);
								return anonymousClass.loadClass(cbctx, parser, imports);
							}), lambdaExpressions.stream() //
									.filter(e -> !skipclambdaExpressions.contains(e)) //
									.map(e -> {
										JavaParser.LambdaExpressionContext lectx = (JavaParser.LambdaExpressionContext) e;
										JavaClass anonymousClass = this.getAnonymousClass().setImports(imports);
										JavaMethod memberMethod = anonymousClass.originalThis.getMemberMethods("ABSTARCT_METHOD").loadMethod(lectx, parser, imports);
										return anonymousClass;
									}))
							.collect(Collectors.toList());
				}

				public class JavaBlock {
					public Map<String, JavaInstance> localFields;

					public JavaBlock() {
						this.localFields = new HashMap<>();
					}

					public JavaInstance getLocalFields(String name) {
						if (!this.localFields.containsKey(name)) {
							this.localFields.put(name, new JavaInstance());
						}
						return this.localFields.get(name);
					}
				}
			}

			public class JavaInstance {

				private Map<String, JavaClass> declaredType;
				private Map<String, JavaMethod> memberMethods;
				private Map<String, JavaInstance> memberFields;

				public JavaInstance() {
					this.declaredType = new HashMap<>();
					this.memberMethods = new HashMap<>();
					this.memberFields = new HashMap<>();
				}

				public void print(int layer) {
					if (this.declaredType.size() > 0 || this.memberMethods.size() > 0 || this.memberFields.size() > 0) {
						if (this.declaredType.size() > 0) {
							System.out.println(JavaProject.indentation(layer) + "[Declared Type]");
							this.declaredType.entrySet().stream() //
									.forEach(e -> System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue())));
						}
						if (this.memberMethods.size() > 0) {
							System.out.println(JavaProject.indentation(layer) + "[Member Methods]");
							this.memberMethods.entrySet().stream() //
									.forEach(e -> {
										System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
										e.getValue().print(layer + 1);
									});
							// this.superClass.print(layer + 2);
						}
						if (this.memberFields.size() > 0) {
							System.out.println(JavaProject.indentation(layer) + "[Member Fields]");
							this.memberFields.entrySet().stream() //
									.forEach(e -> {
										System.out.println(JavaProject.indentation(layer) + JavaProject.printPointer(e.getKey(), e.getValue()));
										e.getValue().print(layer + 1);
									});
							// this.superClass.print(layer + 2);
						}
					}
				}

				public JavaInstance setDeclaredType(String name) {
					this.declaredType.put(name, new JavaClass());
					return this;
				}

				public JavaMethod getMemberMethods(String name) {
					if (!this.memberMethods.containsKey(name)) {
						this.memberMethods.put(name, new JavaMethod());
					}
					return this.memberMethods.get(name);
				}

				public JavaInstance getMemberFields(String name) {
					if (!this.memberFields.containsKey(name)) {
						this.memberFields.put(name, new JavaInstance());
					}
					return this.memberFields.get(name);
				}

				private JavaInstance loadFieldType(JavaParser.VariableDeclaratorContext vdctx, JavaParser parser) {
					JavaParser.TypeTypeContext ttctx = vdctx.getParent().getParent().getRuleContext(JavaParser.TypeTypeContext.class, 0);
					String typeName = Stream.of(ttctx.getRuleContexts(JavaParser.ClassOrInterfaceTypeContext.class).stream() //
							.map(coictx -> {
								List<JavaParser.TypeArgumentsContext> tactxs = coictx.getRuleContexts(JavaParser.TypeArgumentsContext.class);
								String t = coictx.getText();
								if (tactxs.size() > 0) {
									t = t.substring(0, t.length() - tactxs.get(0).getText().length());
								}
								return t;
							}) //
							.collect(Collectors.toList()),
							ttctx.getRuleContexts(JavaParser.PrimitiveTypeContext.class).stream() //
									.map(ptctx -> {
										return ptctx.getText();
									}) //
									.collect(Collectors.toList()))
							.filter(e -> e.size() > 0).findFirst().get().get(0);
					return this.setDeclaredType(typeName);
				}

				public void resolveDeclaredType(JavaImports imports) {
					Iterator<String> i = this.declaredType.keySet().iterator();
					if (i.hasNext()) {
						String declaredTypeName = i.next();
						String[] typeNames = declaredTypeName.split("\\.");
						String typeName = typeNames.length == 0 ? declaredTypeName : typeNames[0];
						if (imports.importClasses.containsKey(typeName)) {
							JavaClass currentClass = imports.importClasses.get(typeName);
							for (int j = 1; j < typeNames.length; j++) {
								typeName = typeNames[j];
								JavaClass getClass = currentClass.innerClasses.get(typeName);
								if (Objects.isNull(getClass)) {
									getClass = currentClass.getInnerClass(typeName);
								}
								currentClass = getClass;
							}
							this.declaredType.put(typeName, currentClass);
						} else if (JavaPackage.this.publicClasses.containsKey(typeName)) {
							JavaClass currentClass = JavaPackage.this.publicClasses.get(typeName);
							for (int j = 1; j < typeNames.length; j++) {
								typeName = typeNames[j];
								JavaClass getClass = currentClass.innerClasses.get(typeName);
								if (Objects.isNull(getClass)) {
									getClass = currentClass.getInnerClass(typeName);
								}
								currentClass = getClass;
							}
							this.declaredType.put(typeName, currentClass);
						} else {
							// this.declaredType.remove(typeName);
						}
						if (typeNames.length > 1) {
							this.declaredType.remove(declaredTypeName);
						}
					}
				}
			}
		}

	}

	private static String printPointer(String name, Object obj) {
		return name + " @" + Integer.toHexString(obj.hashCode());
	}

	private static void printChildlen(ParseTree context, int layer, int max_layer) {
		if (layer == max_layer) {
			return;
		}
		if (context.getChildCount() == 0) {
			System.out.println(indentation(layer) + "{" + context.getClass().getCanonicalName() + "} <= '" + context + "'");
		} else {
			System.out.println(indentation(layer) + "{" + context.getClass().getCanonicalName() + "}");
		}
		for (int i = 0; i < context.getChildCount(); ++i) {
			ParseTree child = context.getChild(i);
			printChildlen(child, layer + 1, max_layer);
		}
	}

	private static String indentation(int n) {
		return String.join("", Collections.nCopies(n, "  "));
	}

}