package com.java.parser.project;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;

import org.antlr.v4.runtime.tree.ParseTree;

import java.util.HashMap;
import java.util.Iterator;

import com.java.parser.antlr.JavaParser;
import com.java.parser.project.JavaProject.JavaPackage.JavaImports;

public class JavaProject {
	private List<JavaImports> importsList;
	private Map<String, JavaPackage> packages;

	public JavaProject() {
		this.packages = new HashMap<>();
		this.importsList = new ArrayList<>();
	}

	public void print(int layer) {
		System.out.println(JavaProject.indentation(layer) + "[Project]");
		System.out.println(JavaProject.indentation(layer + 1) + " @" + Integer.toHexString(this.hashCode()));
		System.out.println(JavaProject.indentation(layer + 2) + "[Packages]");
		this.packages.entrySet().stream().forEach(e -> {
			System.out.println(JavaProject.indentation(layer + 3) + e.getKey() + " @"
					+ Integer.toHexString(e.getValue().hashCode()));
			e.getValue().print(layer + 3);
		});
	}

	public void load(JavaParser parser) {
		JavaParser.CompilationUnitContext cuctx = parser.compilationUnit();
		this.loadPackage(cuctx);
	}

	public void addPackage(String name) {
		this.packages.put(name, new JavaPackage());
	}

	public JavaPackage getPackage(String name) {
		if (!this.packages.containsKey(name)) {
			this.addPackage(name);
		}
		return this.packages.get(name);
	}

	public void loadPackage(JavaParser.CompilationUnitContext cuctx) {
		JavaParser.PackageDeclarationContext ctx = cuctx.getChild(JavaParser.PackageDeclarationContext.class, 0);
		String name = ctx.getChild(1).getText();
		JavaPackage _package = this.getPackage(name);
		JavaImports imports = loadImports(_package, cuctx);

		_package.loadPublicClass(cuctx, imports);
		_package.loadDefaultClass(cuctx, imports);
	}

	public JavaPackage.JavaImports loadImports(JavaPackage _package, JavaParser.CompilationUnitContext cuctx) {
		JavaPackage.JavaImports imports = _package.new JavaImports();
		List<JavaParser.ImportDeclarationContext> idctxs = cuctx
				.getRuleContexts(JavaParser.ImportDeclarationContext.class);

		idctxs.stream().forEach(idctx -> {
			String PackagePath = idctx.getChild(1).getText();
			String lastPackagePath = idctx.getChild(1).getChild(idctx.getChild(1).getChildCount() - 1).getText();
			if (lastPackagePath.matches("[A-Z][a-zA-Z0-9_]*")) {
				String packageName = PackagePath.substring(0, PackagePath.length() - lastPackagePath.length() - 1);
				String className = lastPackagePath;
				imports.importClasses.put(className, this.getPackage(packageName).getPublicClass(className));
			} else {
				String packageName = PackagePath;
				imports.importPackages.put(packageName, this.getPackage(packageName));
			}
		});
		importsList.add(imports);
		return imports;
	}

	public void resolveImports() {
		importsList.stream().forEach(imports -> {
			Predicate<Entry<String, JavaPackage>> isQualified = e -> packages.containsKey(e.getKey())
					&& packages.get(e.getKey()).publicClasses.size() > 0;
			imports.importPackages.entrySet().stream().filter(isQualified).forEach(e -> {
				e.getValue().publicClasses.entrySet().stream()
						.forEach(e1 -> imports.importClasses.put(e1.getKey(), e1.getValue()));
			});
			imports.importPackages.entrySet().removeIf(isQualified);
		});
		packages.entrySet().stream().forEach(e -> {
			e.getValue().defaultClasses.entrySet().forEach(e1 -> e1.getValue().resolveSuperClass());
			e.getValue().publicClasses.entrySet().forEach(e1 -> e1.getValue().resolveSuperClass());
		});
	}

	public class JavaPackage {
		private Map<String, JavaClass> publicClasses;
		private Map<String, JavaClass> defaultClasses;

		public JavaPackage() {
			this.publicClasses = new HashMap<>();
			this.defaultClasses = new HashMap<>();
		}

		public void print(int layer) {
			if (this.publicClasses.size() > 0) {
				System.out.println(JavaProject.indentation(layer + 1) + "[Public Classes]");
				this.publicClasses.entrySet().stream().forEach(e -> {
					System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
							+ Integer.toHexString(e.getValue().hashCode()));
					e.getValue().print(layer + 2);
				});
			}
			if (this.defaultClasses.size() > 0) {
				System.out.println(JavaProject.indentation(layer + 1) + "[Default Classes]");
				this.defaultClasses.entrySet().stream().forEach(e -> {
					System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
							+ Integer.toHexString(e.getValue().hashCode()));
					e.getValue().print(layer + 2);
				});
			}
		}

		public void addPublicClass(String name) {
			this.publicClasses.put(name, new JavaClass());
		}

		public JavaClass getPublicClass(String name) {
			if (!this.publicClasses.containsKey(name)) {
				this.addPublicClass(name);
			}
			return this.publicClasses.get(name);
		}

		public void loadPublicClass(JavaParser.CompilationUnitContext cuctx, JavaImports imports) {

			cuctx.getRuleContexts(JavaParser.TypeDeclarationContext.class).stream()
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassOrInterfaceModifierContext.class).size() > 0)
					.filter(ctx -> ctx.getChild(JavaParser.ClassOrInterfaceModifierContext.class, 0).getText()
							.equals("public"))
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() > 0).limit(1)
					.forEach(ctx -> {
						JavaParser.ClassDeclarationContext classDeclarationContext = ctx
								.getChild(JavaParser.ClassDeclarationContext.class, 0);
						JavaProject.printChildlen(classDeclarationContext, 0, 8);
						System.out.println("");
						String name = classDeclarationContext.getChild(1).getText();
						JavaClass publicClass = this.getPublicClass(name).setImports(imports);
						publicClass.loadStaticMethod(classDeclarationContext);
						publicClass.loadInnerClass(classDeclarationContext);
						publicClass.loadSuperClass(classDeclarationContext);
					});
		}

		public void addDefaultClass(String name) {
			this.defaultClasses.put(name, new JavaClass());
		}

		public JavaClass getDefaultClass(String name) {
			if (!this.defaultClasses.containsKey(name)) {
				this.addDefaultClass(name);
			}
			return this.defaultClasses.get(name);
		}

		public void loadDefaultClass(JavaParser.CompilationUnitContext cuctx, JavaImports imports) {
			cuctx.getRuleContexts(JavaParser.TypeDeclarationContext.class).stream()
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassOrInterfaceModifierContext.class).size() == 0)
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() > 0)
					.forEach(ctx -> {
						JavaParser.ClassDeclarationContext classDeclarationContext = ctx
								.getChild(JavaParser.ClassDeclarationContext.class, 0);
						String name = classDeclarationContext.getChild(1).getText();
						JavaClass defaultClass = this.getDefaultClass(name).setImports(imports);
						defaultClass.loadStaticMethod(classDeclarationContext);
						defaultClass.loadInnerClass(classDeclarationContext);
						defaultClass.loadSuperClass(classDeclarationContext);
					});
			cuctx.getRuleContexts(JavaParser.TypeDeclarationContext.class).stream()
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassOrInterfaceModifierContext.class).size() > 0)
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() > 0)
					.filter(ctx -> !ctx.getChild(JavaParser.ClassOrInterfaceModifierContext.class, 0).getText()
							.equals("public"))
					.forEach(ctx -> {
						JavaParser.ClassDeclarationContext classDeclarationContext = ctx
								.getChild(JavaParser.ClassDeclarationContext.class, 0);
						String name = classDeclarationContext.getChild(1).getText();
						JavaClass defaultClass = this.getDefaultClass(name).setImports(imports);
						defaultClass.loadStaticMethod(classDeclarationContext);
						defaultClass.loadInnerClass(classDeclarationContext);
						defaultClass.loadSuperClass(classDeclarationContext);
					});
		}

		public class JavaImports {
			public Map<String, JavaPackage> importPackages;
			public Map<String, JavaClass> importClasses;

			public JavaImports() {
				this.importPackages = new HashMap<>();
				this.importClasses = new HashMap<>();
			}

			public void print(int layer) {
				if (this.importClasses.size() > 0) {
					System.out.println(JavaProject.indentation(layer) + "[Imported Classes]");
					this.importClasses.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 1) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
						// e.getValue().print(layer + 1);
					});
				}
				if (this.importPackages.size() > 0) {
					System.out.println(JavaProject.indentation(layer) + "[Imported Packages]");
					this.importPackages.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 1) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
						// e.getValue().print(layer + 1);
					});
				}
			}
		}

		public class JavaClass {
			private JavaImports imports;

			private Map<String, JavaClass> superClass;

			private Map<String, JavaClass> innerClasses;

			private Map<String, JavaMethod> staticMethods;
			private Map<String, JavaInstance> staticFields;

			public JavaClass() {
				this.superClass = new HashMap<>();
				this.imports = new JavaImports();
				this.innerClasses = new HashMap<>();

				this.staticMethods = new HashMap<>();
				this.staticFields = new HashMap<>();
			}

			public void print(int layer) {
				this.imports.print(layer + 1);
				if (this.superClass.size() > 0) {
					System.out.println(JavaProject.indentation(layer + 1) + "[Super Class]");
					this.superClass.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
					});
					// this.superClass.print(layer + 2);
				}
				if (this.staticMethods.size() > 0) {
					System.out.println(JavaProject.indentation(layer + 1) + "[Static Methods]");
					this.staticMethods.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
					});
					// this.superClass.print(layer + 2);
				}
				if (this.innerClasses.size() > 0) {
					System.out.println(JavaProject.indentation(layer + 1) + "[Inner Classes]");
					this.innerClasses.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
						e.getValue().print(layer + 2);
					});
				}
			}

			public JavaClass setImports(JavaImports imports) {
				this.imports = imports;
				return this;
			}

			public void addInnerClass(String name) {
				this.innerClasses.put(name, new JavaClass());
			}

			public JavaClass getInnerClass(String name) {
				if (!this.innerClasses.containsKey(name)) {
					this.addInnerClass(name);
				}
				return this.innerClasses.get(name);
			}

			public void loadInnerClass(JavaParser.ClassDeclarationContext ctx) {
				ctx.getRuleContexts(JavaParser.ClassBodyContext.class).stream().forEach(cbctx -> cbctx
						.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream()
						.forEach(cbdctx -> cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream()
								.forEach(mdctx -> mdctx.getRuleContexts(JavaParser.ClassDeclarationContext.class)
										.stream().forEach(cdctx -> {
											String name = cdctx.getChild(1).getText();
											JavaClass innerClass = this.getInnerClass(name).setImports(imports);
											innerClass.loadInnerClass(cdctx);
											innerClass.loadSuperClass(cdctx);
										}))));
			}

			public void setSuperClass(String name) {
				this.superClass.put(name, new JavaClass());
			}

			public void resolveSuperClass() {
				Iterator<String> i = this.superClass.keySet().iterator();//
				if (i.hasNext()) {
					String superClassName = i.next();
					String[] superClassNames = superClassName.split("\\.");
					String className = superClassNames.length == 0 ? superClassName : superClassNames[0];
					if (this.imports.importClasses.containsKey(className)) {
						JavaClass currentClass = this.imports.importClasses.get(className);
						for (int j = 1; j < superClassNames.length; j++) {
							className = superClassNames[j];
							currentClass = currentClass.innerClasses.get(className);
						}
						this.superClass.put(className, currentClass);
					} else if (JavaPackage.this.publicClasses.containsKey(className)) {
						JavaClass currentClass = JavaPackage.this.publicClasses.get(className);
						for (int j = 1; j < superClassNames.length; j++) {
							className = superClassNames[j];
							currentClass = currentClass.innerClasses.get(className);
						}
						this.superClass.put(className, currentClass);
					}
					this.superClass.remove(superClassName);
				}

				this.innerClasses.entrySet().stream().forEach(e -> e.getValue().resolveSuperClass());
			}

			public void loadSuperClass(JavaParser.ClassDeclarationContext ctx) {
				if (ctx.getChildCount() > 3) {
					if (ctx.getChild(2).getText().equals("extends")) {
						String superClassName = ctx.getChild(3).getText();
						this.setSuperClass(superClassName);
					}
				}
			}

			public void addStaticMethods(String name) {
				this.staticMethods.put(name, new JavaMethod());
			}

			public JavaMethod getStaticMethods(String name) {
				if (!this.staticMethods.containsKey(name)) {
					this.addStaticMethods(name);
				}
				return this.staticMethods.get(name);
			}

			public void loadStaticMethod(JavaParser.ClassDeclarationContext ctx) {
				ctx.getRuleContexts(JavaParser.ClassBodyContext.class).stream().forEach(cbctx -> {
					cbctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream()
							.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() > 0)
							.filter(cbdctx -> cbdctx.getChild(JavaParser.ModifierContext.class, 0).getText()
									.equals("public"))
							.forEach(cbdctx -> {
								cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream()
										.forEach(mdctx -> {
											mdctx.getRuleContexts(JavaParser.MethodDeclarationContext.class).stream()
													.forEach(mtdctx -> {
														String name = mtdctx.getChild(1).getText();
														JavaMethod staticMethod = this.getStaticMethods(name);
													});
										});
							});
				});
			}

			public void addStaticFields(String name) {
				this.staticFields.put(name, new JavaInstance());
			}

			public class JavaMethod {
				private Map<String, JavaClass> anonymousClasses;
				private Map<String, JavaMethod> callMethods;

				public JavaMethod() {
					this.anonymousClasses = new HashMap<>();
					this.callMethods = new HashMap<>();
				}

				public String addAnonymousClasses() {
					String name = "#" + this.anonymousClasses.size();
					this.anonymousClasses.put(name, new JavaClass());
					return name;
				}

				public void addCallMethods(String name) {
					this.callMethods.put(name, new JavaMethod());
				}

				public class JavaBlock {
					public Map<String, JavaInstance> localFields;

					public JavaBlock() {
						this.localFields = new HashMap<>();
					}

					public void addLocalFields(String name) {
						this.localFields.put(name, new JavaInstance());
					}
				}
			}

			public class JavaInstance {
				private Map<String, JavaMethod> menberMethods;
				private Map<String, JavaInstance> menberFields;

				public JavaInstance() {
					this.menberMethods = new HashMap<>();
					this.menberFields = new HashMap<>();
				}

				public void addMenberMethods(String name) {
					this.menberMethods.put(name, new JavaMethod());
				}

				public void addMenberFields(String name) {
					this.menberFields.put(name, new JavaInstance());
				}
			}
		}
	}

	private static void printChildlen(ParseTree context, int layer) {
		printChildlen(context, layer, 5);
	}

	private static void printChildlen(ParseTree context, int layer, int max_layer) {
		if (layer == max_layer) {
			return;
		}
		if (context.getChildCount() == 0) {
			System.out.println(
					indentation(layer) + "{" + context.getClass().getCanonicalName() + "} <= '" + context + "'");
		} else {
			System.out.println(indentation(layer) + "{" + context.getClass().getCanonicalName() + "}");
		}
		for (int i = 0; i < context.getChildCount(); ++i) {
			ParseTree child = context.getChild(i);
			printChildlen(child, layer + 1, max_layer);
		}
	}

	private static String indentation(int n) {
		return String.join("", Collections.nCopies(n, "  "));
	}

}