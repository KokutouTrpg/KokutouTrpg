package com.java.parser.project;

import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.function.Predicate;

import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.xpath.XPath;

import java.util.HashMap;
import java.util.Iterator;

import com.java.parser.antlr.JavaParser;
import com.java.parser.project.JavaProject.JavaPackage.JavaImports;

public class JavaProject {
	private List<JavaImports> importsList;
	private Map<String, JavaPackage> packages;

	public JavaProject() {
		this.packages = new HashMap<>();
		this.importsList = new ArrayList<>();
	}

	public void print(int layer) {
		System.out.println(JavaProject.indentation(layer) + "[Project]");
		System.out.println(JavaProject.indentation(layer + 1) + " @" + Integer.toHexString(this.hashCode()));
		System.out.println(JavaProject.indentation(layer + 2) + "[Packages]");
		this.packages.entrySet().stream().forEach(e -> {
			System.out.println(JavaProject.indentation(layer + 3) + e.getKey() + " @"
					+ Integer.toHexString(e.getValue().hashCode()));
			e.getValue().print(layer + 3);
		});
	}

	public void load(JavaParser parser) {
		JavaParser.CompilationUnitContext cuctx = parser.compilationUnit();
		this.loadPackage(cuctx, parser);
	}

	public void addPackage(String name) {
		this.packages.put(name, new JavaPackage());
	}

	public JavaPackage getPackage(String name) {
		if (!this.packages.containsKey(name)) {
			this.addPackage(name);
		}
		return this.packages.get(name);
	}

	public void loadPackage(JavaParser.CompilationUnitContext cuctx, JavaParser parser) {
		JavaParser.PackageDeclarationContext ctx = cuctx.getChild(JavaParser.PackageDeclarationContext.class, 0);
		String name = ctx.getChild(1).getText();
		JavaPackage _package = this.getPackage(name);
		JavaImports imports = loadImports(cuctx, parser, _package);

		_package.loadPublicClass(cuctx, parser, imports);
		_package.loadDefaultClass(cuctx, parser, imports);
	}

	public JavaPackage.JavaImports loadImports(JavaParser.CompilationUnitContext cuctx, JavaParser parser,
			JavaPackage _package) {
		JavaPackage.JavaImports imports = _package.new JavaImports();
		List<JavaParser.ImportDeclarationContext> idctxs = cuctx
				.getRuleContexts(JavaParser.ImportDeclarationContext.class);

		idctxs.stream().forEach(idctx -> {
			String PackagePath = idctx.getChild(1).getText();
			String lastPackagePath = idctx.getChild(1).getChild(idctx.getChild(1).getChildCount() - 1).getText();
			if (lastPackagePath.matches("[A-Z][a-zA-Z0-9_]*")) {
				String packageName = PackagePath.substring(0, PackagePath.length() - lastPackagePath.length() - 1);
				String className = lastPackagePath;

				imports.importClasses.put(className, this.getPackage(packageName).getPublicClass(className));
			} else {
				String packageName = PackagePath;
				imports.importPackages.put(packageName, this.getPackage(packageName));
			}
		});
		/*
		 * can add java basic package (java.lang) but only class
		 * imports.importClasses.put("Runnable",
		 * this.getPackage("java.lang").getPublicClass("Runnable"));
		 */
		importsList.add(imports);
		return imports;
	}

	public void resolveImports() {
		importsList.stream().forEach(imports -> {
			Predicate<Entry<String, JavaPackage>> isQualified = e -> packages.containsKey(e.getKey())
					&& packages.get(e.getKey()).publicClasses.size() > 0;
			imports.importPackages.entrySet().stream().filter(isQualified).forEach(e -> {
				e.getValue().publicClasses.entrySet().stream()
						.forEach(e1 -> imports.importClasses.put(e1.getKey(), e1.getValue()));
			});
			imports.importPackages.entrySet().removeIf(isQualified);
		});
		packages.entrySet().stream().forEach(e -> {
			e.getValue().defaultClasses.entrySet().forEach(e1 -> e1.getValue().resolveSuperClass());
			e.getValue().publicClasses.entrySet().forEach(e1 -> e1.getValue().resolveSuperClass());
		});
		packages.entrySet().stream().forEach(e -> {
			e.getValue().defaultClasses.entrySet().forEach(e1 -> e1.getValue().resolveInheritance());
			e.getValue().publicClasses.entrySet().forEach(e1 -> e1.getValue().resolveInheritance());
		});
	}

	public class JavaPackage {
		private Map<String, JavaClass> publicClasses;
		private Map<String, JavaClass> defaultClasses;

		public JavaPackage() {
			this.publicClasses = new HashMap<>();
			this.defaultClasses = new HashMap<>();
		}

		public void print(int layer) {
			if (this.publicClasses.size() > 0) {
				System.out.println(JavaProject.indentation(layer + 1) + "[Public Classes]");
				this.publicClasses.entrySet().stream().forEach(e -> {
					System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
							+ Integer.toHexString(e.getValue().hashCode()));
					e.getValue().print(layer + 2);
				});
			}
			if (this.defaultClasses.size() > 0) {
				System.out.println(JavaProject.indentation(layer + 1) + "[Default Classes]");
				this.defaultClasses.entrySet().stream().forEach(e -> {
					System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
							+ Integer.toHexString(e.getValue().hashCode()));
					e.getValue().print(layer + 2);
				});
			}
		}

		public void addPublicClass(String name) {
			this.publicClasses.put(name, new JavaClass());
		}

		public JavaClass getPublicClass(String name) {
			if (!this.publicClasses.containsKey(name)) {
				this.addPublicClass(name);
			}
			return this.publicClasses.get(name);
		}

		public void loadPublicClass(JavaParser.CompilationUnitContext cuctx, JavaParser parser, JavaImports imports) {

			cuctx.getRuleContexts(JavaParser.TypeDeclarationContext.class).stream()
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassOrInterfaceModifierContext.class).size() > 0)
					.filter(ctx -> ctx.getChild(JavaParser.ClassOrInterfaceModifierContext.class, 0).getText()
							.equals("public"))
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() > 0).limit(1)
					.forEach(ctx -> {
						JavaParser.ClassDeclarationContext classDeclarationContext = ctx
								.getChild(JavaParser.ClassDeclarationContext.class, 0);

						String name = classDeclarationContext.getChild(1).getText();
						JavaClass publicClass = this.getPublicClass(name).setImports(imports);
						JavaParser.ClassBodyContext cbctx = classDeclarationContext
								.getRuleContext(JavaParser.ClassBodyContext.class, 0);
						publicClass.loadStaticMethod(cbctx, parser, imports);
						publicClass.loadStaticField(cbctx, parser);
						publicClass.loadMember(cbctx, parser, imports);
						publicClass.loadInnerClass(cbctx, parser, imports);
						publicClass.loadSuperClass(cbctx, parser);
					});
		}

		public void addDefaultClass(String name) {
			this.defaultClasses.put(name, new JavaClass());
		}

		public JavaClass getDefaultClass(String name) {
			if (!this.defaultClasses.containsKey(name)) {
				this.addDefaultClass(name);
			}
			return this.defaultClasses.get(name);
		}

		public void loadDefaultClass(JavaParser.CompilationUnitContext cuctx, JavaParser parser, JavaImports imports) {
			cuctx.getRuleContexts(JavaParser.TypeDeclarationContext.class).stream().filter(
					ctx -> (ctx.getRuleContexts(JavaParser.ClassOrInterfaceModifierContext.class).size() == 0) || (!ctx
							.getChild(JavaParser.ClassOrInterfaceModifierContext.class, 0).getText().equals("public")))
					.filter(ctx -> ctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() > 0)
					.forEach(ctx -> {
						JavaParser.ClassDeclarationContext classDeclarationContext = ctx
								.getChild(JavaParser.ClassDeclarationContext.class, 0);
						String name = classDeclarationContext.getChild(1).getText();
						JavaClass defaultClass = this.getDefaultClass(name).setImports(imports);
						JavaParser.ClassBodyContext cbctx = classDeclarationContext
								.getRuleContext(JavaParser.ClassBodyContext.class, 0);
						defaultClass.loadStaticMethod(cbctx, parser, imports);
						defaultClass.loadStaticField(cbctx, parser);
						defaultClass.loadMember(cbctx, parser, imports);
						defaultClass.loadInnerClass(cbctx, parser, imports);
						defaultClass.loadSuperClass(cbctx, parser);
					});

		}

		public class JavaImports {
			public Map<String, JavaPackage> importPackages;
			public Map<String, JavaClass> importClasses;

			public JavaImports() {
				this.importPackages = new HashMap<>();
				this.importClasses = new HashMap<>();
			}

			public void print(int layer) {
				if (this.importClasses.size() > 0) {
					System.out.println(JavaProject.indentation(layer) + "[Imported Classes]");
					this.importClasses.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 1) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
						// e.getValue().print(layer + 1);
					});
				}
				if (this.importPackages.size() > 0) {
					System.out.println(JavaProject.indentation(layer) + "[Imported Packages]");
					this.importPackages.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 1) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
						// e.getValue().print(layer + 1);
					});
				}
			}
		}

		public class JavaClass {
			private JavaImports imports;

			private Map<String, JavaClass> superClass;

			private Map<String, JavaClass> innerClasses;

			private Map<String, JavaMethod> staticMethods;
			private Map<String, JavaInstance> staticFields;

			private JavaInstance originalThis;

			public JavaClass() {
				this.superClass = new HashMap<>();
				this.imports = new JavaImports();
				this.innerClasses = new HashMap<>();

				this.staticMethods = new HashMap<>();
				this.staticFields = new HashMap<>();

				this.originalThis = new JavaInstance();
			}

			public void print(int layer) {
				this.imports.print(layer + 1);
				if (this.superClass.size() > 0) {
					System.out.println(JavaProject.indentation(layer + 1) + "[Super Class]");
					this.superClass.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
					});
					// this.superClass.print(layer + 2);
				}
				if (this.staticMethods.size() > 0 || this.staticFields.size() > 0) {
					System.out.println(JavaProject.indentation(layer + 1) + "[Class Static]");
					if (this.staticMethods.size() > 0) {
						System.out.println(JavaProject.indentation(layer + 2) + "[Static Methods]");
						this.staticMethods.entrySet().stream().forEach(e -> {
							System.out.println(JavaProject.indentation(layer + 3) + e.getKey() + " @"
									+ Integer.toHexString(e.getValue().hashCode()));
							e.getValue().print(layer + 3);
						});
						// this.superClass.print(layer + 2);
					}
					if (this.staticFields.size() > 0) {
						System.out.println(JavaProject.indentation(layer + 2) + "[Static Fields]");
						this.staticFields.entrySet().stream().forEach(e -> {
							System.out.println(JavaProject.indentation(layer + 3) + e.getKey() + " @"
									+ Integer.toHexString(e.getValue().hashCode()));
						});
						// this.superClass.print(layer + 2);
					}
				}
				this.originalThis.print(layer);
				if (this.innerClasses.size() > 0) {
					System.out.println(JavaProject.indentation(layer + 1) + "[Inner Classes]");
					this.innerClasses.entrySet().stream().forEach(e -> {
						System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
								+ Integer.toHexString(e.getValue().hashCode()));
						e.getValue().print(layer + 2);
					});
				}
			}

			public JavaClass setImports(JavaImports imports) {
				this.imports = imports;
				return this;
			}

			public void addInnerClass(String name) {
				this.innerClasses.put(name, new JavaClass());
			}

			public JavaClass getInnerClass(String name) {
				if (!this.innerClasses.containsKey(name)) {
					this.addInnerClass(name);
				}
				return this.innerClasses.get(name);
			}

			public void loadInnerClass(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
				ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream().forEach(cbdctx -> cbdctx
						.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream()
						.filter(mdctx -> mdctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).size() > 0)
						.forEach(mdctx -> mdctx.getRuleContexts(JavaParser.ClassDeclarationContext.class).stream()
								.forEach(cdctx -> {
									String name = cdctx.getChild(1).getText();
									JavaClass innerClass = this.getInnerClass(name).setImports(imports);
									JavaParser.ClassBodyContext cbctx = cdctx
											.getRuleContext(JavaParser.ClassBodyContext.class, 0);
									innerClass.loadStaticMethod(cbctx, parser, imports);
									innerClass.loadStaticField(cbctx, parser);
									innerClass.loadMember(cbctx, parser, imports);
									innerClass.loadInnerClass(cbctx, parser, imports);
									innerClass.loadSuperClass(cbctx, parser);
								})));
			}

			public void setSuperClass(String name) {
				this.superClass.put(name, new JavaClass());
			}

			public void resolveSuperClass() {
				Iterator<String> i = this.superClass.keySet().iterator();
				if (i.hasNext()) {
					String superClassName = i.next();
					String[] superClassNames = superClassName.split("\\.");
					String className = superClassNames.length == 0 ? superClassName : superClassNames[0];
					if (this.imports.importClasses.containsKey(className)) {
						JavaClass currentClass = this.imports.importClasses.get(className);
						for (int j = 1; j < superClassNames.length; j++) {
							className = superClassNames[j];
							JavaClass getClass = currentClass.innerClasses.get(className);
							if (Objects.isNull(getClass)) {
								getClass = currentClass.getInnerClass(className);
							}
							currentClass = getClass;
						}
						this.superClass.put(className, currentClass);
					} else if (JavaPackage.this.publicClasses.containsKey(className)) {
						JavaClass currentClass = JavaPackage.this.publicClasses.get(className);
						for (int j = 1; j < superClassNames.length; j++) {
							className = superClassNames[j];
							JavaClass getClass = currentClass.innerClasses.get(className);
							if (Objects.isNull(getClass)) {
								getClass = currentClass.getInnerClass(className);
							}
							currentClass = getClass;
						}
						this.superClass.put(className, currentClass);
					} else {
						this.superClass.remove(superClassName);
					}
					if (superClassNames.length > 1) {
						this.superClass.remove(superClassName);
					}
				}

				this.innerClasses.entrySet().stream().forEach(e -> e.getValue().resolveSuperClass());

				this.staticMethods.entrySet().stream().forEach(e2 -> e2.getValue().anonymousClasses.entrySet().stream()
						.forEach(e3 -> e3.getValue().resolveSuperClass()));
				this.originalThis.memberMethods.entrySet().stream().forEach(e2 -> e2.getValue().anonymousClasses
						.entrySet().stream().forEach(e3 -> e3.getValue().resolveSuperClass()));
			}

			public void resolveInheritance() {
				Iterator<String> i = this.superClass.keySet().iterator();
				if (i.hasNext()) {
					String superClassName = i.next();
					JavaClass getClass = this.superClass.get(superClassName);
					getClass.resolveInheritance();
					getClass.staticMethods.entrySet().stream()
							// .filter(e -> !this.staticMethods.containsKey(e.getKey()))
							.forEach(e -> System.out.println(e.getKey()));
					getClass.staticMethods.entrySet().stream().filter(e -> !this.staticMethods.containsKey(e.getKey()))
							.forEach(e -> this.staticMethods.put(e.getKey(), e.getValue()));
					getClass.staticFields.entrySet().stream().filter(e -> !this.staticFields.containsKey(e.getKey()))
							.forEach(e -> this.staticFields.put(e.getKey(), e.getValue()));
					getClass.originalThis.memberMethods.entrySet().stream()
							.filter(e -> !this.originalThis.memberMethods.containsKey(e.getKey()))
							.forEach(e -> this.originalThis.memberMethods.put(e.getKey(), e.getValue()));
					getClass.originalThis.memberFields.entrySet().stream()
							.filter(e -> !this.originalThis.memberFields.containsKey(e.getKey()))
							.forEach(e -> this.originalThis.memberFields.put(e.getKey(), e.getValue()));
				}
				this.innerClasses.entrySet().stream().forEach(e -> e.getValue().resolveInheritance());
				this.staticMethods.entrySet().stream().forEach(e2 -> e2.getValue().anonymousClasses.entrySet().stream()
						.forEach(e3 -> e3.getValue().resolveInheritance()));
				this.originalThis.memberMethods.entrySet().stream().forEach(e2 -> e2.getValue().anonymousClasses
						.entrySet().stream().forEach(e3 -> e3.getValue().resolveInheritance()));

			}

			public void loadSuperClass(JavaParser.ClassBodyContext ctx, JavaParser parser) {
				if (ctx.parent.getChildCount() > 3) {
					if (ctx.parent.getChild(2).getText().equals("extends")) {
						String superClassName = ctx.parent.getChild(3).getText();
						this.setSuperClass(superClassName);
					}
				}
			}

			public void addStaticMethods(String name) {
				this.staticMethods.put(name, new JavaMethod());
			}

			public JavaMethod getStaticMethods(String name) {
				if (!this.staticMethods.containsKey(name)) {
					this.addStaticMethods(name);
				}
				return this.staticMethods.get(name);
			}

			public void loadStaticMethod(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
				ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream()
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() > 0)
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).stream()
								.filter(mctx -> mctx.getText().equals("static")).count() > 0)
						.forEach(cbdctx -> {
							cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream()
									.forEach(mdctx -> {
										mdctx.getRuleContexts(JavaParser.MethodDeclarationContext.class).stream()
												.forEach(mtdctx -> {
													String name = mtdctx.getChild(1).getText();
													JavaMethod staticMethod = this.getStaticMethods(name);
													staticMethod.loadAnonymousClass(mtdctx, parser, imports);
												});
									});
						});

			}

			public void addStaticFields(String name) {
				this.staticFields.put(name, new JavaInstance());
			}

			public JavaInstance getStaticFields(String name) {
				if (!this.staticFields.containsKey(name)) {
					this.addStaticFields(name);
				}
				return this.staticFields.get(name);
			}

			public void loadStaticField(JavaParser.ClassBodyContext ctx, JavaParser parser) {
				ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream()
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() > 0)
						.filter(cbdctx -> cbdctx.getRuleContexts(JavaParser.ModifierContext.class).stream()
								.filter(mctx -> mctx.getText().equals("static")).count() > 0)
						.forEach(cbdctx -> {
							cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream()
									.forEach(mdctx -> {
										mdctx.getRuleContexts(JavaParser.FieldDeclarationContext.class).stream()
												.forEach(ftdctx -> {
													ftdctx.getRuleContext(JavaParser.VariableDeclaratorsContext.class,
															0)
															.getRuleContexts(JavaParser.VariableDeclaratorContext.class)
															.stream().forEach(vdctx -> {
																String name = vdctx.getRuleContext(
																		JavaParser.VariableDeclaratorIdContext.class, 0)
																		.getText();
																JavaInstance staticField = this.getStaticFields(name);
															});
												});
									});
						});
			}

			public void loadMember(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
				this.originalThis.loadMemberMethod(ctx, parser, imports);
				this.originalThis.loadMemberField(ctx, parser);
			}

			public class JavaMethod {
				private Map<String, JavaClass> anonymousClasses;
				private Map<String, JavaMethod> callMethods;

				public JavaMethod() {
					this.anonymousClasses = new HashMap<>();
					this.callMethods = new HashMap<>();
				}

				public void print(int layer) {
					if (this.anonymousClasses.size() > 0) {
						System.out.println(JavaProject.indentation(layer + 1) + "[Anonymous Classes]");
						this.anonymousClasses.entrySet().stream().forEach(e -> {
							System.out.println(JavaProject.indentation(layer + 2) + e.getKey() + " @"
									+ Integer.toHexString(e.getValue().hashCode()));
							e.getValue().print(layer + 2);
						});
						// this.superClass.print(layer + 2);
					}
				}

				public String addAnonymousClasses() {
					String name = "#" + this.anonymousClasses.size();
					this.anonymousClasses.put(name, new JavaClass());
					return name;
				}

				public JavaClass getAnonymousClasses() {
					String name = this.addAnonymousClasses();
					return this.anonymousClasses.get(name);
				}

				public void addCallMethods(String name) {
					this.callMethods.put(name, new JavaMethod());
				}

				public JavaMethod getCallMethods(String name) {
					if (!this.callMethods.containsKey(name)) {
						this.addCallMethods(name);
					}
					return this.callMethods.get(name);
				}

				public void loadAnonymousClass(JavaParser.MethodDeclarationContext ctx, JavaParser parser,
						JavaImports imports) {
					Collection<ParseTree> creators = XPath.findAll(ctx, "//creator", parser);
					Collection<ParseTree> skipcreators = XPath.findAll(ctx, "//creator/classCreatorRest//creator",
							parser);
					creators.stream().filter(e -> !skipcreators.contains(e))
							.filter(e -> ((JavaParser.CreatorContext) e)
									.getRuleContext(JavaParser.ClassCreatorRestContext.class, 0)
									.getRuleContexts(JavaParser.ClassBodyContext.class).size() > 0)
							.forEach(e -> {
								JavaParser.CreatorContext creator = (JavaParser.CreatorContext) e;
								JavaClass anonymousClass = this.getAnonymousClasses().setImports(imports);
								String superClassName = creator.getRuleContext(JavaParser.CreatedNameContext.class, 0)
										.getText();
								anonymousClass.setSuperClass(superClassName);

								JavaParser.ClassBodyContext cbctx = creator
										.getRuleContext(JavaParser.ClassCreatorRestContext.class, 0)
										.getRuleContext(JavaParser.ClassBodyContext.class, 0);
								anonymousClass.loadStaticMethod(cbctx, parser, imports);
								anonymousClass.loadStaticField(cbctx, parser);
								anonymousClass.loadMember(cbctx, parser, imports);
								anonymousClass.loadInnerClass(cbctx, parser, imports);
								anonymousClass.loadSuperClass(cbctx, parser);
							});
					Collection<ParseTree> lambdaExpressions = XPath.findAll(ctx, "//expression/lambdaExpression",
							parser);
					lambdaExpressions.stream().forEach(e -> {
						JavaParser.LambdaExpressionContext lambdaExpression = (JavaParser.LambdaExpressionContext) e;
						JavaClass anonymousClass = this.getAnonymousClasses();
						anonymousClass.setImports(imports);
						JavaMethod memberMethod = anonymousClass.originalThis.getMemberMethods("function");
						memberMethod.loadAnonymousClass(lambdaExpression, parser, imports);
						// String superClassName =
						// creator.getRuleContext(JavaParser.CreatedNameContext.class, 0).getText();
						// anonymousClass.setSuperClass(superClassName);
					});
				}

				public void loadAnonymousClass(JavaParser.LambdaExpressionContext ctx, JavaParser parser,
						JavaImports imports) {
					Collection<ParseTree> creators = XPath.findAll(ctx, "//creator", parser);
					Collection<ParseTree> skipcreators = XPath.findAll(ctx, "//creator/classCreatorRest//creator",
							parser);
					creators.stream().filter(e -> !skipcreators.contains(e))
							.filter(e -> ((JavaParser.CreatorContext) e)
									.getRuleContext(JavaParser.ClassCreatorRestContext.class, 0)
									.getRuleContexts(JavaParser.ClassBodyContext.class).size() > 0)
							.forEach(e -> {
								JavaParser.CreatorContext creator = (JavaParser.CreatorContext) e;
								JavaClass anonymousClass = this.getAnonymousClasses().setImports(imports);
								String superClassName = creator.getRuleContext(JavaParser.CreatedNameContext.class, 0)
										.getText();
								anonymousClass.setSuperClass(superClassName);

								JavaParser.ClassBodyContext cbctx = creator
										.getRuleContext(JavaParser.ClassCreatorRestContext.class, 0)
										.getRuleContext(JavaParser.ClassBodyContext.class, 0);
								anonymousClass.loadStaticMethod(cbctx, parser, imports);
								anonymousClass.loadStaticField(cbctx, parser);
								anonymousClass.loadMember(cbctx, parser, imports);
								anonymousClass.loadInnerClass(cbctx, parser, imports);
								anonymousClass.loadSuperClass(cbctx, parser);
							});
					Collection<ParseTree> lambdaExpressions = XPath.findAll(ctx, "//expression/lambdaExpression",
							parser);
					lambdaExpressions.stream().forEach(e -> {
						JavaParser.LambdaExpressionContext lambdaExpression = (JavaParser.LambdaExpressionContext) e;
						JavaClass anonymousClass = this.getAnonymousClasses();
						anonymousClass.setImports(imports);
						JavaMethod memberMethod = anonymousClass.originalThis.getMemberMethods("function");
						memberMethod.loadAnonymousClass(lambdaExpression, parser, imports);
						// String superClassName =
						// creator.getRuleContext(JavaParser.CreatedNameContext.class, 0).getText();
						// anonymousClass.setSuperClass(superClassName);
					});
				}

				public class JavaBlock {
					public Map<String, JavaInstance> localFields;

					public JavaBlock() {
						this.localFields = new HashMap<>();
					}

					public void addLocalFields(String name) {
						this.localFields.put(name, new JavaInstance());
					}
				}
			}

			public class JavaInstance {

				private Map<String, JavaMethod> memberMethods;
				private Map<String, JavaInstance> memberFields;

				public JavaInstance() {
					this.memberMethods = new HashMap<>();
					this.memberFields = new HashMap<>();
				}

				public void print(int layer) {
					if (this.memberMethods.size() > 0 || this.memberFields.size() > 0) {
						System.out.println(JavaProject.indentation(layer + 1) + "[Instance]");
						if (this.memberMethods.size() > 0) {
							System.out.println(JavaProject.indentation(layer + 2) + "[Member Methods]");
							this.memberMethods.entrySet().stream().forEach(e -> {
								System.out.println(JavaProject.indentation(layer + 3) + e.getKey() + " @"
										+ Integer.toHexString(e.getValue().hashCode()));
								e.getValue().print(layer + 3);
							});
							// this.superClass.print(layer + 2);
						}
						if (this.memberFields.size() > 0) {
							System.out.println(JavaProject.indentation(layer + 2) + "[Member Fields]");
							this.memberFields.entrySet().stream().forEach(e -> {
								System.out.println(JavaProject.indentation(layer + 3) + e.getKey() + " @"
										+ Integer.toHexString(e.getValue().hashCode()));
							});
							// this.superClass.print(layer + 2);
						}
					}
				}

				public void addMemberMethods(String name) {
					this.memberMethods.put(name, new JavaMethod());
				}

				public JavaMethod getMemberMethods(String name) {
					if (!this.memberMethods.containsKey(name)) {
						this.addMemberMethods(name);
					}
					return this.memberMethods.get(name);
				}

				public void loadMemberMethod(JavaParser.ClassBodyContext ctx, JavaParser parser, JavaImports imports) {
					ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream()
							.filter(cbdctx -> (cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() == 0)
									|| (cbdctx.getRuleContexts(JavaParser.ModifierContext.class).stream()
											.filter(mctx -> mctx.getText().equals("static")).count() == 0))
							.forEach(cbdctx -> {
								cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream()
										.forEach(mdctx -> {
											mdctx.getRuleContexts(JavaParser.MethodDeclarationContext.class).stream()
													.forEach(mtdctx -> {
														String name = mtdctx.getChild(1).getText();
														JavaMethod memberMethod = this.getMemberMethods(name);
														memberMethod.loadAnonymousClass(mtdctx, parser, imports);
													});
										});
							});
				}

				public void addMemberFields(String name) {
					this.memberFields.put(name, new JavaInstance());
				}

				public JavaInstance getMemberFields(String name) {
					if (!this.memberFields.containsKey(name)) {
						this.addMemberFields(name);
					}
					return this.memberFields.get(name);
				}

				public void loadMemberField(JavaParser.ClassBodyContext ctx, JavaParser parser) {
					ctx.getRuleContexts(JavaParser.ClassBodyDeclarationContext.class).stream()
							.filter(cbdctx -> (cbdctx.getRuleContexts(JavaParser.ModifierContext.class).size() == 0)
									|| (cbdctx.getRuleContexts(JavaParser.ModifierContext.class).stream()
											.filter(mctx -> mctx.getText().equals("static")).count() == 0))
							.forEach(cbdctx -> {
								cbdctx.getRuleContexts(JavaParser.MemberDeclarationContext.class).stream()
										.forEach(mdctx -> {
											mdctx.getRuleContexts(JavaParser.FieldDeclarationContext.class).stream()
													.forEach(ftdctx -> {
														ftdctx.getRuleContext(
																JavaParser.VariableDeclaratorsContext.class, 0)
																.getRuleContexts(
																		JavaParser.VariableDeclaratorContext.class)
																.stream().forEach(vdctx -> {
																	String name = vdctx.getRuleContext(
																			JavaParser.VariableDeclaratorIdContext.class,
																			0).getText();
																	JavaInstance memberField = this
																			.getMemberFields(name);
																});
													});
										});
							});
				}
			}
		}
	}

	private static void printChildlen(ParseTree context, int layer) {
		printChildlen(context, layer, 5);
	}

	private static void printChildlen(ParseTree context, int layer, int max_layer) {
		if (layer == max_layer) {
			return;
		}
		if (context.getChildCount() == 0) {
			System.out.println(
					indentation(layer) + "{" + context.getClass().getCanonicalName() + "} <= '" + context + "'");
		} else {
			System.out.println(indentation(layer) + "{" + context.getClass().getCanonicalName() + "}");
		}
		for (int i = 0; i < context.getChildCount(); ++i) {
			ParseTree child = context.getChild(i);
			printChildlen(child, layer + 1, max_layer);
		}
	}

	private static String indentation(int n) {
		return String.join("", Collections.nCopies(n, "  "));
	}

}