
import org.antlr.v4.runtime.RuleContext;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.xpath.XPath;
import org.antlr.v4.runtime.tree.TerminalNodeImpl;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.Objects;

//import com.util.parser.JavaParser;
//import com.util.parser.JavaParserBaseListener;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class JavaListener extends JavaParserBaseListener  {

    private JavaParser parser = null;
    private String _package = null;
    private List<String> _imports = null;
    
    public class Class {
      private String _name = null;
      private List<String> _imports = null;
      private JavaParser.ClassDeclarationContext _declaration = null;
      private Map<String, JavaParser.MethodDeclarationContext> _methods = null;
      private List<JavaParser.ConstructorDeclarationContext> _constorctors = null;
      public Class(String __name, List<String> __imports, JavaParser.ClassDeclarationContext __declaration) {
        _name = __name;
        _imports = __imports;
        _declaration = __declaration;
        _methods = new HashMap<>();
        _constorctors = new ArrayList<>();

        Collection<ParseTree> methodDecs = XPath.findAll(_declaration, "//methodDeclaration", parser);
        for (Iterator i = methodDecs.iterator(); i.hasNext();) {
          JavaParser.MethodDeclarationContext _method = (JavaParser.MethodDeclarationContext)(i.next());
          String _method_name = _method.getChild(1).getText();
          _methods.put(_method_name, _method);
          JavaParser.ClassBodyDeclarationContext k = (JavaParser.ClassBodyDeclarationContext)(_method.getParent().getParent());
          k.getParent().children.remove(k);
        }
        
        Collection<ParseTree> constructrDecs = XPath.findAll(_declaration, "//constructorDeclaration", parser);
        for (Iterator i = constructrDecs.iterator(); i.hasNext();) {
          JavaParser.ConstructorDeclarationContext _method = (JavaParser.ConstructorDeclarationContext)(i.next());
          _constorctors.add(_method);
          JavaParser.ClassBodyDeclarationContext k = (JavaParser.ClassBodyDeclarationContext)(_method.getParent().getParent());
          k.getParent().children.remove(k);
        }
      }

      public void print() {
        System.out.println("");
        System.out.println("+--- Class ----------------------------------------------------------------------+");
        System.out.println(_name);
        //System.out.println("+--- Imports --------------------------------------------------------------------+");
        //_imports.forEach(_import -> System.out.println(_import));
        System.out.println("+--- Declaration ----------------------------------------------------------------+");
        //printChildlen(_declaration, 0);
        System.out.println("+--- Constructor ----------------------------------------------------------------+");
        _constorctors.forEach(_constorctor -> {printChildlen(_constorctor, 0);System.out.println("");});
        System.out.println("+--- Methods --------------------------------------------------------------------+");
        _methods.forEach((key, _method) -> {printChildlen(_method, 0);System.out.println("");});
        System.out.println("+--------------------------------------------------------------------------------+");
      }
    }
    
    private Map<String, Class> _classes = null;

    public JavaListener(JavaParser parser) {
        this.parser = parser;
        this._package = "";
        this._imports = new ArrayList<>();
        this._classes = new HashMap<>();
    }
    
    public void printClasses() {
      _classes.forEach((key, _class) -> {
        _class.print();
      });
    }

    @Override
    public void enterCompilationUnit(JavaParser.CompilationUnitContext ctx) {
      //printChildlen(ctx, 0);
    }

    @Override
    public void enterPackageDeclaration(JavaParser.PackageDeclarationContext ctx) {
      Collection<ParseTree> qualifiedNames = XPath.findAll(ctx, "//qualifiedName", parser);
      for (Iterator i = qualifiedNames.iterator(); i.hasNext();) {
        _package = ((JavaParser.QualifiedNameContext)(i.next())).getText();
      }
    }

    @Override
    public void enterImportDeclaration(JavaParser.ImportDeclarationContext ctx) {
      Collection<ParseTree> qualifiedNames = XPath.findAll(ctx, "//qualifiedName", parser);
      for (Iterator i = qualifiedNames.iterator(); i.hasNext();) {
        _imports.add(((JavaParser.QualifiedNameContext)(i.next())).getText());
      }
    }
    @Override
    public void enterTypeDeclaration(JavaParser.TypeDeclarationContext ctx) {
      Collection<ParseTree> oclassDecs = XPath.findAll(ctx, "//typeDeclaration/classDeclaration", parser);
      for (Iterator i = oclassDecs.iterator(); i.hasNext();) {
        JavaParser.ClassDeclarationContext _oclass = (JavaParser.ClassDeclarationContext)(i.next());
        String _oclass_name = (_package.equals("") ? "" : _package + ".") + _oclass.getChild(1).getText();
        
        Collection<ParseTree> iclassDecs = XPath.findAll(_oclass.getChild(_oclass.getChildCount()-1), "//classDeclaration", parser);
        for (Iterator j = iclassDecs.iterator(); j.hasNext();) {
          JavaParser.ClassDeclarationContext _iclass = (JavaParser.ClassDeclarationContext)(j.next());
          String _iclass_name = (_package.equals("") ? "" : _package + ".") + _oclass_name + "." + _iclass.getChild(1).getText();
          _classes.put(_iclass_name, new Class(_iclass_name,_imports, _iclass));
          // remove innerClass SubTree
          JavaParser.ClassBodyDeclarationContext k = (JavaParser.ClassBodyDeclarationContext)(_iclass.getParent().getParent());
          k.getParent().children.remove(k);
        }
        _classes.put(_oclass_name, new Class(_oclass_name,_imports, _oclass));
      }
    }

    @Override
    public void enterClassDeclaration(JavaParser.ClassDeclarationContext ctx) {
      //printChildlen(ctx, 0);
    }
    
    @Override
    public void enterMethodDeclaration(JavaParser.MethodDeclarationContext ctx) {
      //printChildlen(ctx.getParent().getParent().getParent().getParent(), 0);
    }

    private void printChildlen(ParseTree context, int layer) {
      if (context.getChildCount() == 0) {
        System.out.println(indentation(layer) + "{" + context.getClass().getCanonicalName() + "} <= '" + context + "'");
      } else {
        System.out.println(indentation(layer) + "{" + context.getClass().getCanonicalName() + "}");
      }
    for (int i = 0; i < context.getChildCount(); ++i) {
        ParseTree child = context.getChild(i);
        printChildlen(child, layer + 1);
      }
    }

    private String indentation(int n) {
      return String.join("", Collections.nCopies(n, "  "));
    }
}