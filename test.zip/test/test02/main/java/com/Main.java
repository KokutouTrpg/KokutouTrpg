import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.nio.file.Paths;
import java.util.stream.Collectors;

//import com.util.parser.JavaParser;
//import com.util.parser.JavaLexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import java.io.PrintStream;

public class Main {

    public static void main(String[] args) throws IOException, IllegalAccessException {
		System.out.println("sss");
		String path = null;
		Optional<String> pathOptional = Arrays.stream(args).filter(item -> item.startsWith("-path=")).findFirst();
		if (pathOptional.isPresent()) {
			path = pathOptional.get();
			path = path.split("-path=")[1];
		}
        if (Objects.isNull(path)) {
            throw new IllegalArgumentException("please pass code path to parse");
        }

		File dir = new File(path);
		if (!dir.exists()) {
			throw new FileNotFoundException(dir.toString());
		}
		List<String> files = new ArrayList<>();
		get(dir, files);

		files = files.stream().filter(item -> item.endsWith(".java")).collect(Collectors.toList());
		List<JavaParser> parsers = new ArrayList<>();
		for (String file : files) {
			System.out.println(file);
			CharStream charStream = CharStreams.fromPath(Paths.get(file));
			JavaLexer javaLexer = new JavaLexer(charStream);
			parsers.add(new JavaParser(new CommonTokenStream(javaLexer)));
		}
		///*
		parsers.forEach(parser -> {
			JavaListener listener = new JavaListener(parser);

			JavaParser.CompilationUnitContext compilationUnitContext = parser.compilationUnit();

			ParseTreeWalker.DEFAULT.walk(listener, compilationUnitContext);
			listener.printClasses();
			//structures.add(listener.getStructure());
		});
		// */
    }
	private static void get(File file, List files) {
        File[] fs = file.listFiles();
        for (File f : fs) {
            if (f.isDirectory()) {
                get(f, files);
            }
            if (f.isFile()) {
                files.add(f.getPath());
            }
        }
    }
}