
class Main {
    private int a = 0;
    private A a = 0;

    public static void main(String args[]) {
        A a = new A();
    }
    public Main(){

    }
    public void test(){

    }
    public class B {
        public B() {
            
        }    
    }
}

public class A {
    public A() {

    }    
}