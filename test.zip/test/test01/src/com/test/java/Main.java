package com.test.java;

import com.test.java.classes.*;
import com.test.java.classes.runnable.Charlie;

public final class Main {
    public static void main(String args[]) {
        Alpha a = new Alpha();
        Bravo b = new Bravo();
        Charlie c = new Charlie();
        SubClass1 s1 = new SubClass1();
        SubClass2 s2 = new SubClass2();
        {
            int i = 0;
        }
        int i = 0;
        Thread th_a = new Thread(a.testA());
        Thread th_b = new Thread(b.testB());
        Thread th_c = new Thread(c);
        th_a.start();
        th_b.start();
        th_c.start();
    }

    public static class SubClass1 {
        public SubClass1() {

        }

        public static class SubClass3 {
            public SubClass3() {

            }
        }
    }

    public static class SubClass2 {
        public SubClass2() {

        }
    }
}

class DefaultClass1 {

}

final class DefaultClass2 {

}