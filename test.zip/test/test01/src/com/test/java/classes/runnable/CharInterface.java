package com.test.java.classes.runnable;

public interface CharInterface {
	public void testC();
}
