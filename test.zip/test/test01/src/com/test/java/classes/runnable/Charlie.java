package com.test.java.classes.runnable;

public class Charlie implements Runnable {
	@Override
	public void run() {
		System.out.println("Charlie");
	}
}
