package com.test.java.classes;

import com.test.java.classes.runnable.Charlie;

public class Bravo {
	public Bravo() {
	}

	public Runnable testB() {
		Charlie c = new Charlie() {
			@Override
			public void run() {
				System.out.println("Bravo");
			}
		};
		return c;
	}

	public static class Delta extends Charlie {
		public Delta() {

		}
	}
}
