package com.test.java.classes;

import com.test.java.classes.runnable.Charlie;
import test.test.Test;

public class Bravo {
	public static int a1;
	public int a2;
	static int a3;
	private static int a4;
	private int a5;

	public Bravo() {
	}

	public Runnable testB() {
		Charlie c = new Charlie() {
			@Override
			public void run() {
				System.out.println("Bravo");
			}
		};
		return c;
	}

	public static class Delta extends Charlie {
		public Delta() {

		}

		public void testD() {

		}
	}

	public static class Zeta extends Test.None.Nest {
	}
}
