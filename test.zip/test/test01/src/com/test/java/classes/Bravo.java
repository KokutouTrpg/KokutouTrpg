package com.test.java.classes;

import com.test.java.classes.runnable.Charlie;
import test.test.Test;

public class Bravo {
	public static Bravo[] b1;
	public static Bravo.Echo<Bravo.Delta>[] e1;
	public static Bravo.Delta d1;
	public static int a1, a6, a7 = 10;
	public static int[] a8;
	public int a2;
	static int a3;
	private static int a4;
	private int a5;

	public Bravo() {
	}

	public Runnable testB() {
		Charlie c = new Charlie() {
			@Override
			public void run() {
				System.out.println("Bravo");
			}
		};
		return c;
	}

	public static class Delta extends Charlie {
		public Delta() {

		}

		public void testD() {

		}
	}

	public static class Echo<T> {
		public Echo() {

		}

		public void testD() {

		}
	}

	public static class Zeta extends Test.None.Nest {
	}
}
