package com.test.java.classes;

import com.test.java.classes.runnable.*;

public class Alpha {
	public void testA() {
		Bravo b = new Bravo();
		Runnable r = new Runnable() {
			@Override
			public void run() {
			}
		};
		test(new Runnable() {
			@Override
			public void run() {
				Runnable r = new Runnable() {
					@Override
					public void run() {
					}
				};
			}
		});

		Runnable r2 = () -> {
			test();
		};
		test(() -> {
			test();
		});

	}

	/*
	 * public Runnable testA() {
	 * test(new Runnable() {
	 * 
	 * @Override
	 * public void run() {
	 * 
	 * }
	 * })
	 * 
	 * Runnable r = () -> {
	 * System.out.println("Alpha");
	 * };
	 * return r;
	 * }
	 */
	/*
	 * public static class Echo extends Bravo.Delta {
	 * public Echo() {
	 * 
	 * }
	 * }
	 */
}
