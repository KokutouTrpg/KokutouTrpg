package com.test.java.classes;

import com.test.java.classes.runnable.*;

public class Alpha {
	public void testA(Alpha aaa) {
		Bravo b = new Bravo();
		Runnable r = new Runnable() {
			@Override
			public void run() {
			}
		};
		test(new Runnable() {
			@Override
			public void run() {
				Runnable r = new Runnable() {
					@Override
					public void run() {
					}
				};
			}
		});

		Runnable r2 = () -> {
			Runnbale r3 = () -> System.out.println("a");
		};
		test(() -> {
			test();
		});

	}

	/*
	 * public Runnable testA() {
	 * test(new Runnable() {
	 * 
	 * @Override
	 * public void run() {
	 * 
	 * }
	 * })
	 * 
	 * Runnable r = () -> {
	 * System.out.println("Alpha");
	 * };
	 * return r;
	 * }
	 */
	/*
	 * public static class Echo extends Bravo.Delta {
	 * public Echo() {
	 * 
	 * }
	 * }
	 */
}
