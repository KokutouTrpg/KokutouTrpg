package com.test.java.classes;

import com.test.java.classes.runnable.*;

public class Alpha extends Bravo {
	public Runnable testA() {
		Runnable r = () -> {
			System.out.println("Alpha");
		};
		return r;
	}

	public static class Echo extends Bravo.Delta {
		public Echo() {

		}
	}
}
