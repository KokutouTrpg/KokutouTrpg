package com;

public class Main {
	public static void main(String[] args) {

		int a, b;
		{
			int i = 0;
			{
				int j = 0;
				{
					Runnable r1;
					int k = 0;
					Runnable r = () -> {
						System.out.println("a");
					};
					r1 = r;
				}
				Runnable r = new Runnable() {
					@Override
					public void run() {
					}
				};
			}
		}
		if (true) {
			int i = 0;
		}
		while (true) {
			int i = 0;
			break;
		}
		for (int i = 0; i < 1; i++) {
			int j = 0;
		}
		int i = 0;
		switch (i) {
			case 1:
				break;
		}
		Outer outer = new Outer();
		outer.makeInner();
	}
}