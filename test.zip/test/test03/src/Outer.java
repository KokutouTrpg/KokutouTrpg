public class Outer {

	public Outer() {

	}

	public void makeInner() {
		Inner inner = new Inner();
		Inner.Inner2 inner2 = inner.new Inner2();
		System.out.println(" @" + Integer.toHexString(this.hashCode()));
		System.out.println(" @" + Integer.toHexString(inner.hashCode()));
		System.out.println(" @" + Integer.toHexString(inner2.hashCode()));
		System.out.println("");
		inner.print();
		inner2.print();
	}

	public class Inner {
		public Inner() {
		}

		public void print() {
			System.out.println(" @" + Integer.toHexString(Outer.this.hashCode()));
			System.out.println(" @" + Integer.toHexString(this.hashCode()));
			System.out.println("");
		}

		public class Inner2 {
			public Inner2() {
			}

			public void print() {
				System.out.println(" @" + Integer.toHexString(Outer.this.hashCode()));
				System.out.println(" @" + Integer.toHexString(Inner.this.hashCode()));
				System.out.println(" @" + Integer.toHexString(this.hashCode()));
				System.out.println("");
			}
		}
	}
}
