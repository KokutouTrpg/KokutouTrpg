package main

import (
	"fmt"
	"os"
	"runtime"

	"github.com/sirupsen/logrus"
	"github.com/urfave/cli"

	"local.5GC_DSCS/nef/logger"
	"local.5GC_DSCS/nef/service"
)

var (
	// バージョン情報 ビルド時に代入(MakeFileに記載)
	VERSION     string
	BUILD_TIME  string
	COMMIT_HASH string
	COMMIT_TIME string

	// NF本体の実体
	NEF = &service.NEF{}

	// CLIレベルのログエントリー
	appLog *logrus.Entry
)

// パッケージ初期化関数
func init() {
	appLog = logger.AppLog
}

// main関数
func main() {
	app := cli.NewApp()
	app.Name = "nef"
	fmt.Print(app.Name, "\n")
	appLog.Infoln("NEF version: ", GetVersion())
	app.Usage = "-nefcfg nef configuration file"
	app.Action = action
	app.Flags = []cli.Flag{
		cli.StringFlag{
			Name:  "nefcfg",
			Usage: "config file",
		},
	}

	if err := app.Run(os.Args); err != nil {
		appLog.Errorf("NEF Run Error: %v", err)
	}
}

// cliアプリケーション登録アクション関数
func action(c *cli.Context) error {
	if err := NEF.Initialize(c.String("nefcfg")); err != nil {
		logger.CfgLog.Errorf("%+v", err)
		return fmt.Errorf("Failed to initialize !!")
	}

	NEF.Start()

	return nil
}

// Version文字列取得関数
func GetVersion() string {
	if VERSION != "" {
		return fmt.Sprintf(
			"\n\tversion: %s"+
				"\n\tbuild time:      %s"+
				"\n\tcommit hash:     %s"+
				"\n\tcommit time:     %s"+
				"\n\tgo version:      %s %s/%s",
			VERSION,
			BUILD_TIME,
			COMMIT_HASH,
			COMMIT_TIME,
			runtime.Version(),
			runtime.GOOS,
			runtime.GOARCH,
		)
	} else {
		return fmt.Sprintf(
			"\n\tNot specify ldflags (which link version) during go build\n\tgo version: %s %s/%s",
			runtime.Version(),
			runtime.GOOS,
			runtime.GOARCH,
		)
	}
}