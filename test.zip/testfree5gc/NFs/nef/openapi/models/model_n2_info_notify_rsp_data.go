/*
 * Namf_Communication
 *
 * AMF Communication Service
 *
 * API version: 1.0.0
 * Manually Created
 */

package models

type N2InfoNotifyRspData struct {
	N2InfoContent *N2InfoContent `json:"n2InfoContent,omitempty"`
}
