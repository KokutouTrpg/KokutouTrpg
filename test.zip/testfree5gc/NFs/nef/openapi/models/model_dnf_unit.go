package models

type DnfUnit struct {
	DnfUnit []Atom `json:"dnfUnit" bson:"dnfUnit"`
}
