/*
 * NEF Configuration Config
 */

package nfconfig

import (
	"fmt"
	"io/ioutil"

	"github.com/sirupsen/logrus"
	"gopkg.in/yaml.v2"

	"local.5GC_DSCS/nef/logger"
)

var (
	NefConfig NFConfig

	// 初期化ログエントリー
	initLog *logrus.Entry
)

// パッケージ初期化関数
func init() {
	initLog = logger.InitLog
}

func InitNFConfig(nfcfgFilePath string) error {
	if content, err := ioutil.ReadFile(nfcfgFilePath); err != nil {
		return err
	} else {
		NefConfig = NFConfig{}

		if yamlErr := yaml.Unmarshal(content, &NefConfig); yamlErr != nil {
			return yamlErr
		}
	}
	setLogLevel()
	
	if err := CheckConfigVersion(); err != nil {
		return err
	}

	return nil
}

func setLogLevel() {
	if NefConfig.Logger == nil {
		initLog.Warnln("NEF config without log level setting!!!")
		return
	}

	if NefConfig.Logger.NEF != nil {
		if NefConfig.Logger.NEF.DebugLevel != "" {
			if level, err := logrus.ParseLevel(NefConfig.Logger.NEF.DebugLevel); err != nil {
				initLog.Warnf("NEF Log level [%s] is invalid, set to [info] level",
					NefConfig.Logger.NEF.DebugLevel)
				logger.SetLogLevel(logrus.InfoLevel)
			} else {
				initLog.Infof("NEF Log level is set to [%s] level", level)
				logger.SetLogLevel(level)
			}
		} else {
			initLog.Infoln("NEF Log level is default set to [info] level")
			logger.SetLogLevel(logrus.InfoLevel)
		}
		logger.SetReportCaller(NefConfig.Logger.NEF.ReportCaller)
	}

}

func CheckConfigVersion() error {
	currentVersion := NefConfig.GetVersion()

	if currentVersion != NEF_EXPECTED_CONFIG_VERSION {
		return fmt.Errorf("config version is [%s], but expected is [%s].",
			currentVersion, NEF_EXPECTED_CONFIG_VERSION)
	}

	logger.CfgLog.Infof("config version [%s]", currentVersion)

	return nil
}
