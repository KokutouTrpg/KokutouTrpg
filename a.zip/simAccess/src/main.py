from typing import Any, Callable
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime 
from zoneinfo import ZoneInfo
from time import time
from scipy.stats import gaussian_kde

def convertDatetime2Time(dt : datetime):
	return dt.timestamp()

def convertTime2Datetime(t : time, tz : str = 'Asia/Tokyo'):
	return datetime.fromtimestamp(t).astimezone(ZoneInfo(tz))

def convertTimeList2DatetimeList(tlist : list[time], tz : str = 'Asia/Tokyo'):
	return [convertTime2Datetime(t, tz) for t in tlist]

def generateDateTime(y : int, m : int, d : int, h : int = 0, min : int = 0):
	return datetime(year = y, month = m, day = d, hour = h, minute = min, second = 0, microsecond = 0)

def generateTime(y : int, m : int, d : int, h : int = 0, min : int = 0):
	return convertDatetime2Time(generateDateTime(y, m, d, h, min))

def samplingUniformDistribution(anchorTime : time, rangeDays : float, samplingNum : int, _):
	return np.random.rand(samplingNum) * rangeDays * 24 * 60 * 60 + anchorTime

def samplingNormalDistribution(anchorTime : time, rangeDays : float, samplingNum : int, _):
	return (np.random.randn(samplingNum) / (2.57582 * 2) + 0.5) * rangeDays * 24 * 60 * 60 + anchorTime

def samplingMixtureGaussianDistributionFromKDE(anchorTime : time, _rangeDays : float, samplingNum : int, paramSamplingMethod : tuple[gaussian_kde]):
	return  paramSamplingMethod[0][0].resample(size = samplingNum)[0] + anchorTime

def generateRandomTimes_tlist(anchorTime : time, rangeDays : float, samplingNum : int, samplingMethod : Callable[[int], np.ndarray]  = samplingNormalDistribution, *paramSamplingMethod : Any):
	return (samplingMethod(anchorTime, rangeDays, samplingNum, paramSamplingMethod)).tolist()

def generateRandomTimesByMultiPeriods_tlist(randomPeriods_list : list[tuple[time, float, int, Callable[[int], np.ndarray], Any]]):
	randomTimes_tlist =[]
	for (anchorTime, rangeDays, samplingNum, samplingMethod, *paramSamplingMethod) in randomPeriods_list:
		randomTimes_tlist = randomTimes_tlist + generateRandomTimes_tlist(anchorTime, rangeDays, samplingNum, samplingMethod, paramSamplingMethod)
	return randomTimes_tlist

if __name__ == "__main__":
	startDay_t : time  = generateTime(2023, 3, 27)
	periodSeconds : int = 7 * 24 * 60 * 60
	binDeltaSeconds : int = 10 * 60
	N=50000


	binFirstTimes_tlist = [startDay_t + binDeltaSeconds * i_bin  for i_bin in range(periodSeconds // binDeltaSeconds)]

	startingTimes_tlist = generateRandomTimesByMultiPeriods_tlist([(generateTime(2023, 3, 27, 9), 3/24, N//2, samplingNormalDistribution),(generateTime(2023, 3, 27, 12), 5/24, N//2, samplingNormalDistribution)])
	startingTimeRanges_tlist = [startDay_t + (t - startDay_t) // binDeltaSeconds * float(binDeltaSeconds) for t in startingTimes_tlist]	
	binCounts_list = [startingTimeRanges_tlist.count(binFirstTime) for binFirstTime in binFirstTimes_tlist]
	plt.bar(binFirstTimes_tlist, binCounts_list, align="edge", width = binDeltaSeconds, color="#0000FF")

	kde = gaussian_kde(startingTimes_tlist)
	
	startingTimes_tlist = generateRandomTimesByMultiPeriods_tlist([(1*24*60*60, 1, N, samplingMixtureGaussianDistributionFromKDE, kde)])
	startingTimeRanges_tlist = [startDay_t + (t - startDay_t) // binDeltaSeconds * float(binDeltaSeconds) for t in startingTimes_tlist]	
	binCounts_list = [startingTimeRanges_tlist.count(binFirstTime) for binFirstTime in binFirstTimes_tlist]
	plt.bar(binFirstTimes_tlist, binCounts_list, align="edge", width = binDeltaSeconds, color="#FF0000")

	startingTimes_tlist = generateRandomTimesByMultiPeriods_tlist([(2*24*60*60, 1, N, samplingMixtureGaussianDistributionFromKDE, kde)])
	startingTimeRanges_tlist = [startDay_t + (t - startDay_t) // binDeltaSeconds * float(binDeltaSeconds) for t in startingTimes_tlist]	
	binCounts_list = [startingTimeRanges_tlist.count(binFirstTime) for binFirstTime in binFirstTimes_tlist]
	plt.bar(binFirstTimes_tlist, binCounts_list, align="edge", width = binDeltaSeconds, color="#00FF00")

	binFirstDayTimes_tlist = [startDay_t + (24 * 60 * 60) * i_bin  for i_bin in range(periodSeconds // (24 * 60 * 60) + 1)]
	binFirstDayTimes_slist = [dt.strftime('%Y/%m/%d') for dt in convertTimeList2DatetimeList(binFirstDayTimes_tlist)]
	plt.xticks(binFirstDayTimes_tlist,binFirstDayTimes_slist,rotation=90)
	plt.minorticks_on()
	
	plt.grid(which = "both", axis = "x")
	plt.grid(which = "major", axis = "y")
	plt.xlim(binFirstTimes_tlist[0],binFirstTimes_tlist[-1]+binDeltaSeconds)
	plt.tight_layout()
	plt.show()