import csv
from typing import Any, Callable
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime 
from zoneinfo import ZoneInfo
from time import time
from scipy.stats import gaussian_kde

# 変換関数
def convertStr2Datetime(dt_s : str):
	return datetime.strptime(dt_s, '%Y/%m/%d %H:%M')

def convertStr2Time(dt_s : str):
	return convertDatetime2Time(convertStr2Datetime(dt_s))

def convertDatetime2Time(dt : datetime):
	return dt.timestamp()

def convertTime2Datetime(t : time, tz : str = 'Asia/Tokyo'):
	return datetime.fromtimestamp(t).astimezone(ZoneInfo(tz))

def convertTimeList2DatetimeList(tlist : list[time], tz : str = 'Asia/Tokyo'):
	return [convertTime2Datetime(t, tz) for t in tlist]

# サンプリング関数
def samplingUniformDistribution(anchorTime : time, rangeDays : float, samplingNum : int, _):
	return np.random.rand(samplingNum) * rangeDays * 24 * 60 * 60 + anchorTime

def samplingNormalDistribution(anchorTime : time, rangeDays : float, samplingNum : int, _):
	return (np.random.randn(samplingNum) / (2.57582 * 2) + 0.5) * rangeDays * 24 * 60 * 60 + anchorTime

def samplingMixtureGaussianDistributionFromKDE(anchorTime : time, _rangeDays : float, samplingNum : int, paramSamplingMethod : tuple[gaussian_kde]):
	return  paramSamplingMethod[0][0].resample(size = samplingNum)[0] + anchorTime

	
# 生成関数
def generateDateTime(y : int, m : int, d : int, h : int = 0, min : int = 0, sec : int = 0, tz : str = 'Asia/Tokyo'):
	return datetime(year = y, month = m, day = d, hour = h, minute = min, second = sec, microsecond = 0, tzinfo = ZoneInfo(tz))

def generateTime(y : int, m : int, d : int, h : int = 0, min : int = 0, sec : int = 0, tz : str = 'Asia/Tokyo'):
	return convertDatetime2Time(generateDateTime(y, m, d, h, min, sec, tz))

def generateRandomTimes_tlist(anchorTime : time, rangeDays : float, samplingNum : int, samplingMethod : Callable[[int], np.ndarray]  = samplingNormalDistribution, *paramSamplingMethod : Any):
	return (samplingMethod(anchorTime, rangeDays, samplingNum, paramSamplingMethod)).tolist()

def generateRandomTimesByMultiDistributions_tlist(randomParameters_list : list[tuple[time, float, int, Callable[[int], np.ndarray], Any]]):
	randomTimes_tlist =[]
	for (anchorTime, rangeDays, samplingNum, samplingMethod, *paramSamplingMethod) in randomParameters_list:
		randomTimes_tlist = randomTimes_tlist + generateRandomTimes_tlist(anchorTime, rangeDays, samplingNum, samplingMethod, paramSamplingMethod)
	return randomTimes_tlist

# 読み込み関数
def loadNotificationRequestTimes(fname : str, anchorTime_t : time,  loadFirstTime_t : time, samplingNum : int = None, rangePerDay : float = 5/24/60):
	samplingEndTime_t : time = loadFirstTime_t + 6 * 60 * 60
	with open(fname) as f:
		reader = csv.reader(f)
		randomParameters_list = []
		for row in reader:
			randomParameters_list.append((convertStr2Time(row[0]), rangePerDay, int(row[1]) , samplingUniformDistribution))
		deviceAproximetryBootTimes_tlist = [deviceAproximetryBootTime_t - loadFirstTime_t \
			 for deviceAproximetryBootTime_t in generateRandomTimesByMultiDistributions_tlist(randomParameters_list) \
			 if loadFirstTime_t <= deviceAproximetryBootTime_t and deviceAproximetryBootTime_t <= samplingEndTime_t]
		if samplingNum is None:
			return [deviceAproximetryBootTime_t + anchorTime_t for deviceAproximetryBootTime_t in deviceAproximetryBootTimes_tlist]
		else:
			kde = gaussian_kde(deviceAproximetryBootTimes_tlist,bw_method=0.01)
			return simulateDeviceBootTimes([(anchorTime_t, 6/24, 50000, samplingMixtureGaussianDistributionFromKDE, kde)])

def loadExceptNotificationRequestTimes(fname_notification : str,fname_token : str, anchorTime_t : time,  loadFirstTime_t : time, samplingNum : int = None, rangePerDay : float = 5/24/60):
	samplingEndTime_t : time = loadFirstTime_t + 24 * 60 * 60
	rows_notification = []
	with open(fname_notification) as f1:
		reader1 = csv.reader(f1)
		for row in reader1:
			rows_notification.append(row)
	rows_token = []
	with open(fname_token) as f2:
		reader2 = csv.reader(f2)
		for row in reader2:
			rows_token.append(row)
	randomParameters_list = []
	for i in range(min(len(rows_token),len(rows_notification))):
		randomParameters_list.append((convertStr2Time(rows_token[i][0]), rangePerDay, int(rows_token[i][1]) - int(rows_notification[i][1]) , samplingUniformDistribution))
	deviceAproximetryBootTimes_tlist = [deviceAproximetryBootTime_t - loadFirstTime_t \
		for deviceAproximetryBootTime_t in generateRandomTimesByMultiDistributions_tlist(randomParameters_list) \
		if loadFirstTime_t <= deviceAproximetryBootTime_t and deviceAproximetryBootTime_t <= samplingEndTime_t]
	if samplingNum is None:
		return [deviceAproximetryBootTime_t + anchorTime_t for deviceAproximetryBootTime_t in deviceAproximetryBootTimes_tlist]
	else:
		kde = gaussian_kde(deviceAproximetryBootTimes_tlist,bw_method=0.01)
		return simulateDeviceBootTimes([(anchorTime_t, 6/24, 50000, samplingMixtureGaussianDistributionFromKDE, kde)])

# シミュレーション関数
def simulateDeviceBootTimes(randomParameters_list : list[tuple[time, float, int, Callable[[int], np.ndarray], Any]]):
	deviceBootTimes_tlist : list[time] = generateRandomTimesByMultiDistributions_tlist(randomParameters_list)
	print("Device Boot Times :",len(deviceBootTimes_tlist))
	return deviceBootTimes_tlist
						      
def simulateGetTokenRequestTimesByNotification(firstRequestTimes_tlist : list[time], simulateEndTime_t : time, systemDowntimes : list[tuple[time]]):
	retryWaitTimes : list[time] = [(2**i) * 60 if 2**i < 60 else 60 * 60 for i in range(20)]

	requestTimes_tlistlist : list[list[time]] =  []
	for di, deviceStartingTime_t in enumerate(firstRequestTimes_tlist):
		print("\rGet TokenRequest Times By Notification : %6d/%6d"%(di + 1, len(firstRequestTimes_tlist)), end="")
		requestTimes_tlistlist.append([deviceStartingTime_t])
		while True:
			if simulateEndTime_t < requestTimes_tlistlist[-1][-1]:
				break
			for systemDowntime in systemDowntimes:
				for retryWaitTime in retryWaitTimes:
					if systemDowntime[0] <= requestTimes_tlistlist[-1][-1] and  requestTimes_tlistlist[-1][-1] <= systemDowntime[1]:
						requestTimes_tlistlist[-1].append(requestTimes_tlistlist[-1][-1] + retryWaitTime)
						continue
					break
			requestTimes_tlistlist[-1].append(requestTimes_tlistlist[-1][-1] + 6 * 60 * 60)
	requestTimes_tlist = [Time_t for Times_tlist in requestTimes_tlistlist for Time_t in Times_tlist]
	print("\rGet TokenRequest Times By Notification : %6d/%6d"%(len(firstRequestTimes_tlist), len(firstRequestTimes_tlist)), len(requestTimes_tlist))
	return requestTimes_tlist

def simulateGetTokenRequestTimesByRegistryService(firstRequestTimes_tlist : list[time], simulateEndTime_t : time, systemDowntimes : list[tuple[time]]):
	retryWaitTimes : list[time] = [(2**i) * 60 if 2**i < 60 else 60 * 60 for i in range(20)]

	requestTimes_tlistlist : list[list[time]] =  []
	for di, firstRequestTime_t in enumerate(firstRequestTimes_tlist):
		print("\rGet TokenRequest Times By RegistryService : %6d/%6d"%(di + 1, len(firstRequestTimes_tlist)), end="")
		requestTimes_tlistlist.append([firstRequestTime_t])
		retryCount : int = 0
		while True:
			if simulateEndTime_t < requestTimes_tlistlist[-1][-1]:
				break
			for systemDowntime in systemDowntimes:
				for retryWaitTime in retryWaitTimes:
					if systemDowntime[0] <= requestTimes_tlistlist[-1][-1] and  requestTimes_tlistlist[-1][-1] <= systemDowntime[1]:
						requestTimes_tlistlist[-1].append(requestTimes_tlistlist[-1][-1] + retryWaitTime)
						continue
					break
			retryCount = retryCount + 1
			requestTimes_tlistlist[-1].append(firstRequestTime_t + retryCount * 24 * 60 * 60)
	requestTimes_tlist = [Time_t for Times_tlist in requestTimes_tlistlist for Time_t in Times_tlist]
	print("\rGet TokenRequest Times By RegistryService : %6d/%6d"%(len(firstRequestTimes_tlist), len(firstRequestTimes_tlist)), len(requestTimes_tlist))
	return requestTimes_tlist

def simulateGetTokenRequestTimesBySublog(firstRequestTimes_tlist : list[time], simulateEndTime_t : time, systemDowntimes : list[tuple[time]]):
	retryWaitTimes : list[time]  = [(2**i) * 60 if 2**i < 60 else 60 * 60 for i in range(20)]

	requestTimes_tlistlist : list[list[time]] =  []
	for di, firstRequestTime_t in enumerate(firstRequestTimes_tlist):
		print("\rGet TokenRequest Times By Sublog : %6d/%6d"%(di + 1, len(firstRequestTimes_tlist)), end="")
		requestTimes_tlistlist.append([firstRequestTime_t + 6*60*60])
		retryCount : int = 0
		while True:
			if simulateEndTime_t < requestTimes_tlistlist[-1][-1]:
				break
			for systemDowntime in systemDowntimes:
				for retryWaitTime in retryWaitTimes:
					if systemDowntime[0] <= requestTimes_tlistlist[-1][-1] and  requestTimes_tlistlist[-1][-1] <= systemDowntime[1]:
						requestTimes_tlistlist[-1].append(requestTimes_tlistlist[-1][-1] + retryWaitTime)
						continue
					break
			retryCount = retryCount + 1
			requestTimes_tlistlist[-1].append(firstRequestTime_t + 6*60*60 + retryCount * 12 * 60 * 60)
	requestTimes_tlist = [Time_t for Times_tlist in requestTimes_tlistlist for Time_t in Times_tlist]
	print("\rGet TokenRequest Times By Sublog : %6d/%6d"%(len(firstRequestTimes_tlist), len(firstRequestTimes_tlist)), len(requestTimes_tlist))
	return requestTimes_tlist

def simulateGetTokenRequestTimesByExceptNotification(firstRequestTimes_tlist : list[time], simulateEndTime_t : time, systemDowntimes : list[tuple[time]]):
	retryWaitTimes : list[time]  = [(2**i) * 60 if 2**i < 60 else 60 * 60 for i in range(20)]

	requestTimes_tlistlist : list[list[time]] =  []
	for di, firstRequestTime_t in enumerate(firstRequestTimes_tlist):
		print("\rGet TokenRequest Times By Except Notification : %6d/%6d"%(di + 1, len(firstRequestTimes_tlist)), end="")
		requestTimes_tlistlist.append([firstRequestTime_t + 6*60*60])
		retryCount : int = 0
		while True:
			if simulateEndTime_t < requestTimes_tlistlist[-1][-1]:
				break
			for systemDowntime in systemDowntimes:
				for retryWaitTime in retryWaitTimes:
					if systemDowntime[0] <= requestTimes_tlistlist[-1][-1] and  requestTimes_tlistlist[-1][-1] <= systemDowntime[1]:
						requestTimes_tlistlist[-1].append(requestTimes_tlistlist[-1][-1] + retryWaitTime)
						continue
					break
			retryCount = retryCount + 1
			requestTimes_tlistlist[-1].append(firstRequestTime_t + retryCount * 24 * 60 * 60)
	requestTimes_tlist = [Time_t for Times_tlist in requestTimes_tlistlist for Time_t in Times_tlist]
	print("\rGet TokenRequest Times By Except Notification : %6d/%6d"%(len(firstRequestTimes_tlist), len(firstRequestTimes_tlist)), len(requestTimes_tlist))
	return requestTimes_tlist

# グラフ描画関数
def drawHistgram(requestTimes_tlist : list[time], drawFirstTime_t : time, drawEndTime_t : time, timePerBin : time, label : str, binFirstTimes_tlist : list[time] = None, binTotalCounts_list : list[int] = None):
	_requestTimes_tlist = [requestTime_t for requestTime_t in requestTimes_tlist if drawFirstTime_t <= requestTime_t and requestTime_t <= drawEndTime_t]
	requestApproximateTimes_tlist = [drawFirstTime_t + (t - drawFirstTime_t) // timePerBin * timePerBin for t in _requestTimes_tlist]	
	binCounts_list = [requestApproximateTimes_tlist.count(binFirstTime) for binFirstTime in binFirstTimes_tlist]
	plt.bar(binFirstTimes_tlist, binCounts_list, bottom = binTotalCounts_list, align="edge", width = timePerBin, label =label)
	if binTotalCounts_list is not None:
		return [binCounts_list[i] + binTotalCounts_list[i] for i in range(len(binCounts_list))]
	return binCounts_list

def drawHistgrams(requestTimes_tdictlist : dict[list[time]], drawFirstTime_t : time, drawEndTime_t : time, timePerBin : time, systemDowntimes : list[tuple[time]], ymax =16000):
	plt.figure()
	drawingDurationTimes : time = drawEndTime_t - drawFirstTime_t
	binFirstTimes_tlist = [drawFirstTime_t + timePerBin * i_bin  for i_bin in range(int(drawingDurationTimes / timePerBin))]

	binTotalCounts_list : list[int] = None
	for label, requestTimes_tlist in requestTimes_tdictlist.items():
		_requestTimes_tlist = []
		for requestTime_t in requestTimes_tlist:
			for systemDowntime in systemDowntimes:
				if systemDowntime[0] <= requestTime_t and  requestTime_t <= systemDowntime[1]:
					break
			else:
				_requestTimes_tlist.append(requestTime_t)
		binTotalCounts_list = drawHistgram(_requestTimes_tlist, drawFirstTime_t, drawEndTime_t, timePerBin, label, binFirstTimes_tlist, binTotalCounts_list)
	
	drawingDurationDays : int = int(drawingDurationTimes / (24 * 60 * 60))
	binFirstDayTimes_tlist = [drawFirstTime_t + (24 * 60 * 60) * i_bin  for i_bin in range(drawingDurationDays + 1)]
	binFirstDayTimes_slist = [dt.strftime('%Y/%m/%d') for dt in convertTimeList2DatetimeList(binFirstDayTimes_tlist)]
	plt.xticks(binFirstDayTimes_tlist, binFirstDayTimes_slist, rotation=90)
	plt.legend()
	plt.minorticks_on()
	plt.grid(which = "both", axis = "x")
	plt.grid(which = "major", axis = "y")
	if ymax is not None:
		plt.ylim(0,ymax)
	plt.xlim(binFirstTimes_tlist[0],binFirstTimes_tlist[-1]+timePerBin)
	plt.tight_layout()
	plt.show()

if __name__ == "__main__":
	loadFirstTime_t : time = generateTime(2023,2,21,0)
	simulateStartTime_t : time = generateTime(2023, 2, 21, 9) 
	simulateEndTime_t : time = generateTime(2023, 2, 26, 9)
	drawFirstTime_t : time  = generateTime(2023, 2, 21, 9)
	drawEndTime_t : time = generateTime(2023, 2, 26, 9)
	timePerBin : int = 5 * 60
	N=49920
	systemDowntimes = [
							(generateTime(2023, 2, 21, 12, 10),generateTime(2023, 2, 21, 23, 45)),
							(generateTime(2023, 2, 22,  0,  0),generateTime(2023, 2, 22,  0, 15)),
							(generateTime(2023, 2, 22, 18, 10),generateTime(2023, 2, 22, 19, 10)),
							(generateTime(2023, 2, 23, 17, 45),generateTime(2023, 2, 23, 18, 30)),
							(generateTime(2023, 2, 24, 17, 40),generateTime(2023, 2, 24, 18, 00)),
						]
	firstRequestTimesByNotification_6Hour_tlist = loadNotificationRequestTimes('data/RequestNotification0221.csv', simulateStartTime_t,  loadFirstTime_t)
	firstRequestTimesByExceptNotification_1Day_tlist = loadExceptNotificationRequestTimes('data/RequestNotification0221.csv', 'data/RequestToken0221.csv', simulateStartTime_t, loadFirstTime_t)

	requestTimes_tdictlist : dict[list[time]] = {
		"By Notification" :  simulateGetTokenRequestTimesByNotification(firstRequestTimesByNotification_6Hour_tlist , simulateEndTime_t, systemDowntimes),
		"By Except Notification" : simulateGetTokenRequestTimesByExceptNotification(firstRequestTimesByExceptNotification_1Day_tlist , simulateEndTime_t, systemDowntimes),
	}
	drawHistgrams(requestTimes_tdictlist, drawFirstTime_t, drawEndTime_t, timePerBin, systemDowntimes)

	"""
	randomParameters_list = [	
							(generateTime(2023, 2, 19,  9,  0), 1/24/3, (N//6 + N//6//2  )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19,  9, 40), 1/24/3, (N//6 + N//6//2  )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19,  8, 45), 1.5/24, (N//6 + N//6//2  )//16*14, samplingNormalDistribution),
							(generateTime(2023, 2, 19, 10,  0), 1/24/3, (N//6 + N//6//2*2)//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 10, 40), 1/24/3, (N//6 + N//6//2*2)//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19,  9, 45), 1.5/24, (N//6 + N//6//2*2)//16*14, samplingNormalDistribution),
							(generateTime(2023, 2, 19, 11,  0), 1/24/3, (N//6            )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 11, 40), 1/24/3, (N//6            )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 10, 45), 1.5/24, (N//6            )//16*14, samplingNormalDistribution),
							(generateTime(2023, 2, 19, 12,  0), 1/24/3, (N//6//2         )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 12, 40), 1/24/3, (N//6//2         )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 11, 45), 1.5/24, (N//6//2         )//16*14, samplingNormalDistribution),
							(generateTime(2023, 2, 19, 13,  0), 1/24/3, (N//6//2         )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 13, 40), 1/24/3, (N//6//2         )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 12, 45), 1.5/24, (N//6//2         )//16*14, samplingNormalDistribution),
							(generateTime(2023, 2, 19, 14,  0), 1/24/3, (N//6//2         )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 14, 40), 1/24/3, (N//6//2         )//16   , samplingNormalDistribution),
							(generateTime(2023, 2, 19, 13, 45), 1.5/24, (N//6//2         )//16*14, samplingNormalDistribution),
						 ]
	deviceBootTimes_tlist = simulateDeviceBootTimes(randomParameters_list)
	
	requestTimes_tdictlist : dict[list[time]] = {
		"By Notification" :  simulateGetTokenRequestTimesByNotification(deviceBootTimes_tlist , simulateEndTime_t, systemDowntimes),
		"By Sublog": simulateGetTokenRequestTimesByRegistryService(deviceBootTimes_tlist , simulateEndTime_t, systemDowntimes),
		"By RegistryService": simulateGetTokenRequestTimesBySublog(deviceBootTimes_tlist , simulateEndTime_t, systemDowntimes),
	}
	drawHistgrams(requestTimes_tdictlist, drawFirstTime_t, drawEndTime_t, timePerBin)
	"""