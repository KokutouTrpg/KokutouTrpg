java -jar antlr-4.7.1-complete.jar -Dlanguage=Python3 ./src/grammar/*.g4

call prepareVenv.bat