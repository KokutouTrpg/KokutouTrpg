package main

import (
        "fmt"
        "go/ast"
        "go/parser"
        "go/token"
)

func main() {
	fset := token.NewFileSet()
	pkgs, err := parser.ParseDir(fset, "../NFs/nef/consumer", nil, parser.ParseComments)
    if err != nil {
            fmt.Printf("Failed to parse dir\n")
            return
    }

    //ast.Print(fset, pkgs)
    var pname string
    var fname string
    var cfname string
    call := make(map[string]map[string][]string)

    for pkgname, pkg := range pkgs {
        //fmt.Printf("pkg %s = %s\n", pkgname, pkg.Name)
        pname = pkgname
        call[pname] = make(map[string][]string)
        for _, file := range pkg.Files {
            ast.Inspect(file, func(n ast.Node) bool {
                if funcd, ok := n.(*ast.FuncDecl); ok {
                    fname = ""
                    if funcd.Recv != nil {
                        typetmpn := funcd.Recv.List[0].Type
                        typename := []string{}
                        for {
                            if _typetmpn, ok := typetmpn.(*ast.StarExpr); ok {
                                typename = append(typename,"*")
                                typetmpn = _typetmpn.X
                                continue
                            }
                            if _typetmpn, ok := typetmpn.(*ast.SelectorExpr); ok {
                                typename = append(typename, _typetmpn.Sel.Name)
                                typetmpn = _typetmpn.X
                                continue
                            }
                            if _typetmpn, ok := typetmpn.(*ast.Ident); ok {
                                typename = append(typename, _typetmpn.Name)
                            }
                            break
                        }
                        typename = append(typename, "|")
                        outtypename := stringcallfunc(typename)
                        fname += outtypename + ">"
                        //fmt.Print(outtypename)
                        //fmt.Print(">")
                    }
                    //fmt.Println(funcd.Name.Name)
                    fname += funcd.Name.Name
                }
                if calle, ok := n.(*ast.CallExpr); ok {
                    funcname := getcallfunc(calle)
                    cfname=stringcallfunc(funcname)
                    //fmt.Print("\t")
                    //fmt.Println(cfname)
                    call[pname][fname] = append(call[pname][fname], cfname)
                }
                return true
            })
        }
    }

    
    for pname, funcs := range call {
        
        for fname, cfuncs := range funcs {
            for _, cfname := range cfuncs {
                if _, ok := call[pname][cfname]; ok {
                    fmt.Println(pname+">"+fname,":", pname+">"+cfname)
                } else {
                    fmt.Println(pname+">"+fname,":", cfname)
                }
            }
        }
    }
}
func stringcallfunc(funcname []string) (out string) {
    for i := len(funcname); i > 0; i-- {
        if funcname[i-1][0]=='|'{
            out = funcname[i-1][1:]
        }else {
            out += funcname[i-1]
        }
        if funcname[i-1] != "[OBJ]" && funcname[i-1] != "|" && i != 1 {
            out += ">"
        }
    }
    return 
}

func getcallfunc(calle *ast.CallExpr) (funcname []string){
    tmpn := calle.Fun
    for {
        if _tmpn, ok := tmpn.(*ast.SelectorExpr); ok {
            funcname = append(funcname, _tmpn.Sel.Name)
            tmpn = _tmpn.X
            continue
        }
        if _tmpn, ok := tmpn.(*ast.TypeAssertExpr); ok {
            typetmpn := _tmpn.Type
            typename := []string{}
            for {
                if _typetmpn, ok := typetmpn.(*ast.StarExpr); ok {
                    typename = append(typename,"*")
                    typetmpn = _typetmpn.X
                    continue
                }
                if _typetmpn, ok := typetmpn.(*ast.SelectorExpr); ok {
                    typename = append(typename, _typetmpn.Sel.Name)
                    typetmpn = _typetmpn.X
                    continue
                }
                if _typetmpn, ok := typetmpn.(*ast.Ident); ok {
                    typename = append(typename, _typetmpn.Name)
                }
                break
            }
            typename = append(typename, "|")
            outtypename := stringcallfunc(typename)
            funcname = append(funcname, outtypename)
            tmpn = _tmpn.X
            continue
        }
        if _tmpn, ok := tmpn.(*ast.Ident); ok {
            funcname = append(funcname, _tmpn.Name)
            if _tmpn.Obj != nil {
                if _tmpn.Obj.Kind != ast.Fun {
                    if o2, ok := _tmpn.Obj.Decl.(*ast.AssignStmt); ok {
                        funcname = append(funcname, "[OBJ]")
                        if objcalle, ok := o2.Rhs[0].(*ast.CallExpr); ok {
                            objfuncname := getcallfunc(objcalle)
                            funcname = append(funcname, objfuncname...)
                        }
                    }
                    if o2, ok := _tmpn.Obj.Decl.(*ast.ValueSpec); ok {
                        typetmpn := o2.Type
                        typename := []string{}
                        for {
                            if _typetmpn, ok := typetmpn.(*ast.StarExpr); ok {
                                typename = append(typename,"*")
                                typetmpn = _typetmpn.X
                                continue
                            }
                            if _typetmpn, ok := typetmpn.(*ast.SelectorExpr); ok {
                                typename = append(typename, _typetmpn.Sel.Name)
                                typetmpn = _typetmpn.X
                                continue
                            }
                            if _typetmpn, ok := typetmpn.(*ast.Ident); ok {
                                typename = append(typename, _typetmpn.Name)
                            }
                            break
                        }
                        typename = append(typename, "|")
                        outtypename := stringcallfunc(typename )
                        funcname[len(funcname)-1] = outtypename
                    }
                    if o2, ok := _tmpn.Obj.Decl.(*ast.Field); ok {
                        typetmpn := o2.Type
                        typename := []string{}
                        for {
                            if _typetmpn, ok := typetmpn.(*ast.StarExpr); ok {
                                typename = append(typename,"*")
                                typetmpn = _typetmpn.X
                                continue
                            }
                            if _typetmpn, ok := typetmpn.(*ast.SelectorExpr); ok {
                                typename = append(typename, _typetmpn.Sel.Name)
                                typetmpn = _typetmpn.X
                                continue
                            }
                            if _typetmpn, ok := typetmpn.(*ast.Ident); ok {
                                typename = append(typename, _typetmpn.Name)
                            }
                            break
                        }
                        typename = append(typename, "|")
                        outtypename := stringcallfunc(typename )
                        funcname[len(funcname)-1] = outtypename
                    }
                }
            }
        }
        break
    }
    return
}