package consumer

import (
	"context"
	"net/http"
	"testing"

	"github.com/stretchr/testify/require"
	"github.com/stretchr/testify/assert"
	"github.com/suzuki-shunsuke/flute/v2/flute"
	

	"local.5GC_DSCS/nef/openapi/Nnrf_NFManagement"
	nef_context "local.5GC_DSCS/nef/context"
	"local.5GC_DSCS/nef/openapi/models"
	"local.5GC_DSCS/nef/openapi/supported_feature"
	"local.5GC_DSCS/nef/nfconfig"
)

type caseValue struct{
	value interface{}
	valid bool
}

var (
	//nrfUri = 
	//nefUri = 
	serviceCases = []flute.Service{
		{
			Endpoint: "http://127.0.0.10:8000",
			Routes: []flute.Route{
				case1Route,
			},
		},
	}
	
	case1Route = flute.Route{
		Name: "case1",
		Matcher: flute.Matcher{
			Method: "PUT",
			Path:   "/nnrf-nfm/v1/nf-instances/aaaaaaaa-aaaa-4aaa-baaa-aaaaaaaaaaaa",
		},
		Tester: flute.Tester{
			BodyJSON: req_profile,
			Header: req_header,
		},
		Response: flute.Response{
			Base: http.Response{
				StatusCode: 201,
				Header: res_header,
			},
			BodyJSON: res_profile,
		},
	}
	case1_nfid = "aaaaaaaa-aaaa-4aaa-baaa-aaaaaaaaaaaa"
	nfConfig = nfconfig.NFConfig{
		Info: &nfconfig.Info{
			Version: "1.0.0",
			Description: "PCF initial local configuration",
		},
		Configuration: &nfconfig.Configuration{
			NefName: "NEF",
			Sbi: &nfconfig.Sbi{
				Scheme: "http",
				RegisterIPv4: "127.0.0.22",
				BindingIPv4: "127.0.0.22",
				Port: 8000,
			},
			TimeFormat: "2019-01-02 15:04:05",
			NrfUri: "http://127.0.0.10:8000",
			ServiceList: []nfconfig.Service {
				{
					ServiceName: "nnef-afsessionwithqos",
					SuppFeat: "",
				},
			},
		},
		Logger: &nfconfig.Logger{
			NEF: &nfconfig.LogSetting{
				DebugLevel: "info",
				ReportCaller: false,
			},
			OpenApi: &nfconfig.LogSetting{
				DebugLevel: "info",
				ReportCaller: false,
			},
			PathUtil: &nfconfig.LogSetting{
				DebugLevel: "info",
				ReportCaller:  false,
			},
		},
	}
	nfContext = nef_context.NEFContext {
		NfId: "aaaaaaaa-aaaa-4aaa-baaa-aaaaaaaaaaaa",
		Name: "NEF",
		UriScheme: "http",
		BindingIPv4: "127.0.0.22",
		RegisterIPv4: "127.0.0.22",
		SBIPort: 8000,
		TimeFormat: "2019-01-02 15:04:05",
		NfService: map[models.ServiceName]models.NfService {
			"nnef-afsessionwithqos": {
				ServiceInstanceId: "0",
				ServiceName: "nnef-afsessionwithqos",
				Versions: &[]models.NfServiceVersion{
					{
						ApiFullVersion:  "1.0.0",
						ApiVersionInUri: "v1",
					},
				},
				Scheme: "http",
				NfServiceStatus: "REGISTERED",
				ApiPrefix: "http://127.0.0.22:8000",
				IpEndPoints: &[]models.IpEndPoint{
					{
						Ipv4Address: "127.0.0.22",
						Transport: "TCP",
						Port: 8000,
					},
				},
				SupportedFeatures: "",
			},
		},
		NefServiceUris: map[models.ServiceName]string{
			"nnef-afsessionwithqos": "http://127.0.0.22:8000/nnef-afsessionwithqos/v1",
		},
		NefSuppFeats: map[models.ServiceName]supported_feature.SupportedFeature{
			"nnef-afsessionwithqos": {},
		},
		NrfUri: "http://127.0.0.10:8000",
	}
	req_profile = models.NfProfile{
		NfInstanceId: case1_nfid,
		NfType: "NEF",
		NfStatus: "REGISTERED",
		Ipv4Addresses: []string{
			"127.0.0.22",
		},
		NfServices: &[]models.NfService{
			{
				ServiceInstanceId: "0",
				ServiceName: "nnef-afsessionwithqos",
				Versions: &[]models.NfServiceVersion{
					{
						ApiVersionInUri: "v1",
						ApiFullVersion: "1.0.0",
					},
				},
				Scheme: "http",
				NfServiceStatus: "REGISTERED",
				IpEndPoints: &[]models.IpEndPoint{
					{
						Ipv4Address: "127.0.0.22",
						Transport: "TCP",
						Port: 8000,
					},
				},
				ApiPrefix: "http://127.0.0.22:8000",
			},
		},
	}
	req_header = http.Header{
		"Content-Type": []string{"application/json"},
		"Location": []string{"128.0.0.1:5487"}, //?
		"Accept": []string{"application/json"},
		"User-Agent": []string{"OpenAPI-Generator/1.0.0/go"},
	}
	res_profile = models.NfProfile{
		NfInstanceId: "aaaaaaaa-aaaa-4aaa-baaa-aaaaaaaaaaaa",
		NfType: "NEF",
		NfStatus: "REGISTERED",
		HeartBeatTimer: 0,
		Ipv4Addresses: []string{
			"127.0.0.22",
		},
		NfServices: &[]models.NfService{
			{
				ServiceInstanceId: "0",
				ServiceName: "nnef-afsessionwithqos",
				Versions: &[]models.NfServiceVersion{
					{
						ApiVersionInUri: "v1",
						ApiFullVersion: "1.0.0",
					},
				},
				Scheme: "http",
				NfServiceStatus: "REGISTERED",
				IpEndPoints: &[]models.IpEndPoint{
					{
						Ipv4Address: "127.0.0.22",
						Transport: "TCP",
						Port: 8000,
					},
				},
				ApiPrefix: "http://127.0.0.22:8000",
			},
		},
	}	
	res_header = http.Header{
		"Content-Type": []string{"application/json"},
		"Location": []string{"http://127.0.0.10:8000/nnrf-nfm/v1/nf-instances/aaaaaaaa-aaaa-4aaa-baaa-aaaaaaaaaaaa"},
		"Accept": []string{"application/json"},
		"User-Agent": []string{"OpenAPI-Generator/1.0.0/go"},
	}
)


func TestClient_CreateUser(t *testing.T) {
	nfconfig.InitNFConfig("../../../config/nefcfg.yaml")
	assert.Equalf(t, nfConfig, nfconfig.NefConfig, "not equa!?")

	self := nef_context.NEF_Self()
	self.InitnefContext(nfconfig.NefConfig)
	self.NfId = case1_nfid
	
	assert.Equalf(t, &nfContext, self, "not equa!?")

	profile, _ := BuildNFInstance(self)
	
	configuration := Nnrf_NFManagement.NewConfiguration()
	configuration.SetBasePath(self.NrfUri)
	client := Nnrf_NFManagement.NewAPIClient(configuration)

	configuration.HTTPClient().Transport = &flute.Transport{T: t, Services: serviceCases,}


	//var res *http.Response
	_, res, err := client.NFInstanceIDDocumentApi.RegisterNFInstance(context.TODO(), self.NfId, profile)
	require.Nil(t, err)
	assert.Equalf(t, 201, res.StatusCode, "not equa!?")
	/*
	defer func() {
		if resCloseErr := res.Body.Close(); resCloseErr != nil {
			fmt.Printf("RegisterNFInstance response body cannot close: %+v", resCloseErr)
		}
	}()
	*/
	/*
	status := res.StatusCode
		if status == http.StatusOK {
			// NFUpdate
			break
		} else if status == http.StatusCreated {
			// NFRegister
			break
		} else {
			fmt.Println("NRF return wrong status code", status)
		}
	*/
}
