package models

type CnfUnit struct {
	CnfUnit []Atom `json:"cnfUnit" bson:"cnfUnit"`
}
