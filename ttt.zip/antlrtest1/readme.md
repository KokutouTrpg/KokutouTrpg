java -jar antlr-4.7.1-complete.jar -Dlanguage=Python3 ./src/grammar/*.g4

call prepareVenv.bat


https://github.com/pyenv-win/pyenv-win#installation

https://www.python.org/ftp/python/3.7.9/python-3.7.9-amd64.exe