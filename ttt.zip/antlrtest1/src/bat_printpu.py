import printpu
def runMainProcess(root_path: str, requestClass):
		
		cname = (requestClass['packageName'] + "." +requestClass['className']).replace(".","_")
		endmethods = []
		callmethods = {}
		for method in requestClass['methods']:
			mname = method['methodName'].replace(".","_").split("@")[1]
			mtype = "S" if method['isStatic'] else "M"
			fname = root_path + cname+"."+mname+".pu"

			endmethods.append(cname+"@"+mname)

			include_list : list[str] = []
			call_list : list[str] = []
			for callMethod in method['callMethods']:
				tmp1 = callMethod.replace(".","_").split("@")
				tmp2 = tmp1[0].split("#")
				cmname = tmp1[1]
				ccname = tmp2[0]
				include = '!include %s.%s.pu!'%(ccname,cmname)
				if include not in include_list:
					include_list.append(include)
				if len(tmp2) == 1: 
					call = '$CALL_%s_%s(%s)'%(ccname,cmname,cname)
					call_list.append(call)
					cmtype="S"
				elif len(tmp2) == 2: 
					call = '$CALL_%s_%s(%s, $GET_CALLCOUNT_%s_CONSTRUCTOR())'%(ccname,cmname,cname,ccname)
					call_list.append(call)
					cmtype="M"
				cfname = root_path + ccname+"."+cmname+".pu"
				callmethods[ccname+"@"+cmname] = [ccname, cmname, cmtype, cfname]
				callmethods[ccname+"@LOAD"] = [ccname, "LOAD", "S", root_path + ccname+".LOAD.pu"]
			printpu.printPu(cname, mname, mtype, fname, include_list=include_list,call_list=call_list)
		for key in callmethods:
			if key not in endmethods:
				[cname, mname, mtype, fname] = callmethods[key]
				printpu.printPu(cname, mname, mtype, fname)

if __name__ == '__main__':
	requestClass = {
			'className': 'A',
			'methods': [
				{'callMethods': ['test.TestTargetSrc.A@CONSTRUCTOR'], 'isStatic': True, 'methodName': 'test.TestTargetSrc.A@LOAD'},
				{'callMethods': [], 'isStatic': True, 'methodName': 'A@CONSTRUCTOR'},
				{'callMethods': ['test.TestTargetSrc.A@staticA1'], 'isStatic': True, 'methodName': 'test.TestTargetSrc.A@CONSTRUCTOR'},
				{'callMethods': ['test.TestTargetSrc.A@staticA2', 'test.TestTargetSrc.A@staticA3', 'test.TestTargetSrc.A#I@menberA1', 'test.TestTargetSrc.B@staticB1', 'test.TestTargetSrc.B@CONSTRUCTOR', 'test.TestTargetSrc.B#I@menberB1'], 'isStatic': True, 'methodName': 'test.TestTargetSrc.A@staticA1'},
				{'callMethods': ['test.TestTargetSrc.A@staticA3'], 'isStatic': True, 'methodName': 'test.TestTargetSrc.A@staticA2'},
				{'callMethods': [], 'isStatic': True, 'methodName': 'test.TestTargetSrc.A@staticA3'},
				{'callMethods': ['test.TestTargetSrc.A#I@menberA2', 'test.TestTargetSrc.A#I@menberA3'], 'isStatic': False, 'methodName': 'test.TestTargetSrc.A#I@menberA1'},
				{'callMethods': ['test.TestTargetSrc.A#I@menberA3'], 'isStatic': False, 'methodName': 'test.TestTargetSrc.A#I@menberA2'},
				{'callMethods': [], 'isStatic': False, 'methodName': 'test.TestTargetSrc.A#I@menberA3'}
			],
			'packageName': 'test.TestTargetSrc'
		}
	runMainProcess("test/oooo/", requestClass)