import os
from pathlib import Path
import subprocess
import sys
from javaAnalyzer.JavaAnalyzer import JavaAnalyzer 

THIS_PYTHON_FILE : str

class Directory():
	def __init__(self, root_path: str):
		self.root_path = root_path
		self.code_file_list = []

	def find(self, query):
		result = Path(self.root_path).glob(query)
		self.code_file_list = []
		for f in result:
			code_file_path : str = str(f)
			code_file_id : str = code_file_path.replace(self.root_path + "\\", "").replace("\\", "_").replace(".java", "")
			self.code_file_list.append((code_file_path, code_file_id))
		return self.code_file_list

def getFileName(code_file_path: str):
	start = code_file_path.rfind("\\") + 1
	end = code_file_path.rfind(".")
	return code_file_path[start:end]

def runMainProcess(root_path: str):
	code_file_list : list[tuple[str,str]]  = Directory(root_path).find("**\\*.java")
	if os.path.isdir('out') == False:
		os.mkdir('out')
	if os.path.isdir('out\\scu') == False:
		os.mkdir('out\\scu')
	for code_file in code_file_list:
		print(code_file)
		out_file_path = "./out/" + code_file[1] + ".out"
		print(out_file_path)
		with open(out_file_path, "w") as out_file:
			cmd = ["python", THIS_PYTHON_FILE, "-codefilepath", code_file[0], "-codefileid", code_file[1]]
			subprocess.run(cmd, stdout = out_file)

def runSubProcess(code_file_path: str, code_file_id: str):
	JavaAnalyzer().execute(code_file_path, code_file_id)

if __name__ == '__main__':
	THIS_PYTHON_FILE = sys.argv[0] 
	if len(sys.argv) == 2:
		runMainProcess(sys.argv[1])
	if len(sys.argv) == 5:
		runSubProcess(sys.argv[2], sys.argv[4])