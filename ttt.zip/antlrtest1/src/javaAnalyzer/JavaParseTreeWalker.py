from antlr4 import ParseTreeWalker
from antlr4 import ParseTreeListener, RuleNode
import inspect

class JavaParseTreeWalker(ParseTreeWalker):
	def enterRule(self, listener:ParseTreeListener, r:RuleNode):
		ctx = r.getRuleContext()
		print("%s[%s] %s"%("\t"*ctx.depth(), inspect.currentframe().f_code.co_name, type(ctx).__name__),ctx.getText())
		listener.enterEveryRule(ctx)
		ctx.enterRule(listener)

	def exitRule(self, listener:ParseTreeListener, r:RuleNode):
		ctx = r.getRuleContext()
		#print("%s[%s] %s"%("\t"*ctx.depth(), inspect.currentframe().f_code.co_name, type(ctx).__name__))
		ctx.exitRule(listener)
		listener.exitEveryRule(ctx)