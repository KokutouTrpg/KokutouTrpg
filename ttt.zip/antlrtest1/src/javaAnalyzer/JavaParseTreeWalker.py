from io import FileIO
from antlr4.tree.Tree import ParseTreeWalker, ParseTree, ErrorNode, TerminalNode
from antlr4 import ParseTreeListener, RuleNode
import inspect

class JavaParseTreeWalker(ParseTreeWalker):
	current_ctxid : int = -1
	parents_ctxid : list[int] = [] 

	def walk(self, listener:ParseTreeListener, t:ParseTree, file: FileIO):

		#"""
		ctx = t#t.getRuleContext()
		self.current_ctxid = self.current_ctxid + 1
		if ctx.getChildCount() == 0:
			label = "{ %s | %s }"%(type(ctx).__name__, ctx.getText())
		else:
			label = "{ %s }"%(type(ctx).__name__)
		print( 'p%d [shape=record, label="%s"]'%(self.current_ctxid, label),file=file)
		self.parents_ctxid.append(self.current_ctxid)
		if len(self.parents_ctxid) > 1:
			print("p%d -> p%d"%(self.parents_ctxid[-2],self.parents_ctxid[-1]),file=file)
		#"""

		if isinstance(t, ErrorNode):
			listener.visitErrorNode(t)
			self.parents_ctxid.pop()
			return
		elif isinstance(t, TerminalNode):
			listener.visitTerminal(t)
			self.parents_ctxid.pop()
			return
		self.enterRule(listener, t, file)
		for child in t.getChildren():
			self.walk(listener, child, file)
		self.exitRule(listener, t, file)
		self.parents_ctxid.pop()
				

	def enterRule(self, listener:ParseTreeListener, r:RuleNode, file:FileIO):
		ctx = r.getRuleContext()
		

		#"""
		print("%s[%s] %s"%("\t"*ctx.depth(), inspect.currentframe().f_code.co_name, type(ctx).__name__),ctx.getText())
		#"""

		listener.enterEveryRule(ctx)
		ctx.enterRule(listener)

	def exitRule(self, listener:ParseTreeListener, r:RuleNode, file:FileIO):
		ctx = r.getRuleContext()
		#print("%s[%s] %s"%("\t"*ctx.depth(), inspect.currentframe().f_code.co_name, type(ctx).__name__))
		ctx.exitRule(listener)
		listener.exitEveryRule(ctx)
