from pprint import pformat
from multiprocessing import  Queue
import time
from antlr4.tree.Trees import Trees
from antlr4 import FileStream, CommonTokenStream, ParseTreeWalker, InputStream
from grammar.JavaLexer import JavaLexer
from grammar.JavaParser import JavaParser
from javaAnalyzer.BasicInfoListener import BasicInfoListener
from javaAnalyzer.JavaParseTreeWalker import JavaParseTreeWalker

class JavaAnalyzer:
	# 初期化関数
	def __init__(self):
		self.listener = BasicInfoListener()

	# 実行関数
	def execute(self, code_file_path : str, code_file_id: str, q: Queue):
		print("Start worker", code_file_path, code_file_id)
		fs = FileStream(code_file_path, encoding="utf-8")
		jl = JavaLexer(fs)
		cts = CommonTokenStream(jl)
		self.parser = JavaParser(cts)
		walker = JavaParseTreeWalker()
		walker.walk(self.listener, self.parser.compilationUnit())
		print('Display all data extracted by AST. \n' + pformat(self.listener.ast_info, width=160))
		q.put("parser")
		print("End worker", code_file_path, code_file_id)
