import os
from pathlib import Path
from multiprocessing import Process, Queue
import sys
from antlr4 import InputStream, CommonTokenStream
from grammar.JavaLexer import JavaLexer
from grammar.JavaParser import JavaParser
from javaAnalyzer.BasicInfoListener import BasicInfoListener
from javaAnalyzer.JavaAnalyzer import JavaAnalyzer
from javaAnalyzer.JavaParseTreeWalker import JavaParseTreeWalker 

from antlr4.tree.Trees import Trees
THIS_PYTHON_FILE : str

class Directory():
	def __init__(self, root_path: str):
		self.root_path = root_path
		self.code_file_list = []

	def find(self, query):
		result = Path(self.root_path).glob(query)
		self.code_file_list = []
		for f in result:
			code_file_path : str = str(f)
			code_file_id : str = code_file_path.replace(self.root_path + "\\", "").replace("\\", "_").replace(".java", "")
			self.code_file_list.append((code_file_path, code_file_id))
		return self.code_file_list

def getFileName(code_file_path: str):
	start = code_file_path.rfind("\\") + 1
	end = code_file_path.rfind(".")
	return code_file_path[start:end]

def runMainProcess(root_path: str):
	code_file_list : list[tuple[str,str]]  = Directory(root_path).find("**\\*.java")
	q = Queue()
	process_list : list[Process] = []
	cu_dict : dict[str, JavaParser] = {}
	for code_file in code_file_list:
		process_list.append(Process(target=worker, args=(code_file[0], code_file[1], q,)))
		process_list[-1].start()
		cu_dict[code_file[1]] = q.get()
	for process in process_list:
		process.join()

	for key in cu_dict:
		print(cu_dict[key])

def worker(code_file_path: str, code_file_id: str, q: Queue):
	JavaAnalyzer().execute(code_file_path, code_file_id, q)

if __name__ == '__main__':
	THIS_PYTHON_FILE = sys.argv[0] 
	if len(sys.argv) == 2:
		runMainProcess(sys.argv[1])