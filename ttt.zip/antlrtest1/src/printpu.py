from io import FileIO
import os
import sys

def printCheckTop(cname : str, mname : str, mtype : str, file : FileIO):
	print('\t\'### CHECK TOP #########################################\' ', file = file)
	print('\t!$TOP ?= 0', file = file)
	print('\t!$CALL_FIRST_%s_%s ?= 0'%(cname, mname), file = file)
	print('\t!if $TOP == 0', file = file)
	print('\t\t!$TOP= 1', file = file)
	print('\t\t!$CALL_FIRST_%s_%s = 1'%(cname, mname), file = file)
	print('\t!endif', file = file)
	print('\t\'#######################################################\' ', file = file)
	print('\t', file = file)

def printInclude(cname : str, mname : str, mtype : str, file : FileIO, include_list : list[str] = []):
	print('\t\'#### INCLUDE ##########################################\' ', file = file)
	if mname != "LOAD":
		print('\t!include %s.LOAD.pu!'%(cname), file = file)
		#print('\tnewpage', file = file)
	if mtype == "M":
		print('\t!include %s.CONSTRUCTOR.pu!'%(cname), file = file)
	for include in include_list:
		print('\t%s'%(include), file = file)
	print('\t\'#######################################################\' ', file = file)
	print('\t', file = file)

def printCallCount(cname : str, mname : str, mtype : str, file : FileIO):
	print('\t\'#### CALLCOUNT ########################################\' ', file = file)
	print('\t!$CALLCOUNT_%s_%s ?= 0'%(cname, mname), file = file)
	print('\t!function $COUNTUP_CALLCOUNT_%s_%s()'%(cname, mname), file = file)
	print('\t\t!$CALLCOUNT_%s_%s = $CALLCOUNT_%s_%s + 1'%(cname, mname, cname, mname), file = file)
	print('\t\t!return $CALLCOUNT_%s_%s'%(cname, mname), file = file)
	print('\t!endfunction', file = file)
	print('\t!function $GET_CALLCOUNT_%s_%s()'%(cname, mname), file = file)
	print('\t\t!return $CALLCOUNT_%s_%s'%(cname, mname), file = file)
	print('\t!endfunction', file = file)
	print('\t\'#### CALLCOUNT ########################################\' ', file = file)
	print('\t', file = file)

def printCall(cname : str, mname : str, mtype : str, file : FileIO, call_list: list[str] = []):
	print('\t\'#### CALL #############################################\' ', file = file)
	if mname == "LOAD":
		print('\t!procedure $CALL_%s_%s()'%(cname, mname), file = file)
	elif mtype == "M":
		print('\t!procedure $CALL_%s_%s($callby, $instance)'%(cname, mname), file = file)
	elif mtype == "S":
		print('\t!procedure $CALL_%s_%s($callby)'%(cname, mname), file = file)
	print('\t\t!$count = $COUNTUP_CALLCOUNT_%s_%s()'%(cname, mname), file = file)
	if mname == "LOAD":
		print('\t\t?-> %s : LOAD'%(cname), file = file)
		print('\t\tactivate %s'%(cname), file = file)
		for call in call_list:
			print('\t\t\t%s'%(call), file = file)
		print('\t\t?<-[hidden]- %s'%(cname), file = file)
		print('\t\tdeactivate %s'%(cname), file = file)
	elif mname == "CONSTRUCTOR":
		print('\t\tparticipant "%s[$count]" as %s.$count'%(cname, cname), file = file)
		print('\t\t$callby -> %s.$count : new'%(cname), file = file)
		print('\t\tactivate %s.$count #00AAFF'%(cname), file = file)
		print('\t\tactivate %s.$count'%(cname), file = file)
		for call in call_list:
			print('\t\t\t%s'%(call), file = file)
		print('\t\t$callby <-[hidden]- %s.$count'%(cname), file = file)
		print('\t\tdeactivate %s.$count'%(cname), file = file)
	elif mtype == "M":
		print('\t\t$callby -> %s.$instance : %s[##$count##]'%(cname, mname), file = file)
		print('\t\tactivate %s.$instance'%(cname), file = file)
		for call in call_list:
			print('\t\t%s'%(call), file = file)
		print('\t\t$callby <-- %s.$instance'%(cname), file = file)
		print('\t\tdeactivate %s.$instance'%(cname), file = file)
	elif mtype == "S":
		print('\t\t$callby -> %s : %s[##$count##]'%(cname, mname), file = file)
		print('\t\tactivate %s'%(cname), file = file)
		for call in call_list:
			print('\t\t%s'%(call), file = file)
		print('\t\t$callby <-- %s'%(cname), file = file)
		print('\t\tdeactivate %s'%(cname), file = file)
	print('\t!endprocedure', file = file)
	print('\t\'#######################################################\' ', file = file)
	print('\t', file = file)

def printCallByTop(cname : str, mname : str, mtype : str, file : FileIO):
	print('\t\'#### CALL by TOP ######################################\' ', file = file)
	if mname == "LOAD":
		print('\t\t$CALL_%s_%s()'%(cname, mname), file = file)
	else:
		print('\t!if $CALL_FIRST_%s_%s == 1'%(cname, mname), file = file)
		if mtype == "M":
			print('\t\t!if $GET_CALLCOUNT_%s_CONSTRUCTOR() == 0'%(cname), file = file)
			print('\t\t\t$CALL_%s_CONSTRUCTOR(" ")'%(cname), file = file)
			print('\t\t!endif', file = file)
			print('\t\t$CALL_%s_%s(" ", $GET_CALLCOUNT_%s_CONSTRUCTOR())'%(cname, mname, cname), file = file)
		elif mtype == "S":
			print('\t\t$CALL_%s_%s(" ")'%(cname, mname), file = file)
		print('\t!endif', file = file)
	print('\t\'#######################################################\' ', file = file)
	print('\t', file = file)

def printPu(cname : str, mname : str, mtype : str, fname : str = None, include_list : list[str] = [], call_list : list[str] = []):
	
	if fname is None:
		print('!$INCLUDED_%s_%s ?= 0'%(cname, mname), file = sys.stdout)
		print('!if $INCLUDED_%s_%s == 0'%(cname, mname), file = sys.stdout)
		print('\t!$INCLUDED_%s_%s = 1'%(cname, mname), file = sys.stdout)
		print('\t', file = sys.stdout)
		printCheckTop(cname, mname, mtype, sys.stdout)
		printCallCount(cname, mname, mtype, sys.stdout)
		printCall(cname, mname, mtype, sys.stdout, call_list = call_list)
		printInclude(cname, mname, mtype, sys.stdout, include_list = include_list)
		printCallByTop(cname, mname, mtype, sys.stdout)
		print('!endif', file = sys.stdout)
	else:		
		if not os.path.exists(fname):
			with open(fname, 'w') as file:
				print('!$INCLUDED_%s_%s ?= 0'%(cname, mname), file = file)
				print('!if $INCLUDED_%s_%s == 0'%(cname, mname), file = file)
				print('\t!$INCLUDED_%s_%s = 1'%(cname, mname), file = file)
				print('\t', file = file)
				printCheckTop(cname, mname, mtype, file)
				printCallCount(cname, mname, mtype, file)
				printCall(cname, mname, mtype, file, call_list = call_list)
				printInclude(cname, mname, mtype, file, include_list = include_list)
				printCallByTop(cname, mname, mtype, file)
				print('!endif', file = file)

if __name__ == '__main__':
	cname = sys.argv[1] # クラス名
	mname = sys.argv[2] # 関数名(コンストラクタはCONSTRUCTOR)
	mtype = sys.argv[3] # 関数種類 M or S (コンストラクタはS)
	fname = sys.argv[4]
	printPu(cname, mname, mtype, fname)