package test.TestTargetSrc;

public class A {
	public static A a = new A();
	public static int sinta = 1;
	public B b = new B();
	public C c;

	public A() {
		c = new C();
		A a2 = new A();
	}

	public A(int a) {
		staticA1();
	}

	public A(A a) {

	}

	public static void staticA1() {
		int inta = staticA2() + staticA3();
		a.menberA1();
		B.staticB1();
		a.b.menberB1();
		a.c.menberC();
	}

	public static int staticA2() {
		return staticA3();
	}

	public static int staticA3() {
		return sinta;
	}

	public void menberA1() {
		int inta = this.menberA2() + this.menberA3();
	}

	public int menberA2() {
		return menberA3();
	}

	public int menberA3() {
		return 1;
	}

	public class C {
		public C() {

		}

		public void menberC() {

		}
	}
}