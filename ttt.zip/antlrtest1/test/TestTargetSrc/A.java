package test.TestTargetSrc;

class E extends Exception {
	public String msg;

	E(String s) {
		msg = s;
	}

	public void menberE1() {
		msg.toCharArray();
	}

}

public class A {
	public static A a = new A(1);
	public static int sinta = 1;
	public B b = new B();
	public C c;

	A() {
		c = new C();
		A a2 = new A();
	}

	A(int a) {
		try {
			staticA1();
		} catch (E e) {
			e.menberE1();
		}
	}

	public A(A a) {
		try {
			staticA1();
		} catch (E e) {
			e.menberE1();
		}
	}

	public static void staticA1() throws E {
		if (staticA2() + staticA3() == 0) {
			a.menberA1();
			B.staticB1();
			throw new E("");
		}
		a.b.menberB1();
		a.c.menberC();
	}

	public static int staticA2() {
		return staticA3();
	}

	public static int staticA3() {
		return sinta;
	}

	public void menberA1() {
		int inta = this.menberA2() + this.menberA3();
	}

	public int menberA2() {
		return menberA3();
	}

	public int menberA3() {
		return 1;
	}

	public class C {
		public C() {

		}

		public void menberC() {

		}
	}
}