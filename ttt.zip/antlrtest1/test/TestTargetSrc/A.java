package test.TestTargetSrc;

public class A {
	public static A a = new A();
	public static int sinta = 1;

	public A() {

	}

	public A(int a) {
		staticA1();
	}

	public static void staticA1() {
		int inta = staticA2() + staticA3();
		a.menberA1();
		B.staticB1();
		B b = new B();
		b.menberB1();
	}

	public static int staticA2() {
		return staticA3();
	}

	public static int staticA3() {
		return sinta;
	}

	public void menberA1() {
		int inta = this.menberA2() + this.menberA3();
	}

	public int menberA2() {
		return menberA3();
	}

	public int menberA3() {
		return 1;
	}
}