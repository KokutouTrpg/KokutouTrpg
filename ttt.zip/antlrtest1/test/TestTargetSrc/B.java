package test.TestTargetSrc;

public class B {
	public static void staticB1() {
		staticB2();
	}

	public static void staticB2() {
		staticB3();
	}

	public static void staticB3() {
		// do something
	}

	public void menberB1() {
		menberB2().menberB3();
	}

	public B menberB2() {
		return this;
	}

	public B menberB3() {
		return this;
	}
}