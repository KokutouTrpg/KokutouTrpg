package test.TestTargetSrc.C;

public class C {
	public static void staticC1(String[] args) {
		staticC2();
	}

	public static void staticC2() {
		staticC3();
	}

	public static void staticC3() {
		// do something
	}
}