import java.io.File;
import java.io.FileInputStream;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        String dpath = "./TestTargetJavaProject/test1/src/";
        // String dpath = "./src/";
        File dir = new File(dpath);
        File[] flist = dir.listFiles();
        Java8ParserBaseListener listener = new Java8ParserBaseListener();
        for (File f : flist) {
            listener.walk(f);
        }
        System.out.println("-------------------------------------------------------------------------");
        listener.printCallTree();
    }
}
