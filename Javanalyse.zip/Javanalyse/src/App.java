import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

public class App {
    public static void main(String[] args) throws Exception {
        refirectSystemOut();
        String dpath = "./TestTargetJavaProject/test1/src/";
        // String dpath = "./src/";
        File dir = new File(dpath);
        File[] flist = dir.listFiles();
        MyJava8ParserListener listener = new MyJava8ParserListener();
        for (File f : flist) {
            listener.walk(f);
        }
        listener.printContextTree();
        // listener.printCallTree();
    }

    private static void refirectSystemOut() {
        try {
            // 出力先のファイルを指定
            File file = new File("a.pu");

            // PrintStreamをファイルに設定
            PrintStream printStream = new PrintStream(file);

            // System.outをファイルにリダイレクト
            System.setOut(printStream);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}