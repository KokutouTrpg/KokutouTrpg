public class Bpp {

    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
    }

    public static void static_a() throws Exception {
        App app = new App();
        app.a();
        Thread th = () -> app.a();
        th.start();
    }

    public static void static_b() throws Exception {
        static_c();
    }

    public static void static_c() throws Exception {
    }

    public void a() throws Exception {
    }

    public void b() throws Exception {
        this.a();
    }

    public void c(App a) throws Exception {
        a.a();
    }
}
