public class App {

    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
    }

    public static void static_a() throws Exception {
        App app = new App();
        app.a();
        Thread th1 = () -> app.a();
        Thread th2 = () -> {
            new App();
        };
        th1.start();
        th2.start();
    }

    public static void static_b() throws Exception {
        static_c();
    }

    public static void static_c() throws Exception {
    }

    public void a() throws Exception {
    }

    public void b() throws Exception {
        this.a();
    }

    public void c(App a) throws Exception {
        a.a();
    }

    public void d(App a) throws Exception {
        a.c(new App());
    }

    class SubApp extends Bpp {
        SubApp(int a) {
            this();
        }

        SubApp() {
            super();
        }

        SubApp(long a) {
            App.super();
        }

        @Override
        public void a() {
            App.static_a();
            App.this.a();
            a();
            super.a();
        }
    }
}
