from http.server import HTTPServer
from http.server import BaseHTTPRequestHandler


class CustomHTTPRequestHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', "text/html")
        self.end_headers()
        html_context = '<html lang="ja">' \
                       '<meta charset="UTF-8"><form method="POST" action="/"><input type="submit" value="送信"></form>' \
                       '</html>'
        self.wfile.write(html_context.encode())

    def do_PUT(self):
		# リクエスト確認
        print("------------client_address------------\n{}".format(self.client_address))
        print("------------command------------\n{}".format(self.command))
        print("------------request_version------------\n{}".format(self.request_version))
        print("------------headers------------\n{}".format(self.headers))
        print("------------path------------\n{}".format(self.path))
        print("------------requestline------------\n{}".format(self.requestline))
        print("------------rfile_fsize------------")
        i = 0
        rfsize_s = ""
        while True:
            rd = self.rfile.read(1)
            print("|%3d|%2s|%2s|"%(i,rd.hex(),rd))
            i = i+ 1
            if rd == b'\r':
                continue
            rfsize_s = rfsize_s + rd.decode('utf-8')
            if rd == b'\n':
                break
        rfsize = int(rfsize_s,16)
        print(rfsize)
        rd = self.rfile.read(rfsize)
        print("------------rfile_body[Byte]------------")
        print(rd)
        print("------------rfile_body[Utf-8]------------")
        print(rd.decode('utf-8'))
        print("------------rfile_body[hex]------------")
        print(rd.hex())
        print("-----------------------------")
        # 応答
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.end_headers()
        html_context = "送信完了"
        self.wfile.write(html_context.encode())


server_address = ('127.0.0.10', 8080)
httpd = HTTPServer(server_address, CustomHTTPRequestHandler)
httpd.serve_forever()