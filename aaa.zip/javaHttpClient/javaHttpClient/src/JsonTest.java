import com.carrotsearch.sizeof.RamUsageEstimator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Map;

import org.apache.commons.codec.binary.Hex;

public class JsonTest {

    public static void main(String[] args) throws Exception {
        Runtime r = Runtime.getRuntime();
        try {
            String path = Paths.get("").toAbsolutePath().toString() + "\\javaHttpClient\\in\\test_in.json";
            FileInputStream fis = new FileInputStream(path);
            InputStream is = new FilterInputStream(fis) {
                private final int MAX_READ_BYTES = 4;

                @Override
                public int read() throws IOException {
                    int readByte = in.read();
                    int readByteLength = 4;
                    String readByteLength_str = String.format("%4d / %4d [Bytes]", readByteLength, 4);
                    String readByte_str = String.format("%4x", readByte);
                    System.out.println("    |read|1|" + readByteLength_str + "|" + readByte_str + "|");
                    return readByte;
                }

                @Override
                public int read(byte b[]) throws IOException {
                    return read(b, 0, b.length);
                }

                @Override
                public int read(byte bout[], int off, int len) throws IOException {

                    byte bin[] = new byte[MAX_READ_BYTES];
                    int readByteLength = in.read(bin, 0, MAX_READ_BYTES);
                    if (readByteLength > 0) {
                        System.arraycopy(bin, 0, bout, 0, MAX_READ_BYTES);
                        String readLen_str = String.format("%4d / %4d [Bytes]", readByteLength, len);
                        byte bout_sub[] = Arrays.copyOfRange(bout, off, readByteLength);
                        String readByte_str = new String(Hex.encodeHex(bout_sub));
                        String read_str = new String(bout_sub, StandardCharsets.UTF_8);
                        // System.out.println(" |read|2|" + readLen_str + "|" + readByte_str + "|" +
                        // read_str + "|");
                    } else {

                        String readLen_str = String.format("%4d / %4d [Bytes]", 0, len);
                        // System.out.println(" |read|2|" + readLen_str + "|");
                    }
                    return readByteLength;
                }

                @Override
                public void close() throws IOException {
                    super.close();
                    // System.out.println(" |close|");
                }

            };
            ObjectMapper mapper = new ObjectMapper();
            JsonParser jp = mapper.createParser(is);
            long firstJpBytes = RamUsageEstimator.sizeOf(jp);
            long endJpBytes = firstJpBytes;
            long maxJpBytes = firstJpBytes;
            int depth = 0;
            int max_depth = depth;
            long max_depth_maxJpBytes = depth;
            while (true) {
                long beforeJpBytes = RamUsageEstimator.sizeOf(jp);
                JsonToken jt = jp.nextToken();
                if (jt == null) {
                    break;
                }
                if (jt.isStructStart()) {
                    depth++;
                    if (depth > max_depth) {
                        max_depth = depth;
                    }
                }
                if (jt.isStructEnd()) {
                    depth--;
                }
                r.gc();
                long currentJpBytes = RamUsageEstimator.sizeOf(jp);
                endJpBytes = currentJpBytes;
                if (currentJpBytes > maxJpBytes) {
                    maxJpBytes = currentJpBytes;
                    max_depth_maxJpBytes = depth;
                }
                // System.out.print(firstJpBytes + " + " + (currentJpBytes - firstJpBytes));
                // System.out.print("(" + (currentJpBytes - beforeJpBytes) + ")");
                // System.out.print(" [" + depth + "]");
                // System.out.println(" | " + jt + " |");
            }
            System.out.print(firstJpBytes + " + " + (endJpBytes - firstJpBytes));
            System.out.print("(" + (maxJpBytes - firstJpBytes) + "[" + max_depth_maxJpBytes + "])");
            System.out.println("[" + max_depth + "]");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}