import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URI;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;
import java.util.function.Function;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.logging.Log;
import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.Args;
import org.apache.http.util.EntityUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.function.TriFunction;

public class App {
    private static LinkedList<ExecutionLog> executionLogs = new LinkedList<ExecutionLog>();

    private static long getFileSize(String file_path) throws IOException {
        return Files.size(Paths.get(file_path));
    }

    private static void createRandomTxtFile(String file_path, int len) throws IOException {
        // FileWriterクラスのオブジェクトを生成する
        FileWriter file = new FileWriter(file_path);
        // PrintWriterクラスのオブジェクトを生成する
        PrintWriter pw = new PrintWriter(new BufferedWriter(file));

        // ファイルに書き込む
        pw.print(RandomStringUtils.randomAlphanumeric(len));

        // ファイルを閉じる
        pw.close();
    }

    public static void addExecutionLog(String cname, String params, long startNT, long endNT, String message) {
        Thread cth = Thread.currentThread();
        String tname = cth.getName();
        StackTraceElement ste = cth.getStackTrace()[2];
        String mname = ste.getMethodName();
        int depth = cth.getStackTrace().length;
        executionLogs.addLast(
                new ExecutionLog(tname, cname, mname, params, startNT, endNT, message, depth));

    }

    public static void main(String[] args) {

        try {
            String cdir_path = Paths.get("").toAbsolutePath().toString() + "\\javaHttpClient\\inout\\";
            String infile_path = cdir_path + "in.txt";
            String outfile_path = cdir_path + "out.txt.gz";

            // createRandomTxtFile(infile_path, 1024 * 1024 * 50);
            createRandomTxtFile(infile_path, 1024 * 1024);
            byte[] buf = new byte[500 * 1024];
            // 圧縮元ファイルへのストリームを開く
            FileInputStream fis = new FileInputStream(infile_path) {
                @Override
                public int read() throws IOException {
                    long startNT = System.nanoTime();
                    int result = super.read();
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "", startNT, endNT, "Read " + result + " Bytes.");
                    return result;
                }

                @Override
                public int read(byte b[]) throws IOException {
                    long startNT = System.nanoTime();
                    int result = super.read(b);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[]", startNT, endNT, "Read " + result + " Bytes.");
                    return result;
                }

                @Override
                public int read(byte b[], int off, int len) throws IOException {
                    long startNT = System.nanoTime();
                    int result = super.read(b, off, len);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[], int off, int len", startNT, endNT, "Read " + result + " Bytes.");
                    return result;
                }
            };
            BufferedInputStream bis = new BufferedInputStream(fis) {
                @Override
                public int read() throws IOException {
                    long startNT = System.nanoTime();
                    int result = super.read();
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "", startNT, endNT, "Read " + result + " Bytes.");
                    return result;
                }

                @Override
                public int read(byte b[]) throws IOException {
                    long startNT = System.nanoTime();
                    int result = super.read(b);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[]", startNT, endNT, "Read " + result + " Bytes.");
                    return result;
                }

                @Override
                public int read(byte b[], int off, int len) throws IOException {
                    long startNT = System.nanoTime();
                    int result = super.read(b, off, len);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[], int off, int len", startNT, endNT, "Read " + result + " Bytes.");
                    return result;
                }
            };
            // 圧縮先ファイルへのストリームを開く
            FileOutputStream fos = new FileOutputStream(outfile_path) {
                @Override
                public void write(int b) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "int b", startNT, endNT, "Write 4 Bytes.");
                }

                @Override
                public void write(byte b[]) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[]", startNT, endNT, "Write " + b.length + " Bytes.");
                }

                @Override
                public void write(byte b[], int off, int len) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b, off, len);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[], int off, int len", startNT, endNT, "Write " + len + " Bytes.");
                }
            };
            BufferedOutputStream bos = new BufferedOutputStream(fos, 1024 * 2) {
                @Override
                public void write(int b) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "int b", startNT, endNT, "Write 4 Bytes.");
                }

                @Override
                public void write(byte b[]) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[]", startNT, endNT, "Write " + b.length + " Bytes.");
                }

                @Override
                public void write(byte b[], int off, int len) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b, off, len);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[], int off, int len", startNT, endNT, "Write " + len + " Bytes.");
                }
            };
            GZIPOutputStream gos = new GZIPOutputStream(bos, 1024 * 8) {
                @Override
                public void write(int b) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "int b", startNT, endNT, "Write 4 Bytes.");
                }

                @Override
                public void write(byte b[]) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[]", startNT, endNT, "Write " + b.length + " Bytes.");
                }

                @Override
                public void write(byte b[], int off, int len) throws IOException {
                    long startNT = System.nanoTime();
                    super.write(b, off, len);
                    long endNT = System.nanoTime();
                    String cname = this.getClass().getSuperclass().getSimpleName();
                    addExecutionLog(cname, "byte b[], int off, int len", startNT, endNT, "Write " + len + " Bytes.");
                }
            };
            // データを圧縮して書き込む
            int size;
            do {
                size = fis.read(buf, 0, buf.length);
                if (size != -1) {
                    gos.write(buf, 0, size);
                }
            } while (size != -1);
            /*
             * while ((size = fis.read(buf, 0, buf.length)) != -1) {
             * gos.write(buf, 0, size);
             * }
             */
            gos.flush();
            gos.close();
            bis.close();
            System.out.println("File: in.txt = " + getFileSize(infile_path));
            System.out.println("File: out.txt = " + getFileSize(outfile_path));
            for (ExecutionLog el : executionLogs) {
                el.printlog();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static class ExecutionLog {
        private String threadName;
        private String className;
        private String methodName;
        private String params;
        private long startTime;
        private long endTime;
        private String message;
        private int depth;

        public ExecutionLog(String threadName, String className, String methodName, String params, long startTime,
                long endTime,
                String message, int depth) {
            this.threadName = threadName;
            this.className = className;
            this.methodName = methodName;
            this.params = params;
            this.startTime = startTime;
            this.endTime = endTime;
            this.message = message;
            this.depth = depth;
        }

        public void printlog() {
            System.out.println("[" + threadName + "]" + className + "." + methodName
                    + "(" + params + ") executeTime = "
                    + (endTime - startTime) + "(" + startTime + " - " + endTime + ") : " + message);
        }
    }
}