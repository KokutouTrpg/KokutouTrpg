#!/usr/bin/env python3

#Built-in imports
import datetime
import selectors
import socket
from threading import Thread, Event
import traceback
import sys
import time
import struct
import urllib.error
import argparse
import json
from logging import getLogger, config

with open('./log_config.json', 'r') as f:
	log_conf = json.load(f)

config.dictConfig(log_conf)
logger = getLogger(__name__)
logger.info('message')

t_delta=datetime.timedelta(hours=9)
JST=datetime.timezone(t_delta,'JST')

#JDWP protocol variables
HANDSHAKE=b"JDWP-Handshake"
HANDSHAKE1=b"JDWP-Handshak1"
HANDSHAKE2=b"JDWP-Handshak2"
HANDSHAKE3=b"JDWP-Handshak3"

#Command signatures
VERSION_SIG=(1,1)
CLASSESBYSIGNATURE_SIG=(1,2)
ALLCLASSES_SIG=(1,3)
ALLTHREADS_SIG=(1,4)
IDSIZES_SIG=(1,7)
CREATESTRING_SIG=(1,11)
SUSPENDVM_SIG=(1,8)
RESUMEVM_SIG=(1,9)
SIGNATURE_SIG=(2,1)
FIELDS_SIG=(2,4)
METHODS_SIG=(2,5)
GETVALUES_SIG=(2,6)
CLASSOBJECT_SIG=(2,11)
INVOKESTATICMETHOD_SIG=(3,3)
REFERENCETYPE_SIG=(9,1)
INVOKEMETHOD_SIG=(9,6)
STRINGVALUE_SIG=(10,1)
THREADNAME_SIG=(11,1)
THREADSUSPEND_SIG=(11,2)
THREADRESUME_SIG=(11,3)
THREADSTATUS_SIG=(11,4)
THREADFRAMES_SIG=(11,6)
EVENTSET_SIG=(15,1)
EVENTCLEAR_SIG=(15,2)
EVENTCLEARALL_SIG=(15,3)

#Other codes
MODKIND_COUNT=1
MODKIND_THREADONLY=2
MODKIND_CLASSMATCH=5
MODKIND_LOCATIONONLY=7
EVENT_BREAKPOINT=2
SUSPEND_NONE=0
SUSPEND_EVENTTHREAD=1
SUSPEND_ALL=2
NOT_IMPLEMENTED=99
VM_DEAD=112
INVOKE_SINGLE_THREADED=2
TAG_OBJECT=76
TAG_STRING=115
TYPE_CLASS=1

class Singleton(object):
	def __new__(cls, *args, **kargs):
		if not hasattr(cls, "_instance"):
			cls._instance = super(Singleton, cls).__new__(cls)
		return cls._instance
	
class JDWPClient(Singleton):

	def __init__(self,host:str,port:int=8000) -> None:
		self._host=host
		self._port=port
		self._socket=None

	def __enter__(self):
		logger.info("[+] Enter JDWPClient")
		self.open()
		self._socketReceiver = self.SocketReceiver(self._socket)
		self._socketReceiver.start()
		return self

	def open(self) -> None:
		logger.info("[+] Open JDWPClient's socket")
		self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self._socket.setblocking( False ) 
		try:
			logger.info(f"[+] Trying to connect {self._host}:{self._port}")
			self._socket.connect((self._host, self._port))
		except socket.error as e:
			raise Exception(f"[-] Failed to connect: {e}")
		else:
			logger.info(f"[+] Success to connect")

	def close(self) -> None:
		if self._socket:
			self._socket.close()
			self._socket=None
		logger.info("[+] Close JDWPClient's socket")

	def __exit__(self,exc_type,exc_value,traceback):
		self._socketReceiver.stop()
		self.close()
		logger.info("[+] Exit JDWPClient")
			
	def send(self,buf):
		logger.info("[+] Start JDWPClient's send Method")
		self._socket.send(buf)
		logger.info("[+] End JDWPClient's send Method")
	
	def sendHandshake(self):
		self.send(HANDSHAKE)
		
	class SocketReceiver(Thread):
		def __init__(self,socket) -> None:
			Thread.__init__(self)
			self._socket = socket
			self._isStop = False
			self._packetCount=0

		def start(self) -> None:
			logger.info("[+] Start SocketReceiver's thread")
			super().start()

		def stop(self) -> None:
			self._isStop = True
			self.join()
			logger.info("[+] Stop SocketReceiver's thread")

		def run(self) -> None:
			logger.info("[+] Start SocketReceiver's run method")
			self._main()
			logger.info("[+] End SocketReceiver's run method")

		def _main(self) -> None:
			logger.info("[+] Start SocketReceiver's main method")
			sel = selectors.DefaultSelector()
			sel.register( self._socket, selectors.EVENT_READ, self._recv )
			while not self._isStop:
				logger.info("[+] SocketReceiver's loop in")
				events = sel.select()   # イベント発生待ち
				for key, mask in events:
					key.data( key.fileobj )
				logger.info("[+] SocketReceiver's loop out")
			logger.info("[+] End SocketReceiver's main method")

		def _recv(self,_socket:socket.socket):
			try:
				if self._packetCount == 0:
					self._recvHandshakePacket(_socket)
				else:
					_socket._recvPacket()
				self._packetCount += 1
			except socket.timeout as e:
				logger.info("[+] SocketReceiver's timeout")
				return None
		
		def _recvHandshakePacket(self,_socket:socket.socket) -> None:
			buf = _socket.recv(14)
			_buf_str=buf.decode('utf-8')
			logger.info(f"[+] Receive SocketReceiver's Handshake Packet: {_buf_str:s}")
		
		def _recvPacket(self,_socket:socket.socket) -> None:
			header = _socket.recv(11)
			
			pktlen,id,flags,errcode = struct.unpack(">IIcH",header)
			buf=b""
			while len(buf) + 11 < pktlen:
				recvSize=1024 if pktlen-(len(buf)+11)>1024 else pktlen-(len(buf)+11)
				data=self._socket.recv(recvSize)
				if data:
					buf+=data[:recvSize]
				else:
					#If no data is received,we wait a bit before trying again
					time.sleep(0.01)
			isReplyPacket = flags==b"\x80"
			if isReplyPacket:#b'\x80' is the flag for a reply packet
				if errcode!=0:
					raise Exception(f"Received error code {errcode}")
				else:
					pass
					#replypacket
			else: 
				cmdid = errcode
				errcode = None
				#not replypacket = event notify
			
			_buf_hex=''.join('\\x{:02x}'.format(letter) for letter in buf)
			logger.info(f"[+] Receive SocketReceiver's Packet: {_buf_hex:s}")
		
		
class TestJDWPServer(Thread):
	def __init__(self, host:str="0.0.0.0", port:int=8080) -> None:
		self._host=host
		self._port=port
		self._socket = None
		Thread.__init__(self)
		self._isStop = False

	def __enter__(self):
		logger.info("[+] Enter TestJDWPServer")
		self.start()
		return self

	def __exit__(self,exc_type,exc_value,traceback):
		self.stop()
		logger.info("[+] Exit TestJDWPServer")

	def start(self) -> None:
		logger.info("[+] Start TestJDWPServer's thread")
		self.open()
		super().start()

	def stop(self) -> None:
		self._isStop = True
		self.join()
		self.close()
		logger.info("[+] Stop TestJDWPServer's thread")

	def open(self) -> None:
		logger.info("[+] Open TestJDWPServer's socket")
		self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
		self._socket.setblocking( False ) 
		self._socket.bind((self._host,self._port))
		self._socket.listen(1)

	def close(self) -> None:
		try:
			self._socket.shutdown(socket.SHUT_RDWR)
			self._socket.close()
		except:
			pass
		logger.info("[+] Close TestJDWPServer's socket")

	def run(self) -> None:
		logger.info("[+] Start TestJDWPServer's run Method")
		self._main()
		logger.info("[+] End TestJDWPServer's run Method")

	def _main(self):
		logger.info("[+] Start TestJDWPServer's main Method")

		sel = selectors.DefaultSelector()
		sel.register( self._socket, selectors.EVENT_READ, self._accept )
		events = sel.select()   # イベント発生待ち
		for key, mask in events:
			key.data( key.fileobj )
		
		sel = selectors.DefaultSelector()
		sel.register( self._conn, selectors.EVENT_READ, self._recv )
		while not self._isStop:
			try:
				logger.info("[+] TestJDWPServer's loop in")
				events = sel.select()   # イベント発生待ち
				for key, mask in events:
					key.data( key.fileobj )
				logger.info("[+] TestJDWPServer's loop out")
			except ConnectionResetError:
				break
			except BrokenPipeError:
				break
		logger.info("[+] End TestJDWPServer's main Method")

	def _accept(self,_socket:socket.socket):
		self._conn, _ = _socket.accept()
		logger.info(f"[+] Accepted TestJDWPServer's socket")

	def _recv(self,_socket) -> bytes:
		try:
			buf =_socket.recv(14)
			_buf_hex=''.join('\\x{:02x}'.format(letter) for letter in buf)
			_buf_str=buf.decode('utf-8')
			logger.info(f"[+] Receive TestJDWPServer's socket{_buf_str:s}")
			time.sleep(10)
			self.send()
		except socket.timeout as e:
			logger.info("[+] TestJDWPServer's timeout")
			return None
		return buf

	def send(self):
		logger.info("[+] Start TestJDWPServer's send Method")
		self._conn.send(HANDSHAKE2)
		logger.info("[+] End TestJDWPServer's send Method")

	def send2(self):
		logger.info("[+] Start TestJDWPServer's send2 Method")
		self._conn.send(HANDSHAKE3)
		logger.info("[+] End TestJDWPServer's send2 Method")

	def respond(self, message:str) -> str:
		logger.info(f"[+] Recv message: {message:s}")
		return message

if __name__ == '__main__':
	target, port = ("127.0.0.1", 60323)
	try:
		with TestJDWPServer(target, port,10) as srv:
			time.sleep(1)
			with JDWPClient(target, port,10) as cli:
				time.sleep(1)
				cli.send()
				srv.send2()
				time.sleep(20)
	except KeyboardInterrupt:
		print("[+] Exiting on user's request")
	except Exception:
		print("[x] An unexpected exception occurred during execution:")
		traceback.print_exc()