#!/usr/bin/env python3

#Built-in imports
import datetime
import socket
from threading import Thread, Event
import traceback
import sys
import time
import struct
import urllib.error
import argparse
import json
from logging import getLogger, config

with open('./log_config.json', 'r') as f:
	log_conf = json.load(f)

config.dictConfig(log_conf)
logger = getLogger(__name__)
logger.info('message')

t_delta=datetime.timedelta(hours=9)
JST=datetime.timezone(t_delta,'JST')

#JDWP protocol variables
HANDSHAKE=b"JDWP-Handshake"

#Command signatures
VERSION_SIG=(1,1)
CLASSESBYSIGNATURE_SIG=(1,2)
ALLCLASSES_SIG=(1,3)
ALLTHREADS_SIG=(1,4)
IDSIZES_SIG=(1,7)
CREATESTRING_SIG=(1,11)
SUSPENDVM_SIG=(1,8)
RESUMEVM_SIG=(1,9)
SIGNATURE_SIG=(2,1)
FIELDS_SIG=(2,4)
METHODS_SIG=(2,5)
GETVALUES_SIG=(2,6)
CLASSOBJECT_SIG=(2,11)
INVOKESTATICMETHOD_SIG=(3,3)
REFERENCETYPE_SIG=(9,1)
INVOKEMETHOD_SIG=(9,6)
STRINGVALUE_SIG=(10,1)
THREADNAME_SIG=(11,1)
THREADSUSPEND_SIG=(11,2)
THREADRESUME_SIG=(11,3)
THREADSTATUS_SIG=(11,4)
THREADFRAMES_SIG=(11,6)
EVENTSET_SIG=(15,1)
EVENTCLEAR_SIG=(15,2)
EVENTCLEARALL_SIG=(15,3)

#Other codes
MODKIND_COUNT=1
MODKIND_THREADONLY=2
MODKIND_CLASSMATCH=5
MODKIND_LOCATIONONLY=7
EVENT_BREAKPOINT=2
SUSPEND_NONE=0
SUSPEND_EVENTTHREAD=1
SUSPEND_ALL=2
NOT_IMPLEMENTED=99
VM_DEAD=112
INVOKE_SINGLE_THREADED=2
TAG_OBJECT=76
TAG_STRING=115
TYPE_CLASS=1

class Singleton(object):
	def __new__(cls, *args, **kargs):
		if not hasattr(cls, "_instance"):
			cls._instance = super(Singleton, cls).__new__(cls)
		return cls._instance
	
class JDWPClient(Singleton):

	def __init__(self,host:str,port:int=8000,timeout:float=10) -> None:
		self._host=host
		self._port=port
		self._socket=None
		self._timeout = timeout

	def __enter__(self):
		logger.info("[+] Enter JDWPClient")
		self.open()
		self._socketReceiver = self.SocketReceiver(self._socket)
		self._socketReceiver.start()
		return self

	def open(self) -> None:
		logger.info("[+] Open JDWPClient's socket")
		self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,0)
		if self._timeout < 0:
			self._socket.settimeout(self._timeout)
		self._socket.bind((self._host,60324))
		print(id(self._socket))

	def close(self) -> None:
		if self._socket:
			self._socket.close()
			self._socket=None
		logger.info("[+] Close JDWPClient's socket")

	def __exit__(self,exc_type,exc_value,traceback):
		self._socketReceiver.stop()
		self.close()
		logger.info("[+] Exit JDWPClient")
			
	def send(self):
		logger.info("[+] Start JDWPClient's send Method")
		self._socket.sendto(HANDSHAKE,(self._host,self._port))
		logger.info("[+] End JDWPClient's send Method")
		
	class SocketReceiver(Thread):
		def __init__(self,socket:socket.socket) -> None:
			Thread.__init__(self)
			self._socket = socket
			self._isStop = False

		def start(self) -> None:
			logger.info("[+] Start SocketReceiver's thread")
			super().start()

		def stop(self) -> None:
			self._isStop = True
			self.join()
			logger.info("[+] Stop SocketReceiver's thread")

		def run(self) -> None:
			logger.info("[+] Start SocketReceiver's run method")
			self._main()
			logger.info("[+] End SocketReceiver's run method")

		def _main(self) -> None:
			logger.info("[+] Start SocketReceiver's main method")
			while not self._isStop:
				logger.info("[+] SocketReceiver's loop in")
				self._recv()
				logger.info("[+] SocketReceiver's loop out")
			logger.info("[+] End SocketReceiver's main method")

		def _recv(self) -> bytes:
			try:
				print(id(self._socket))
				print(type(self._socket))
				print(self._socket.recvfrom)
				buf, addr = self._socket.recvfrom(14)
				logger.info(''.join('\\x{:02x}'.format(letter) for letter in buf))
			except socket.timeout as e:
				logger.info("[+] SocketReceiver's timeout")
				return None
			return buf
		
class TestJDWPServer(Thread):
	def __init__(self, host:str="0.0.0.0", port:int=8080,timeout:float=10) -> None:
		self._host=host
		self._port=port
		self._socket = None
		self._timeout = timeout
		Thread.__init__(self)
		#self.isRunning = Event()
		self._isStop = False

	def __enter__(self):
		logger.info("[+] Enter TestJDWPServer")
		self.start()
		return self

	def __exit__(self,exc_type,exc_value,traceback):
		self.stop()
		logger.info("[+] Exit TestJDWPServer")

	def start(self) -> None:
		logger.info("[+] Start TestJDWPServer's thread")
		self.open()
		super().start()

	def stop(self) -> None:
		self._isStop = True
		self.join()
		self.close()
		logger.info("[+] Stop TestJDWPServer's thread")

	def open(self) -> None:
		logger.info("[+] Open TestJDWPServer's socket")
		self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, 0)#SOCK_STREAM
		self._socket.settimeout(self._timeout)
		self._socket.bind((self._host,self._port))
		#self._socket.listen(1)
		#self._socket.connect((self._host, self._port))

	def close(self) -> None:
		try:
			self._socket.shutdown(socket.SHUT_RDWR)
			self._socket.close()
		except:
			pass
		logger.info("[+] Close TestJDWPServer's socket")

	def run(self) -> None:
		logger.info("[+] Start TestJDWPServer's run Method")
		self._main()
		logger.info("[+] End TestJDWPServer's run Method")

	def _main(self):
		logger.info("[+] Start TestJDWPServer's main Method")
		while not self._isStop:
			try:
				#self._socket.connect((self._host, self._port))
				#self.conn, _ = self._socket.accept()
				pass
			except TimeoutError:
				logger.info(f"[-] Not Accept TestJDWPServer's socket")
				continue
			break
		logger.info(f"[+] Accepted TestJDWPServer's socket")
		while not self._isStop:
			try:
				logger.info("[+] TestJDWPServer's loop in")
				self._recv()
				logger.info("[+] TestJDWPServer's loop out")
			except ConnectionResetError:
				break
			except BrokenPipeError:
				break
		logger.info("[+] End TestJDWPServer's main Method")

	def _recv(self) -> bytes:
		try:
			print(type(self._socket))
			buf,addr =self._socket.recvfrom(14)
			logger.info(''.join('\\x{:02x}'.format(letter) for letter in buf))
			self.send()
		except socket.timeout as e:
			logger.info("[+] TestJDWPServer's timeout")
			return None
		return buf

	def send(self):
		logger.info("[+] Start TestJDWPServer's send Method")
		time.sleep(12)
		self._socket.sendto(HANDSHAKE,(self._host,self._port))
		logger.info("[+] End TestJDWPServer's send Method")

	def respond(self, message:str) -> str:
		logger.info(f"[+] Recv message: {message:s}")
		return message

if __name__ == '__main__':
	target, port = ("127.0.0.1", 60323)
	try:
		with TestJDWPServer(target, port,10) as srv:
			time.sleep(1)
			with JDWPClient(target, port,10) as cli:
				time.sleep(1)
				cli.send()
	except KeyboardInterrupt:
		print("[+] Exiting on user's request")
	except Exception:
		print("[x] An unexpected exception occurred during execution:")
		traceback.print_exc()